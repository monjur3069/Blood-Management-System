﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class AdminViewDonorProfile : Form
    {
        public AdminViewDonorProfile()
        {
            InitializeComponent();
        }

        private void button_View_Click(object sender, EventArgs e)
        {
            ViewDonorProfile();
        }

        private void ViewDonorProfile()
        {

            string indexID = textBox_indexID.Text.Trim().ToString();
            // string username = textBox_username.Text.Trim().ToString();
            string testIndex = null;

            if ((!string.IsNullOrEmpty(indexID)) && (indexID != "index"))
            {
                string ConnectString = ConnectionString.connString;
                MySqlConnection conn = new MySqlConnection(ConnectString);

                try
                {

                    //opening connection
                    conn.Open();

                    DataTable dt = new DataTable();

                    MySqlDataReader myReader = null;

                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases, imgName from donortable where Donor_Index = '" + indexID + "' ", conn);
                    myReader = myCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        testIndex = (myReader["Donor_Index"].ToString());
                    }
                    if (testIndex != indexID)
                    {
                        
                        label_username.Text = "username";
                                                
                        label_name.Text = "151631030XX";
                        label_id.Text = "151631030XX";
                        label_dept.Text = "XXXXX";
                        label_intake.Text = "XXX";
                        label_section.Text = "XX";
                        label_phone.Text = "017299000XX";
                        labe_email.Text = "someone@example.com";
                        label_birth.Text = "1990-10-10";

                        label_age.Text = "XX";
                        label_city.Text = "XXXXX";
                        label_address.Text = "Donor Adress";
                        label_blood_group.Text = "X";
                        label_gender.Text = "XXXXX";

                        label_eligibility.Text = "XXX";


                        label_last_donation.Text = "1990-10-10";

                        label_diseases.Text = "N/A";

                        string paths = Application.StartupPath;
                        pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + "imagedefault.jpg");

                        MessageBox.Show(" Donor Not Found! ");


                        myReader.Close();
                        conn.Close();

                    }
                    else
                    {
                        
                        
                        //assigning DB value to fields
                        label_username.Text = (myReader["username"].ToString());

                        textBox_indexID.Text = (myReader["Donor_Index"].ToString());

                        label_name.Text = (myReader["Student_Name"].ToString());
                        label_id.Text = (myReader["Student_ID"].ToString());
                        label_dept.Text = (myReader["Department"].ToString());
                        label_intake.Text = (myReader["Intake"].ToString());
                        label_section.Text = (myReader["Section"].ToString());
                        label_phone.Text = (myReader["Phone_No"].ToString());
                        labe_email.Text = (myReader["Email_ID"].ToString());
                        label_birth.Text = (myReader["Birth_Day"].ToString());

                        label_age.Text = (myReader["Age"].ToString());
                        label_city.Text = (myReader["City"].ToString());
                        label_address.Text = (myReader["Address"].ToString());
                        label_blood_group.Text = (myReader["Blood_Group"].ToString());
                        label_gender.Text = (myReader["Gender"].ToString());

                        //label_eligibility.Text = (myReader["Eligibility"].ToString().ToUpper());

                        string LastDonationTemp = (myReader["Last_Donation"].ToString());
                        label_last_donation.Text = LastDonationTemp;

                        label_diseases.Text = (myReader["Diseases"].ToString());

                        string tempLoadImagePath = (myReader["imgName"].ToString());
                        /***************IMGAE PATH *****************/
                        if ((tempLoadImagePath == "0") || (string.IsNullOrEmpty(tempLoadImagePath)))
                        {
                            tempLoadImagePath = "imagedefault.jpg";
                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        else
                        {

                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        /***************IMGAE PATH *****************/
                        /***************** Eligibility Issue*********************/
                        DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);


                        DateTime lastDonationDate = LastDonationTemp2;
                        DateTime currentDate = DateTime.Now;

                        TimeSpan difference = currentDate - lastDonationDate;

                        int differenceInDays = difference.Days;

                        // int differenceInHours = difference.Hours;
                        //string totalDays = differenceInDays.ToString();
                        //return differenceInDays;



                        if (differenceInDays >= 90)
                        {
                            label_eligibility.Text = "YES";
                        }
                        else
                        {
                            label_eligibility.Text = "NO";
                        }
                        /***************** Eligibility Issue*********************/

                        myReader.Close();
                        conn.Close();
                                               
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Empty index!");
            }


        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {

            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_previous_Click(object sender, EventArgs e)
        {
            ViewPreviousProfile();
        }

        private void ViewPreviousProfile()
        {
            string indexID = textBox_indexID.Text.Trim().ToString();
            int tempIndexID = 0;
            string testIndex = null;

            if ((!string.IsNullOrEmpty(indexID)) && (indexID != "index"))
            {
                tempIndexID = int.Parse(indexID) - 1;
                indexID = tempIndexID.ToString();

                string ConnectString = ConnectionString.connString;
                MySqlConnection conn = new MySqlConnection(ConnectString);

                try
                {

                    //opening connection
                    conn.Open();

                    DataTable dt = new DataTable();

                    MySqlDataReader myReader = null;

                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases, imgName from donortable where Donor_Index = '" + indexID + "' ", conn);
                    myReader = myCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        testIndex = (myReader["Donor_Index"].ToString());
                    }
                    if (testIndex != indexID)
                    {
                        textBox_indexID.Text = tempIndexID.ToString();

                        label_username.Text = "username";

                        label_name.Text = "151631030XX";
                        label_id.Text = "151631030XX";
                        label_dept.Text = "XXXXX";
                        label_intake.Text = "XXX";
                        label_section.Text = "XX";
                        label_phone.Text = "017299000XX";
                        labe_email.Text = "someone@example.com";
                        label_birth.Text = "1990-10-10";

                        label_age.Text = "XX";
                        label_city.Text = "XXXXX";
                        label_address.Text = "Donor Adress";
                        label_blood_group.Text = "X";
                        label_gender.Text = "XXXXX";

                        label_eligibility.Text = "XXX";


                        label_last_donation.Text = "1990-10-10";

                        label_diseases.Text = "N/A";
                        string paths = Application.StartupPath;
                        pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + "imagedefault.jpg");

                        myReader.Close();
                        conn.Close();

                        
                    }
                    else
                    {
                        //assigning DB value to fields
                        label_username.Text = (myReader["username"].ToString());

                        textBox_indexID.Text = (myReader["Donor_Index"].ToString());

                        label_name.Text = (myReader["Student_Name"].ToString());
                        label_id.Text = (myReader["Student_ID"].ToString());
                        label_dept.Text = (myReader["Department"].ToString());
                        label_intake.Text = (myReader["Intake"].ToString());
                        label_section.Text = (myReader["Section"].ToString());
                        label_phone.Text = (myReader["Phone_No"].ToString());
                        labe_email.Text = (myReader["Email_ID"].ToString());
                        label_birth.Text = (myReader["Birth_Day"].ToString());

                        label_age.Text = (myReader["Age"].ToString());
                        label_city.Text = (myReader["City"].ToString());
                        label_address.Text = (myReader["Address"].ToString());
                        label_blood_group.Text = (myReader["Blood_Group"].ToString());
                        label_gender.Text = (myReader["Gender"].ToString());

                        //label_eligibility.Text = (myReader["Eligibility"].ToString().ToUpper());

                        string LastDonationTemp = (myReader["Last_Donation"].ToString());
                        label_last_donation.Text = LastDonationTemp;

                        label_diseases.Text = (myReader["Diseases"].ToString());

                        string tempLoadImagePath = (myReader["imgName"].ToString());

                        /***************IMGAE PATH *****************/
                        if ((tempLoadImagePath == "0") || (string.IsNullOrEmpty(tempLoadImagePath)))
                        {
                            tempLoadImagePath = "imagedefault.jpg";
                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        else
                        {

                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        /***************IMGAE PATH *****************/


                        /***************** Eligibility Issue*********************/
                        DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);


                        DateTime lastDonationDate = LastDonationTemp2;
                        DateTime currentDate = DateTime.Now;

                        TimeSpan difference = currentDate - lastDonationDate;

                        int differenceInDays = difference.Days;

                        // int differenceInHours = difference.Hours;
                        //string totalDays = differenceInDays.ToString();
                        //return differenceInDays;



                        if (differenceInDays >= 90)
                        {
                            label_eligibility.Text = "YES";
                        }
                        else
                        {
                            label_eligibility.Text = "NO";
                        }
                        /***************** Eligibility Issue*********************/

                        myReader.Close();
                        conn.Close();


                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Empty Index!");
            }
        }

        private void button_Next_Click(object sender, EventArgs e)
        {
            ViewNextProfile();
        }

        private void ViewNextProfile()
        {
            string indexID = textBox_indexID.Text.Trim().ToString();
            int tempIndexID = 0;
            string testIndex = null;

            if ((!string.IsNullOrEmpty(indexID)) && (indexID != "index"))
            {
                tempIndexID = int.Parse(indexID) + 1;
                indexID = tempIndexID.ToString();

                string ConnectString = ConnectionString.connString;
                MySqlConnection conn = new MySqlConnection(ConnectString);

                try
                {

                    //opening connection
                    conn.Open();

                    DataTable dt = new DataTable();

                    MySqlDataReader myReader = null;

                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases, imgName from donortable where Donor_Index = '" + indexID + "' ", conn);
                    myReader = myCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        testIndex = (myReader["Donor_Index"].ToString());
                    }
                    if (testIndex != indexID)
                    {
                        textBox_indexID.Text = tempIndexID.ToString();

                        label_username.Text = "username";

                        label_name.Text = "151631030XX";
                        label_id.Text = "151631030XX";
                        label_dept.Text = "XXXXX";
                        label_intake.Text = "XXX";
                        label_section.Text = "XX";
                        label_phone.Text = "017299000XX";
                        labe_email.Text = "someone@example.com";
                        label_birth.Text = "1990-10-10";

                        label_age.Text = "XX";
                        label_city.Text = "XXXXX";
                        label_address.Text = "Donor Adress";
                        label_blood_group.Text = "X";
                        label_gender.Text = "XXXXX";
                        string paths = Application.StartupPath;
                        pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + "imagedefault.jpg");

                        myReader.Close();
                        conn.Close();


                    }
                    else
                    {
                        //assigning DB value to fields
                        label_username.Text = (myReader["username"].ToString());

                        textBox_indexID.Text = (myReader["Donor_Index"].ToString());

                        label_name.Text = (myReader["Student_Name"].ToString());
                        label_id.Text = (myReader["Student_ID"].ToString());
                        label_dept.Text = (myReader["Department"].ToString());
                        label_intake.Text = (myReader["Intake"].ToString());
                        label_section.Text = (myReader["Section"].ToString());
                        label_phone.Text = (myReader["Phone_No"].ToString());
                        labe_email.Text = (myReader["Email_ID"].ToString());
                        label_birth.Text = (myReader["Birth_Day"].ToString());

                        label_age.Text = (myReader["Age"].ToString());
                        label_city.Text = (myReader["City"].ToString());
                        label_address.Text = (myReader["Address"].ToString());
                        label_blood_group.Text = (myReader["Blood_Group"].ToString());
                        label_gender.Text = (myReader["Gender"].ToString());

                        //label_eligibility.Text = (myReader["Eligibility"].ToString().ToUpper());

                        string LastDonationTemp = (myReader["Last_Donation"].ToString());
                        label_last_donation.Text = LastDonationTemp;

                        label_diseases.Text = (myReader["Diseases"].ToString());

                        string tempLoadImagePath = (myReader["imgName"].ToString());
                        /***************IMGAE PATH *****************/
                        if ((tempLoadImagePath == "0") || (string.IsNullOrEmpty(tempLoadImagePath)))
                        {
                            tempLoadImagePath = "imagedefault.jpg";
                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        else
                        {

                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        /***************IMGAE PATH *****************/
                        /***************** Eligibility Issue*********************/
                        DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);


                        DateTime lastDonationDate = LastDonationTemp2;
                        DateTime currentDate = DateTime.Now;

                        TimeSpan difference = currentDate - lastDonationDate;

                        int differenceInDays = difference.Days;

                        // int differenceInHours = difference.Hours;
                        //string totalDays = differenceInDays.ToString();
                        //return differenceInDays;



                        if (differenceInDays >= 90)
                        {
                            label_eligibility.Text = "YES";
                        }
                        else
                        {
                            label_eligibility.Text = "NO";
                        }
                        /***************** Eligibility Issue*********************/

                        myReader.Close();
                        conn.Close();


                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Empty Index!");
            }

        }

        private void button_update_Click(object sender, EventArgs e)
        {
            UpdateDonorProfileAdmin profile = new UpdateDonorProfileAdmin();
            profile.Width = this.Width;
            profile.Height = this.Height;
            profile.StartPosition = FormStartPosition.Manual;
            profile.Location = new Point(this.Location.X, this.Location.Y);
            //profile.textBox_indexID.Text = "0";
            // Program was crushing if the index was null, so decided to force changed it to "0", but now changing logic, checking null index first.

            this.Hide();
            profile.ShowDialog();
            this.Close();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void textBox_indexID_Enter(object sender, EventArgs e)
        {
            if (textBox_indexID.Text == "index")
            {
                textBox_indexID.Text = "";
                textBox_indexID.ForeColor = Color.Black;
            }
        }

        private void textBox_indexID_Leave(object sender, EventArgs e)
        {
            if (textBox_indexID.Text == "")
            {
                textBox_indexID.Text = "index";
                textBox_indexID.ForeColor = Color.Gray;
            }
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            
        
        }

        private void textBox_indexID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
