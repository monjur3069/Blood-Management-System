﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Admincp : Form
    {
        public Admincp()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button_home_Click(object sender, EventArgs e)
        {
            
        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_regdonor_Click(object sender, EventArgs e)
        {
            Userreg reg = new Userreg();
            reg.Width = this.Width;
            reg.Height = this.Height;
            reg.StartPosition = FormStartPosition.Manual;
            reg.Location = new Point(this.Location.X, this.Location.Y);

            DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
            reg.dateTimePicker_birthday.Value = setBirthDayTime;

            DateTime setLastDonationTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
            reg.dateTimePicker_lastdonation.Value = setLastDonationTime;


            this.Hide();
            reg.ShowDialog();
            this.Close();
        }

        private void button_deletedonor_Click(object sender, EventArgs e)
        {
            Admindelete admindelete = new Admindelete();
            admindelete.Width = this.Width;
            admindelete.Height = this.Height;
            admindelete.StartPosition = FormStartPosition.Manual;
            admindelete.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admindelete.ShowDialog();
            this.Close();
        }

        private void button_searchdonor_Click(object sender, EventArgs e)
        {
            Adminsearch adminsearch = new Adminsearch();
            adminsearch.Width = this.Width;
            adminsearch.Height = this.Height;
            adminsearch.StartPosition = FormStartPosition.Manual;
            adminsearch.Location = new Point(this.Location.X, this.Location.Y);
          

            this.Hide();
            adminsearch.ShowDialog();
            this.Close();
        }

        private void button_adminview_all_donor_Click(object sender, EventArgs e)
        {
            Alldonorlist alldonorlist = new Alldonorlist();
            alldonorlist.Width = this.Width;
            alldonorlist.Height = this.Height;
            alldonorlist.StartPosition = FormStartPosition.Manual;
            alldonorlist.Location = new Point(this.Location.X, this.Location.Y);
            // =================================================================
            string ConnectString = ConnectionString.connString;


            //string ConnectString = "datasource = localhost; username = root; password = ; database = bubt_blood_donation_center ";
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                conn.Open();
                MySqlCommand query = conn.CreateCommand();
                query.CommandType = CommandType.Text;

                query.CommandText = "Select * from donortable ";
                //create adaptor to fill data from database
                MySqlDataAdapter da = new MySqlDataAdapter(query);
                //create datatable which holds the data
                DataTable dt = new DataTable();
                da.Fill(dt);
                //bind your data to gridview
                alldonorlist.dataGridView_ALL_donor_list.DataSource = dt;
                // dataGridView1.DataBind();
                                
                query.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //=====================================================================
            this.Hide();
            alldonorlist.ShowDialog();
            this.Close();
        }

        private void button_delete_user_Click(object sender, EventArgs e)
        {
            DeleteUser userDelete = new DeleteUser();
            userDelete.Width = this.Width;
            userDelete.Height = this.Height;
            userDelete.StartPosition = FormStartPosition.Manual;
            userDelete.Location = new Point(this.Location.X, this.Location.Y);


            this.Hide();
            userDelete.ShowDialog();
            this.Close();
        }

        private void button_update_pwd_Click(object sender, EventArgs e)
        {
            ChangePasswprd updatepwd = new ChangePasswprd();
            updatepwd.Width = this.Width;
            updatepwd.Height = this.Height;
            updatepwd.StartPosition = FormStartPosition.Manual;
            updatepwd.Location = new Point(this.Location.X, this.Location.Y);


            this.Hide();
            updatepwd.ShowDialog();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateDonorProfileAdmin profile = new UpdateDonorProfileAdmin();
            profile.Width = this.Width;
            profile.Height = this.Height;
            profile.StartPosition = FormStartPosition.Manual;
            profile.Location = new Point(this.Location.X, this.Location.Y);
            //profile.textBox_indexID.Text = "0";
            // Program was crushing if the index was null, so decided to force changed it to "0", but now changing logic, checking null index first.

            this.Hide();
            profile.ShowDialog();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DeleteDonorProfileAdmin dltprofile = new DeleteDonorProfileAdmin();
            dltprofile.Width = this.Width;
            dltprofile.Height = this.Height;
            dltprofile.StartPosition = FormStartPosition.Manual;
            dltprofile.Location = new Point(this.Location.X, this.Location.Y);
            //dltprofile.textBox_indexID.Text = "0"; NB : if it is null then the program was crushing by pressing next prev button so i [RAJIB] forced it to "0", but later i thought checking null or not would be more better. 
            // so the above line is commenting out after putting some null check logic.
            this.Hide();
            dltprofile.ShowDialog();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PatientDonor patientdonor = new PatientDonor();

            patientdonor.Width = this.Width;
            patientdonor.Height = this.Height;
            patientdonor.StartPosition = FormStartPosition.Manual;
            patientdonor.Location = new Point(this.Location.X, this.Location.Y);
            
            this.Hide();
            patientdonor.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Patient patient = new Patient();

            patient.Width = this.Width;
            patient.Height = this.Height;
            patient.StartPosition = FormStartPosition.Manual;
            patient.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            patient.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            patientdonorInfo pdinfo = new patientdonorInfo();
            pdinfo.Width = this.Width;
            pdinfo.Height = this.Height;
            pdinfo.StartPosition = FormStartPosition.Manual;
            pdinfo.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            pdinfo.ShowDialog();
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            AdminViewDonorProfile viewprofiledonor = new AdminViewDonorProfile();
            viewprofiledonor.Width = this.Width;
            viewprofiledonor.Height = this.Height;
            viewprofiledonor.StartPosition = FormStartPosition.Manual;
            viewprofiledonor.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            viewprofiledonor.ShowDialog();
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            PatientModify pmdfy = new PatientModify();
            pmdfy.Width = this.Width;
            pmdfy.Height = this.Height;
            pmdfy.StartPosition = FormStartPosition.Manual;
            pmdfy.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            pmdfy.ShowDialog();
            this.Close();
        }
    }
}
