﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Admindelete : Form
    {
        public Admindelete()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            deleteDonorProfile();
        }
        private void deleteDonorProfile()
        {
            string indexID = textBox_deletedonor.Text.Trim().ToString();
            string testIndex = null;


            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            if(!string.IsNullOrEmpty(indexID) && (indexID != "Enter username"))
            {
                try
                {

                    //opening connection
                    conn.Open();

                    DataTable dt = new DataTable();

                    MySqlDataReader myReader = null;

                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases from donortable where Donor_Index = '" + indexID + "' ", conn);
                    myReader = myCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        testIndex = (myReader["Donor_Index"].ToString());
                    }
                    if (testIndex != indexID)
                    {
                        MessageBox.Show(" Donor Not Found! ");

                        myReader.Close();
                        conn.Close();

                    }
                    else
                    {
                        myCommand.Cancel();
                        myReader.Close();
                        
                        MySqlCommand cmd = conn.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "DELETE FROM donortable WHERE Donor_Index = '" + indexID + "'  ";

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("User's Personal Information has been DELETED.");
                        conn.Close();

                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter username!");
            }

        }

        private void textBox_deletedonor_Enter(object sender, EventArgs e)
        {
            if (textBox_deletedonor.Text == "Enter IndexID")
            {
                textBox_deletedonor.Text = "";
                textBox_deletedonor.ForeColor = Color.Black;
            }
        }

        private void textBox_deletedonor_Leave(object sender, EventArgs e)
        {
            if (textBox_deletedonor.Text == "")
            {
                textBox_deletedonor.Text = "Enter IndexID";
                textBox_deletedonor.ForeColor = Color.Gray;
            }
        }
    }
}
