﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication9
{
    public partial class Adminlogin : Form
    {
        public Adminlogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button_home_Click(object sender, EventArgs e)
        {
            /*Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close(); */
        }

        private void button_home2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_donorlist_Click(object sender, EventArgs e)
        {
            Donorlist d = new Donorlist();
            d.Width = this.Width;
            d.Height = this.Height;
            d.StartPosition = FormStartPosition.Manual;
            d.Location = new Point(this.Location.X, this.Location.Y);
            //d.dataGridView_donor_list = new DataGridView();
            // d.dataGridView_donor_list.Enabled = true;
            //d.dataGridView_donor_list.Visible = true;

            string ConnectString = "datasource = localhost; username = root; password = ; database = bubt_blood_donation_center ";
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                conn.Open();
                MySqlCommand query = conn.CreateCommand();
                query.CommandType = CommandType.Text;

                query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable where Eligibility='YES'";
                //create adaptor to fill data from database
                MySqlDataAdapter da = new MySqlDataAdapter(query);
                //create datatable which holds the data
                DataTable dt = new DataTable();
                da.Fill(dt);
                //bind your data to gridview
                d.dataGridView_donor_list.DataSource = dt;
                // dataGridView1.DataBind();



                query.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            //this.Visible = false;
            this.Hide();
            d.ShowDialog();
            this.Close();
                               
            //this.Hide();
            //this.Visible = true;
        }

        private void button_login_inactive_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_login_Click(object sender, EventArgs e)
        {
           
            AdminLoginValidation();

        }

        //poor code not using anymore.
        /*
        private void AdminLoginValidation2()
        {

            string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                // Trim for removing space
                string adminuserid = textBox_username.Text.Trim();
                string adminpassword = textBox_password.Text.Trim();

                conn.Open();
                
                MySqlDataAdapter sda = new MySqlDataAdapter("Select Count(*) From adminlogin where adminid='" + adminuserid + "' and adminpwd = '" + adminpassword + "' ",conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if(dt.Rows[0][0].ToString()=="1")
                {
                    Admincp admincp = new Admincp();
                    admincp.Width = this.Width;
                    admincp.Height = this.Height;
                    admincp.StartPosition = FormStartPosition.Manual;
                    admincp.Location = new Point(this.Location.X, this.Location.Y);
                    conn.Close();
                    this.Hide();
                    admincp.ShowDialog();
                    this.Close();
                }
                else
                {
                    conn.Close();
                    MessageBox.Show("Username Password didn't match! Try again.");
                    textBox_username.Text = "Enter Admin ID";
                    textBox_password.Text = "Enter password";
                }



                //cmd.ExecuteNonQuery();
                textBox_username.Clear();
                textBox_password.Clear();
                conn.Close();
               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        */

        private void AdminLoginValidation()
        {
            // Trim for removing space
            string adminuserid = textBox_username.Text.Trim();
            string adminpassword = textBox_password.Text.Trim();
            string testAdminId = null; // for dumping DB username and check for matching
            string testAdminPwd = null; // for dumping DB username and check for matching

            // Checking ussername password get matched or not.

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            if (!string.IsNullOrEmpty(adminuserid) && !string.IsNullOrEmpty(adminpassword) && (adminuserid != "Enter admistrative ID") && (adminpassword != "Enter Password"))
            {
                try
                {
                    conn.Open();
                    DataTable dt = new DataTable();
                    MySqlDataReader myReader = null;
                    MySqlCommand myCommand = new MySqlCommand("select adminid, adminpwd from adminlogin where adminid ='" + adminuserid + "' and adminpwd = '" + adminpassword + "' ", conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        testAdminId = (myReader["adminid"].ToString().Trim());
                        testAdminPwd = (myReader["adminpwd"].ToString().Trim());
                    }
                    if ((adminuserid == testAdminId) && (testAdminPwd == adminpassword))
                    {
                        Admincp admincp = new Admincp();
                        admincp.Width = this.Width;
                        admincp.Height = this.Height;
                        admincp.StartPosition = FormStartPosition.Manual;
                        admincp.Location = new Point(this.Location.X, this.Location.Y);

                        myReader.Close();
                        conn.Close();
                        this.Hide();
                        admincp.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Username Password didn't match! Try again.");
                        textBox_username.Clear();
                        textBox_password.Clear();
                        myReader.Close();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter Administrative ID and Password");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void textBox_username_Enter(object sender, EventArgs e)
        {
            if(textBox_username.Text == "Enter admistrative ID")
            {
                textBox_username.Text = "";
                textBox_username.ForeColor = Color.Black;
            }
        }

        private void textBox_username_Leave(object sender, EventArgs e)
        {
            if (textBox_username.Text == "")
            {
                textBox_username.Text = "Enter admistrative ID";
                textBox_username.ForeColor = Color.Gray;
            }
        }

        private void textBox_password_Enter(object sender, EventArgs e)
        {
            if(textBox_password.Text == "Enter Password")
            {
                textBox_password.Text = "";
                textBox_password.ForeColor = Color.Black;
            }
        }

        private void textBox_password_Leave(object sender, EventArgs e)
        {
            if (textBox_password.Text == "")
            {
                textBox_password.Text = "Enter Password";
                textBox_password.ForeColor = Color.Gray;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Contact BUBT or an ADMIN");
            DEVELOPERS devp = new DEVELOPERS();
            devp.Width = this.Width;
            devp.Height = this.Height;
            devp.StartPosition = FormStartPosition.Manual;
            devp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            devp.ShowDialog();
            this.Close();
        }
    }

}

