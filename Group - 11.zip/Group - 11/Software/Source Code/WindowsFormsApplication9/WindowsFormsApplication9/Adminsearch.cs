﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Adminsearch : Form
    {
        public Adminsearch()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void Adminsearch_Load(object sender, EventArgs e)
        {

        }

        private void textBox_searchby_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_searcfor_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_search_Click(object sender, EventArgs e)
        {
            admin_RegularSearch();
        }

        private void admin_RegularSearch()
        {
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);
                         
            try
            {
              if(comboBox_AdminGeneralSearch.SelectedIndex != -1)
                {
                    string searchBy = comboBox_AdminGeneralSearch.SelectedItem.ToString().Trim().ToUpper();
                    string searchValue = textBox_adminGeneralSearchValue.Text.Trim().ToString().ToUpper();

                    conn.Open();
                    MySqlCommand query = conn.CreateCommand();
                    query.CommandType = CommandType.Text;

                    if (searchBy == "BLOOD GROUP")
                    {
                        // query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable where Eligibility ='YES' and Blood_Group = '" + searchValue + "' ";
                        query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address from donortable where  Blood_Group = '" + searchValue + "' ";
                    }
                    else if (searchBy == "NAME")
                    {
                        query.CommandText = "Select * from donortable where  Student_Name LIKE '%" + searchValue + "%' ";
                    }
                    else if (searchBy == "CITY")
                    {
                        query.CommandText = "Select * from donortable where  City LIKE '%" + searchValue + "%' ";
                    }
                    else if (searchBy == "PHONE")
                    {
                        query.CommandText = "Select * from donortable where  Phone_No LIKE '%" + searchValue + "%' ";
                    }
                    else if (searchBy == "STUDENT ID")
                    {
                        query.CommandText = "Select * from donortable where  Student_ID LIKE '%" + searchValue + "%' ";
                    }
                    else if (searchBy == "DEPARTMENT")
                    {
                        query.CommandText = "Select * from donortable where  Department LIKE '%" + searchValue + "%' ";
                    }
                    // table changed to user login info
                    else if (searchBy == "USER NAME")
                    {
                        query.CommandText = "Select * from userlogin where 	username LIKE '%" + searchValue + "%' ";
                    }
                    else
                    {
                        MessageBox.Show("Select Search Item");
                    }

                    //create adaptor to fill data from database
                    MySqlDataAdapter sda = new MySqlDataAdapter(query);

                    //create datatable which holds the data
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    //bind your data to gridview
                    dataGridView_admin_searchResult.DataSource = dt;
                    // dataGridView1.DataBind();



                    query.ExecuteNonQuery();
                    conn.Close();

                }
              else
                {
                    comboBox_AdminGeneralSearch.Text = "Select Search Item";
                    MessageBox.Show("Select Search Item");
                }

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox_AdminGeneralSearch_Enter(object sender, EventArgs e)
        {
            if(comboBox_AdminGeneralSearch.Text == "Select Search Item")
            {
                comboBox_AdminGeneralSearch.Text = "";
                comboBox_AdminGeneralSearch.ForeColor = Color.Black;
            }
        }

        private void comboBox_AdminGeneralSearch_Leave(object sender, EventArgs e)
        {
            if (comboBox_AdminGeneralSearch.Text == "")
            {
                comboBox_AdminGeneralSearch.Text = "Select Search Item";
                comboBox_AdminGeneralSearch.ForeColor = Color.Gray;
            }
        }

        private void textBox_adminGeneralSearchValue_Enter(object sender, EventArgs e)
        {
            if (textBox_adminGeneralSearchValue.Text == "keyword sample :  O+ , dhaka, 01729900004")
            {
                textBox_adminGeneralSearchValue.Text = "";
                textBox_adminGeneralSearchValue.ForeColor = Color.Black;
            }

        }

        private void textBox_adminGeneralSearchValue_Leave(object sender, EventArgs e)
        {
            if (textBox_adminGeneralSearchValue.Text == "")
            {
                textBox_adminGeneralSearchValue.Text = "keyword sample :  O+ , dhaka, 01729900004";
                textBox_adminGeneralSearchValue.ForeColor = Color.Gray;
            }
        }

        private void comboBox_AdminGeneralSearch_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int height = dataGridView_admin_searchResult.Height;
            dataGridView_admin_searchResult.Height = dataGridView_admin_searchResult.RowCount * dataGridView_admin_searchResult.RowTemplate.Height * 2;
            Bitmap bmp = new Bitmap(dataGridView_admin_searchResult.Width, dataGridView_admin_searchResult.Height);
            dataGridView_admin_searchResult.DrawToBitmap(bmp, new Rectangle(0, 0, dataGridView_admin_searchResult.Width, dataGridView_admin_searchResult.Height));
            dataGridView_admin_searchResult.Height = height;
            e.Graphics.DrawImage(bmp, 10, 10);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //PrintDialog printDlg = new PrintDialog();
            //printDlg.Document = printDocument1;

            // for previewing before printing
            PrintPreviewDialog prntpreview = new PrintPreviewDialog();
            prntpreview.Document = printDocument1;
            prntpreview.ShowDialog();


            /*printDlg.AllowSelection = true;

            printDlg.AllowSomePages = true;

            //Call ShowDialog

            if (printDlg.ShowDialog() == DialogResult.OK)
              
                printDocument1.Print();*/
        }
    }
}
