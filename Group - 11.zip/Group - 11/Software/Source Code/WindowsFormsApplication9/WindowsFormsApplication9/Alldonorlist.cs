﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication9
{
    public partial class Alldonorlist : Form
    {
        public Alldonorlist()
        {
            InitializeComponent();
        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_home_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView_donor_list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //allDonorList();
        }

        private void allDonorList()
        {
            string ConnectString = "datasource = localhost; username = root; password = ; database = bubt_blood_donation_center ";
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                conn.Open();
                MySqlCommand query = conn.CreateCommand();
                query.CommandType = CommandType.Text;

                query.CommandText = "Select * from donortable ";
                //create adaptor to fill data from database
                MySqlDataAdapter da = new MySqlDataAdapter(query);
                //create datatable which holds the data
                DataTable dt = new DataTable();
                da.Fill(dt);
                //bind your data to gridview
                dataGridView_ALL_donor_list.DataSource = dt;
                // dataGridView1.DataBind();



                query.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }




    }
}
