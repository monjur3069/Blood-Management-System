﻿namespace WindowsFormsApplication9
{
    partial class ChangePasswprd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_check_username = new System.Windows.Forms.TextBox();
            this.textBox_new_pwd = new System.Windows.Forms.TextBox();
            this.textBox_new_pwd2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button_change_pwd = new System.Windows.Forms.Button();
            this.textBox_admin_id = new System.Windows.Forms.TextBox();
            this.textBox_admin_pwd = new System.Windows.Forms.TextBox();
            this.textBox_admin_pwd2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button_submit_admin = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.Color.Green;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(387, 12);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(201, 40);
            this.button_admin_cp.TabIndex = 24;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Green;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(594, 11);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 25;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(369, 40);
            this.button_home.TabIndex = 23;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(13, 365);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(678, 25);
            this.label3.TabIndex = 20;
            this.label3.Text = "CHANGE ADMIN PASSWORD";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(11, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(680, 28);
            this.label2.TabIndex = 21;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(11, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 32);
            this.label1.TabIndex = 22;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(97, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 19);
            this.label4.TabIndex = 26;
            this.label4.Text = "Username :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_check_username
            // 
            this.textBox_check_username.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_check_username.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_check_username.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_check_username.Location = new System.Drawing.Point(256, 168);
            this.textBox_check_username.MaxLength = 20;
            this.textBox_check_username.Name = "textBox_check_username";
            this.textBox_check_username.Size = new System.Drawing.Size(197, 27);
            this.textBox_check_username.TabIndex = 27;
            this.textBox_check_username.Text = "username";
            this.textBox_check_username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_check_username.Enter += new System.EventHandler(this.textBox_check_username_Enter);
            this.textBox_check_username.Leave += new System.EventHandler(this.textBox_check_username_Leave);
            // 
            // textBox_new_pwd
            // 
            this.textBox_new_pwd.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_new_pwd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_new_pwd.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_new_pwd.Location = new System.Drawing.Point(256, 211);
            this.textBox_new_pwd.MaxLength = 20;
            this.textBox_new_pwd.Name = "textBox_new_pwd";
            this.textBox_new_pwd.PasswordChar = '*';
            this.textBox_new_pwd.Size = new System.Drawing.Size(197, 27);
            this.textBox_new_pwd.TabIndex = 27;
            this.textBox_new_pwd.Text = "password";
            this.textBox_new_pwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_new_pwd.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.textBox_new_pwd.Enter += new System.EventHandler(this.textBox_new_pwd_Enter);
            this.textBox_new_pwd.Leave += new System.EventHandler(this.textBox_new_pwd_Leave);
            // 
            // textBox_new_pwd2
            // 
            this.textBox_new_pwd2.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_new_pwd2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_new_pwd2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_new_pwd2.Location = new System.Drawing.Point(256, 254);
            this.textBox_new_pwd2.MaxLength = 20;
            this.textBox_new_pwd2.Name = "textBox_new_pwd2";
            this.textBox_new_pwd2.PasswordChar = '*';
            this.textBox_new_pwd2.Size = new System.Drawing.Size(197, 27);
            this.textBox_new_pwd2.TabIndex = 27;
            this.textBox_new_pwd2.Text = "password";
            this.textBox_new_pwd2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_new_pwd2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.textBox_new_pwd2.Enter += new System.EventHandler(this.textBox_new_pwd2_Enter);
            this.textBox_new_pwd2.Leave += new System.EventHandler(this.textBox_new_pwd2_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(97, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 19);
            this.label5.TabIndex = 26;
            this.label5.Text = "New Password :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(97, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 19);
            this.label6.TabIndex = 26;
            this.label6.Text = "Confirm Password :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_change_pwd
            // 
            this.button_change_pwd.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_change_pwd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_change_pwd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_change_pwd.ForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.button_change_pwd.Location = new System.Drawing.Point(310, 299);
            this.button_change_pwd.Name = "button_change_pwd";
            this.button_change_pwd.Size = new System.Drawing.Size(90, 35);
            this.button_change_pwd.TabIndex = 28;
            this.button_change_pwd.Text = "SUBMIT";
            this.button_change_pwd.UseVisualStyleBackColor = false;
            this.button_change_pwd.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_admin_id
            // 
            this.textBox_admin_id.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_admin_id.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_admin_id.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_admin_id.Location = new System.Drawing.Point(256, 419);
            this.textBox_admin_id.MaxLength = 20;
            this.textBox_admin_id.Name = "textBox_admin_id";
            this.textBox_admin_id.Size = new System.Drawing.Size(197, 27);
            this.textBox_admin_id.TabIndex = 29;
            this.textBox_admin_id.Text = "admin id";
            this.textBox_admin_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_admin_id.Enter += new System.EventHandler(this.textBox_admin_id_Enter);
            this.textBox_admin_id.Leave += new System.EventHandler(this.textBox_admin_id_Leave);
            // 
            // textBox_admin_pwd
            // 
            this.textBox_admin_pwd.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_admin_pwd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_admin_pwd.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_admin_pwd.Location = new System.Drawing.Point(256, 471);
            this.textBox_admin_pwd.MaxLength = 20;
            this.textBox_admin_pwd.Name = "textBox_admin_pwd";
            this.textBox_admin_pwd.PasswordChar = '*';
            this.textBox_admin_pwd.Size = new System.Drawing.Size(197, 27);
            this.textBox_admin_pwd.TabIndex = 29;
            this.textBox_admin_pwd.Text = "password";
            this.textBox_admin_pwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_admin_pwd.Enter += new System.EventHandler(this.textBox_admin_pwd_Enter);
            this.textBox_admin_pwd.Leave += new System.EventHandler(this.textBox_admin_pwd_Leave);
            // 
            // textBox_admin_pwd2
            // 
            this.textBox_admin_pwd2.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_admin_pwd2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_admin_pwd2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_admin_pwd2.Location = new System.Drawing.Point(256, 519);
            this.textBox_admin_pwd2.MaxLength = 20;
            this.textBox_admin_pwd2.Name = "textBox_admin_pwd2";
            this.textBox_admin_pwd2.PasswordChar = '*';
            this.textBox_admin_pwd2.Size = new System.Drawing.Size(197, 27);
            this.textBox_admin_pwd2.TabIndex = 29;
            this.textBox_admin_pwd2.Text = "password";
            this.textBox_admin_pwd2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_admin_pwd2.Enter += new System.EventHandler(this.textBox_admin_pwd2_Enter);
            this.textBox_admin_pwd2.Leave += new System.EventHandler(this.textBox_admin_pwd2_Leave);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Yellow;
            this.label7.Location = new System.Drawing.Point(12, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(678, 25);
            this.label7.TabIndex = 20;
            this.label7.Text = "CHANGE USER PASSWORD";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label3_Click);
            // 
            // button_submit_admin
            // 
            this.button_submit_admin.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_submit_admin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_submit_admin.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_submit_admin.ForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.button_submit_admin.Location = new System.Drawing.Point(310, 565);
            this.button_submit_admin.Name = "button_submit_admin";
            this.button_submit_admin.Size = new System.Drawing.Size(90, 35);
            this.button_submit_admin.TabIndex = 30;
            this.button_submit_admin.Text = "SUBMIT";
            this.button_submit_admin.UseVisualStyleBackColor = false;
            this.button_submit_admin.Click += new System.EventHandler(this.button_submit_admin_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(97, 422);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 19);
            this.label8.TabIndex = 26;
            this.label8.Text = "Admin ID :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(97, 474);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 19);
            this.label9.TabIndex = 26;
            this.label9.Text = "New Password :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(97, 522);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 19);
            this.label10.TabIndex = 26;
            this.label10.Text = "Confirm Password :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChangePasswprd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button_submit_admin);
            this.Controls.Add(this.textBox_admin_pwd2);
            this.Controls.Add(this.textBox_admin_pwd);
            this.Controls.Add(this.textBox_admin_id);
            this.Controls.Add(this.button_change_pwd);
            this.Controls.Add(this.textBox_new_pwd2);
            this.Controls.Add(this.textBox_new_pwd);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox_check_username);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ChangePasswprd";
            this.Text = "Admin CP Update Password";
            this.Load += new System.EventHandler(this.ChangePasswprd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_check_username;
        private System.Windows.Forms.TextBox textBox_new_pwd;
        private System.Windows.Forms.TextBox textBox_new_pwd2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_change_pwd;
        private System.Windows.Forms.TextBox textBox_admin_id;
        private System.Windows.Forms.TextBox textBox_admin_pwd;
        private System.Windows.Forms.TextBox textBox_admin_pwd2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_submit_admin;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}