﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class ChangePasswprd : Form
    {
        public ChangePasswprd()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChangeUserPwd();
        }

        private void ChangeUserPwd()
        {

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);
            string username = textBox_check_username.Text.Trim().ToString();
            string testUserName = null;
            string password = textBox_new_pwd.Text.Trim().ToString();
            string password2 = textBox_new_pwd2.Text.Trim().ToString();

            // checking if username field is empty
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(password2)&&(username !="username")&&(password != "password")&&(password2 != "password"))
            {
                if (password == password2)
                {
                    try
                    {
                        conn.Open();
                        DataTable dt = new DataTable();
                        MySqlDataReader myReader = null;
                        MySqlCommand myCommand = new MySqlCommand("select username from userlogin where username = '" + username + "' ", conn);
                        myReader = myCommand.ExecuteReader();
                        while (myReader.Read())
                        {
                            testUserName = (myReader["username"].ToString().Trim());

                        }
                        if (username == testUserName)
                        {
                            myCommand.Cancel();
                            myReader.Close(); // MySqlCommand with reader has to be closed first before using another command.
                            MySqlCommand cmd = conn.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "UPDATE userlogin SET password ='" + password + "' WHERE username = '" + username + "' ";
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Password for username : " + username + " Successfully Changed! new Password is : " + password + "");

                            textBox_check_username.Clear();
                            textBox_new_pwd.Clear();
                            textBox_new_pwd2.Clear();
                            myReader.Close();
                            conn.Close();


                        }
                        else
                        {
                            MessageBox.Show("USER NOT FOUND!");
                            textBox_check_username.Clear();
                            textBox_new_pwd.Clear();
                            textBox_new_pwd2.Clear();
                            myReader.Close();
                            conn.Close();
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }

                else
                {
                    MessageBox.Show("Password Didn't Matched!");
                }
            }
            else
            {
                MessageBox.Show("Empty Field. Input Value");
            }            
        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ChangePasswprd_Load(object sender, EventArgs e)
        {

        }

        private void button_submit_admin_Click(object sender, EventArgs e)
        {
            ChangeAdminPwd();
        }

        private void ChangeAdminPwd()
        {

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            // taking textbox input into username and password variable.
            string adminID = textBox_admin_id.Text.Trim().ToString();
            string testUserName = null;
            string password = textBox_admin_pwd.Text.Trim().ToString();
            string password2 = textBox_admin_pwd2.Text.Trim().ToString();

                // checking if username field is empty
                if (!string.IsNullOrEmpty(adminID) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(password2) && (adminID != "admin id") && (password != "password") && (password2 != "password"))
                {
                    if (password == password2)
                    {
                        try
                        {
                            conn.Open();
                            DataTable dt = new DataTable();
                            MySqlDataReader myReader = null;
                            MySqlCommand myCommand = new MySqlCommand("select adminid from adminlogin where adminid = '" + adminID + "' ", conn);
                            myReader = myCommand.ExecuteReader();
                            while (myReader.Read())
                            {
                            testUserName = (myReader["adminid"].ToString().Trim());

                            }
                            if (adminID == testUserName)
                            {
                                myCommand.Cancel();
                                myReader.Close(); // MySqlCommand with reader has to be closed first before using another command.
                                MySqlCommand cmd = conn.CreateCommand();
                                cmd.CommandType = CommandType.Text;
                                cmd.CommandText = "UPDATE adminlogin SET adminpwd ='" + password + "' WHERE adminid = '" + adminID + "' ";
                                cmd.ExecuteNonQuery();
                                MessageBox.Show("Password for adminid : " + adminID + " Successfully Changed! new Password is : " + password + "");

                                textBox_check_username.Clear();
                                textBox_new_pwd.Clear();
                                textBox_new_pwd2.Clear();
                                myReader.Close();
                                conn.Close();


                            }
                            else
                            {
                                MessageBox.Show("ID NOT FOUND!");
                                textBox_check_username.Clear();
                                textBox_new_pwd.Clear();
                                textBox_new_pwd2.Clear();
                                myReader.Close();
                                conn.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password Didn't Matched!");
                    }
                }

                else
                {
                    MessageBox.Show("Empty Field. Input Value");
                }

        }

        private void textBox_check_username_Enter(object sender, EventArgs e)
        {
            if(textBox_check_username.Text == "username")
            {
                textBox_check_username.Text = "";
                textBox_check_username.ForeColor = Color.Black;
            }
        }

        private void textBox_check_username_Leave(object sender, EventArgs e)
        {
            if (textBox_check_username.Text == "")
            {
                textBox_check_username.Text = "username";
                textBox_check_username.ForeColor = Color.Gray;
            }
        }

        private void textBox_new_pwd_Enter(object sender, EventArgs e)
        {
            if (textBox_new_pwd.Text == "password")
            {
                textBox_new_pwd.Text = "";
                textBox_new_pwd.ForeColor = Color.Black;
            }
        }

        private void textBox_new_pwd_Leave(object sender, EventArgs e)
        {
            if (textBox_new_pwd.Text == "")
            {
                textBox_new_pwd.Text = "password";
                textBox_new_pwd.ForeColor = Color.Gray;
            }
        }

        private void textBox_new_pwd2_Enter(object sender, EventArgs e)
        {
            if (textBox_new_pwd2.Text == "password")
            {
                textBox_new_pwd2.Text = "";
                textBox_new_pwd2.ForeColor = Color.Black;
            }
        }

        private void textBox_admin_id_Enter(object sender, EventArgs e)
        {
            if (textBox_admin_id.Text == "admin id")
            {
                textBox_admin_id.Text = "";
                textBox_admin_id.ForeColor = Color.Black;
            }
        }

        private void textBox_new_pwd2_Leave(object sender, EventArgs e)
        {
            if (textBox_new_pwd2.Text == "")
            {
                textBox_new_pwd2.Text = "password";
                textBox_new_pwd2.ForeColor = Color.Gray;
            }
        }

        private void textBox_admin_id_Leave(object sender, EventArgs e)
        {
            if (textBox_admin_id.Text == "")
            {
                textBox_admin_id.Text = "admin id";
                textBox_admin_id.ForeColor = Color.Gray;
            }
        }

        private void textBox_admin_pwd_Enter(object sender, EventArgs e)
        {
            if (textBox_admin_pwd.Text == "password")
            {
                textBox_admin_pwd.Text = "";
                textBox_admin_pwd.ForeColor = Color.Black;
            }
        }

        private void textBox_admin_pwd_Leave(object sender, EventArgs e)
        {
            if (textBox_admin_pwd.Text == "")
            {
                textBox_admin_pwd.Text = "password";
                textBox_admin_pwd.ForeColor = Color.Gray;
            }
        }

        private void textBox_admin_pwd2_Enter(object sender, EventArgs e)
        {
            if (textBox_admin_pwd2.Text == "password")
            {
                textBox_admin_pwd2.Text = "";
                textBox_admin_pwd2.ForeColor = Color.Black;
            }
        }

        private void textBox_admin_pwd2_Leave(object sender, EventArgs e)
        {
            if (textBox_admin_pwd2.Text == "")
            {
                textBox_admin_pwd2.Text = "password";
                textBox_admin_pwd2.ForeColor = Color.Gray;
            }
        }
    }
}
