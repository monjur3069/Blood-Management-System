﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication9
{
    static class ConnectionString
    {
        private static string _connString = "datasource = localhost; username = root; password = ; database = bubt_blood_donation_center";
        // "datasource = localhost; username = root; password = ; database = bubt_blood_donation_center";
        // "datasource = 173.254.24.21; username = pharmau7_blood; password = rajib_3087!; database = pharmau7_blood";

        public static string connString
        {
            get { return _connString; }
            set { _connString = value; }
        }
    }
    
}