﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class DEVELOPERS : Form
    {
        public DEVELOPERS()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button_home2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            Signup signup = new Signup();
            signup.Width = this.Width;
            signup.Height = this.Height;
            signup.StartPosition = FormStartPosition.Manual;
            signup.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            signup.ShowDialog();
            this.Close();
        }

        private void button_login_inactive_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }
    }
}
