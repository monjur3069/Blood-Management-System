﻿namespace WindowsFormsApplication9
{
    partial class DeleteDonorProfileAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeleteDonorProfileAdmin));
            this.button_delete = new System.Windows.Forms.Button();
            this.pictureBox1_dp = new System.Windows.Forms.PictureBox();
            this.button_Next = new System.Windows.Forms.Button();
            this.button_previous = new System.Windows.Forms.Button();
            this.button_View = new System.Windows.Forms.Button();
            this.textBox_indexID = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_id = new System.Windows.Forms.Label();
            this.label_username = new System.Windows.Forms.Label();
            this.label_2 = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_1 = new System.Windows.Forms.Label();
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label_gender = new System.Windows.Forms.Label();
            this.label_eligibility = new System.Windows.Forms.Label();
            this.label_last_donation = new System.Windows.Forms.Label();
            this.label_blood_group = new System.Windows.Forms.Label();
            this.label_age = new System.Windows.Forms.Label();
            this.label_birth = new System.Windows.Forms.Label();
            this.label_address = new System.Windows.Forms.Label();
            this.label_diseases = new System.Windows.Forms.Label();
            this.label_city = new System.Windows.Forms.Label();
            this.labe_email = new System.Windows.Forms.Label();
            this.label_phone = new System.Windows.Forms.Label();
            this.label_section = new System.Windows.Forms.Label();
            this.label_intake = new System.Windows.Forms.Label();
            this.label_dept = new System.Windows.Forms.Label();
            this.button_exit = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label_33 = new System.Windows.Forms.Label();
            this.label_14 = new System.Windows.Forms.Label();
            this.label_31 = new System.Windows.Forms.Label();
            this.label_7 = new System.Windows.Forms.Label();
            this.label_6 = new System.Windows.Forms.Label();
            this.label_32 = new System.Windows.Forms.Label();
            this.label_12 = new System.Windows.Forms.Label();
            this.label_8 = new System.Windows.Forms.Label();
            this.label_5 = new System.Windows.Forms.Label();
            this.label_4 = new System.Windows.Forms.Label();
            this.label_9 = new System.Windows.Forms.Label();
            this.label_30 = new System.Windows.Forms.Label();
            this.label_3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).BeginInit();
            this.SuspendLayout();
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.Red;
            this.button_delete.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete.ForeColor = System.Drawing.Color.White;
            this.button_delete.Location = new System.Drawing.Point(399, 569);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(90, 35);
            this.button_delete.TabIndex = 351;
            this.button_delete.Text = "DELETE";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // pictureBox1_dp
            // 
            this.pictureBox1_dp.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox1_dp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_dp.Image")));
            this.pictureBox1_dp.Location = new System.Drawing.Point(577, 182);
            this.pictureBox1_dp.Name = "pictureBox1_dp";
            this.pictureBox1_dp.Padding = new System.Windows.Forms.Padding(3);
            this.pictureBox1_dp.Size = new System.Drawing.Size(98, 126);
            this.pictureBox1_dp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_dp.TabIndex = 350;
            this.pictureBox1_dp.TabStop = false;
            // 
            // button_Next
            // 
            this.button_Next.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_Next.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Next.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Next.ForeColor = System.Drawing.SystemColors.Info;
            this.button_Next.Location = new System.Drawing.Point(591, 570);
            this.button_Next.Name = "button_Next";
            this.button_Next.Size = new System.Drawing.Size(90, 35);
            this.button_Next.TabIndex = 349;
            this.button_Next.Text = "NEXT";
            this.button_Next.UseVisualStyleBackColor = false;
            this.button_Next.Click += new System.EventHandler(this.button_Next_Click);
            // 
            // button_previous
            // 
            this.button_previous.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_previous.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_previous.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_previous.ForeColor = System.Drawing.SystemColors.Info;
            this.button_previous.Location = new System.Drawing.Point(303, 569);
            this.button_previous.Name = "button_previous";
            this.button_previous.Size = new System.Drawing.Size(90, 35);
            this.button_previous.TabIndex = 348;
            this.button_previous.Text = "PREV";
            this.button_previous.UseVisualStyleBackColor = false;
            this.button_previous.Click += new System.EventHandler(this.button_previous_Click);
            // 
            // button_View
            // 
            this.button_View.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_View.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_View.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_View.ForeColor = System.Drawing.SystemColors.Info;
            this.button_View.Location = new System.Drawing.Point(585, 123);
            this.button_View.Name = "button_View";
            this.button_View.Size = new System.Drawing.Size(90, 35);
            this.button_View.TabIndex = 347;
            this.button_View.Text = "VIEW";
            this.button_View.UseVisualStyleBackColor = false;
            this.button_View.Click += new System.EventHandler(this.button_View_Click);
            // 
            // textBox_indexID
            // 
            this.textBox_indexID.BackColor = System.Drawing.Color.LightSkyBlue;
            this.textBox_indexID.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_indexID.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_indexID.Location = new System.Drawing.Point(164, 128);
            this.textBox_indexID.Name = "textBox_indexID";
            this.textBox_indexID.Size = new System.Drawing.Size(163, 27);
            this.textBox_indexID.TabIndex = 346;
            this.textBox_indexID.Text = "index";
            this.textBox_indexID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_indexID.Enter += new System.EventHandler(this.textBox_indexID_Enter);
            this.textBox_indexID.Leave += new System.EventHandler(this.textBox_indexID_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(131, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 19);
            this.label12.TabIndex = 345;
            this.label12.Text = "***";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(64, 134);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 15);
            this.label11.TabIndex = 344;
            this.label11.Text = "INDEX ID :";
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_id.Location = new System.Drawing.Point(161, 221);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(87, 18);
            this.label_id.TabIndex = 342;
            this.label_id.Text = "151631030XX";
            // 
            // label_username
            // 
            this.label_username.Font = new System.Drawing.Font("Calibri", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_username.Location = new System.Drawing.Point(346, 128);
            this.label_username.Name = "label_username";
            this.label_username.Size = new System.Drawing.Size(209, 27);
            this.label_username.TabIndex = 343;
            this.label_username.Text = "username";
            this.label_username.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_2
            // 
            this.label_2.AutoSize = true;
            this.label_2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_2.Location = new System.Drawing.Point(64, 221);
            this.label_2.Name = "label_2";
            this.label_2.Size = new System.Drawing.Size(51, 18);
            this.label_2.TabIndex = 341;
            this.label_2.Text = "ID NO :";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.Location = new System.Drawing.Point(161, 183);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(136, 18);
            this.label_name.TabIndex = 339;
            this.label_name.Text = "FirstName LastName";
            // 
            // label_1
            // 
            this.label_1.AutoSize = true;
            this.label_1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_1.Location = new System.Drawing.Point(64, 183);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(54, 18);
            this.label_1.TabIndex = 340;
            this.label_1.Text = "NAME :";
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.Color.Green;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(388, 17);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(201, 40);
            this.button_admin_cp.TabIndex = 337;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Green;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(595, 16);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 338;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(13, 17);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(369, 40);
            this.button_home.TabIndex = 336;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(12, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 32);
            this.label1.TabIndex = 335;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_gender
            // 
            this.label_gender.AutoSize = true;
            this.label_gender.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_gender.Location = new System.Drawing.Point(601, 326);
            this.label_gender.Name = "label_gender";
            this.label_gender.Size = new System.Drawing.Size(48, 18);
            this.label_gender.TabIndex = 334;
            this.label_gender.Text = "XXXXX";
            // 
            // label_eligibility
            // 
            this.label_eligibility.AutoSize = true;
            this.label_eligibility.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_eligibility.Location = new System.Drawing.Point(601, 360);
            this.label_eligibility.Name = "label_eligibility";
            this.label_eligibility.Size = new System.Drawing.Size(32, 18);
            this.label_eligibility.TabIndex = 332;
            this.label_eligibility.Text = "XXX";
            // 
            // label_last_donation
            // 
            this.label_last_donation.AutoSize = true;
            this.label_last_donation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_last_donation.Location = new System.Drawing.Point(601, 398);
            this.label_last_donation.Name = "label_last_donation";
            this.label_last_donation.Size = new System.Drawing.Size(74, 18);
            this.label_last_donation.TabIndex = 331;
            this.label_last_donation.Text = "1990-10-10";
            // 
            // label_blood_group
            // 
            this.label_blood_group.AutoSize = true;
            this.label_blood_group.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_blood_group.Location = new System.Drawing.Point(431, 398);
            this.label_blood_group.Name = "label_blood_group";
            this.label_blood_group.Size = new System.Drawing.Size(16, 18);
            this.label_blood_group.TabIndex = 330;
            this.label_blood_group.Text = "X";
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_age.Location = new System.Drawing.Point(431, 360);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(22, 18);
            this.label_age.TabIndex = 329;
            this.label_age.Text = "00";
            // 
            // label_birth
            // 
            this.label_birth.AutoSize = true;
            this.label_birth.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_birth.Location = new System.Drawing.Point(381, 326);
            this.label_birth.Name = "label_birth";
            this.label_birth.Size = new System.Drawing.Size(74, 18);
            this.label_birth.TabIndex = 328;
            this.label_birth.Text = "1990-10-10";
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_address.Location = new System.Drawing.Point(161, 510);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(118, 18);
            this.label_address.TabIndex = 327;
            this.label_address.Text = "Address of Donor.";
            // 
            // label_diseases
            // 
            this.label_diseases.AutoSize = true;
            this.label_diseases.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_diseases.Location = new System.Drawing.Point(161, 474);
            this.label_diseases.Name = "label_diseases";
            this.label_diseases.Size = new System.Drawing.Size(32, 18);
            this.label_diseases.TabIndex = 326;
            this.label_diseases.Text = "N/A";
            // 
            // label_city
            // 
            this.label_city.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_city.Location = new System.Drawing.Point(161, 398);
            this.label_city.Name = "label_city";
            this.label_city.Size = new System.Drawing.Size(142, 15);
            this.label_city.TabIndex = 325;
            this.label_city.Text = "DHAKA";
            // 
            // labe_email
            // 
            this.labe_email.AutoSize = true;
            this.labe_email.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe_email.Location = new System.Drawing.Point(161, 438);
            this.labe_email.Name = "labe_email";
            this.labe_email.Size = new System.Drawing.Size(163, 18);
            this.labe_email.TabIndex = 324;
            this.labe_email.Text = "someone@example.com";
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phone.Location = new System.Drawing.Point(161, 360);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(88, 18);
            this.label_phone.TabIndex = 323;
            this.label_phone.Text = "01729900XXX";
            // 
            // label_section
            // 
            this.label_section.AutoSize = true;
            this.label_section.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_section.Location = new System.Drawing.Point(161, 326);
            this.label_section.Name = "label_section";
            this.label_section.Size = new System.Drawing.Size(24, 18);
            this.label_section.TabIndex = 322;
            this.label_section.Text = "XX";
            // 
            // label_intake
            // 
            this.label_intake.AutoSize = true;
            this.label_intake.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_intake.Location = new System.Drawing.Point(161, 290);
            this.label_intake.Name = "label_intake";
            this.label_intake.Size = new System.Drawing.Size(24, 18);
            this.label_intake.TabIndex = 321;
            this.label_intake.Text = "XX";
            // 
            // label_dept
            // 
            this.label_dept.AutoSize = true;
            this.label_dept.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dept.Location = new System.Drawing.Point(161, 259);
            this.label_dept.Name = "label_dept";
            this.label_dept.Size = new System.Drawing.Size(48, 18);
            this.label_dept.TabIndex = 333;
            this.label_dept.Text = "XXXXX";
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_exit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit.ForeColor = System.Drawing.Color.White;
            this.button_exit.Location = new System.Drawing.Point(495, 570);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(90, 35);
            this.button_exit.TabIndex = 320;
            this.button_exit.Text = "BACK";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(489, 326);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 18);
            this.label9.TabIndex = 317;
            this.label9.Text = "GENDER :";
            // 
            // label_33
            // 
            this.label_33.AutoSize = true;
            this.label_33.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_33.Location = new System.Drawing.Point(489, 360);
            this.label_33.Name = "label_33";
            this.label_33.Size = new System.Drawing.Size(86, 18);
            this.label_33.TabIndex = 318;
            this.label_33.Text = "ELIGIBILITY : ";
            // 
            // label_14
            // 
            this.label_14.AutoSize = true;
            this.label_14.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_14.Location = new System.Drawing.Point(317, 360);
            this.label_14.Name = "label_14";
            this.label_14.Size = new System.Drawing.Size(41, 18);
            this.label_14.TabIndex = 316;
            this.label_14.Text = "AGE :";
            // 
            // label_31
            // 
            this.label_31.AutoSize = true;
            this.label_31.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_31.Location = new System.Drawing.Point(317, 326);
            this.label_31.Name = "label_31";
            this.label_31.Size = new System.Drawing.Size(51, 18);
            this.label_31.TabIndex = 315;
            this.label_31.Text = "BIRTH :";
            // 
            // label_7
            // 
            this.label_7.AutoSize = true;
            this.label_7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_7.Location = new System.Drawing.Point(64, 438);
            this.label_7.Name = "label_7";
            this.label_7.Size = new System.Drawing.Size(54, 18);
            this.label_7.TabIndex = 314;
            this.label_7.Text = "EMAIL :";
            // 
            // label_6
            // 
            this.label_6.AutoSize = true;
            this.label_6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_6.Location = new System.Drawing.Point(64, 360);
            this.label_6.Name = "label_6";
            this.label_6.Size = new System.Drawing.Size(59, 18);
            this.label_6.TabIndex = 313;
            this.label_6.Text = "PHONE :";
            // 
            // label_32
            // 
            this.label_32.AutoSize = true;
            this.label_32.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_32.Location = new System.Drawing.Point(489, 398);
            this.label_32.Name = "label_32";
            this.label_32.Size = new System.Drawing.Size(99, 18);
            this.label_32.TabIndex = 312;
            this.label_32.Text = "Last Donation :";
            // 
            // label_12
            // 
            this.label_12.AutoSize = true;
            this.label_12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_12.Location = new System.Drawing.Point(64, 510);
            this.label_12.Name = "label_12";
            this.label_12.Size = new System.Drawing.Size(71, 18);
            this.label_12.TabIndex = 311;
            this.label_12.Text = "ADDRESS :";
            // 
            // label_8
            // 
            this.label_8.AutoSize = true;
            this.label_8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_8.Location = new System.Drawing.Point(64, 398);
            this.label_8.Name = "label_8";
            this.label_8.Size = new System.Drawing.Size(42, 18);
            this.label_8.TabIndex = 310;
            this.label_8.Text = "CITY :";
            // 
            // label_5
            // 
            this.label_5.AutoSize = true;
            this.label_5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_5.Location = new System.Drawing.Point(64, 326);
            this.label_5.Name = "label_5";
            this.label_5.Size = new System.Drawing.Size(37, 18);
            this.label_5.TabIndex = 309;
            this.label_5.Text = "SEC :";
            // 
            // label_4
            // 
            this.label_4.AutoSize = true;
            this.label_4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_4.Location = new System.Drawing.Point(64, 290);
            this.label_4.Name = "label_4";
            this.label_4.Size = new System.Drawing.Size(59, 18);
            this.label_4.TabIndex = 308;
            this.label_4.Text = "INTAKE :";
            // 
            // label_9
            // 
            this.label_9.AutoSize = true;
            this.label_9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_9.Location = new System.Drawing.Point(64, 474);
            this.label_9.Name = "label_9";
            this.label_9.Size = new System.Drawing.Size(72, 18);
            this.label_9.TabIndex = 307;
            this.label_9.Text = "DISEASES :";
            // 
            // label_30
            // 
            this.label_30.AutoSize = true;
            this.label_30.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_30.Location = new System.Drawing.Point(317, 398);
            this.label_30.Name = "label_30";
            this.label_30.Size = new System.Drawing.Size(91, 18);
            this.label_30.TabIndex = 306;
            this.label_30.Text = "BLOOD TYPE :";
            // 
            // label_3
            // 
            this.label_3.AutoSize = true;
            this.label_3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_3.Location = new System.Drawing.Point(64, 259);
            this.label_3.Name = "label_3";
            this.label_3.Size = new System.Drawing.Size(46, 18);
            this.label_3.TabIndex = 305;
            this.label_3.Text = "DEPT :";
            // 
            // DeleteDonorProfileAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.pictureBox1_dp);
            this.Controls.Add(this.button_Next);
            this.Controls.Add(this.button_previous);
            this.Controls.Add(this.button_View);
            this.Controls.Add(this.textBox_indexID);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.label_username);
            this.Controls.Add(this.label_2);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.label_1);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_gender);
            this.Controls.Add(this.label_eligibility);
            this.Controls.Add(this.label_last_donation);
            this.Controls.Add(this.label_blood_group);
            this.Controls.Add(this.label_age);
            this.Controls.Add(this.label_birth);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.label_diseases);
            this.Controls.Add(this.label_city);
            this.Controls.Add(this.labe_email);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.label_section);
            this.Controls.Add(this.label_intake);
            this.Controls.Add(this.label_dept);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label_33);
            this.Controls.Add(this.label_14);
            this.Controls.Add(this.label_31);
            this.Controls.Add(this.label_7);
            this.Controls.Add(this.label_6);
            this.Controls.Add(this.label_32);
            this.Controls.Add(this.label_12);
            this.Controls.Add(this.label_8);
            this.Controls.Add(this.label_5);
            this.Controls.Add(this.label_4);
            this.Controls.Add(this.label_9);
            this.Controls.Add(this.label_30);
            this.Controls.Add(this.label_3);
            this.Name = "DeleteDonorProfileAdmin";
            this.Text = "Admin CP delete donor";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.PictureBox pictureBox1_dp;
        private System.Windows.Forms.Button button_Next;
        private System.Windows.Forms.Button button_previous;
        private System.Windows.Forms.Button button_View;
        public System.Windows.Forms.TextBox textBox_indexID;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label_id;
        public System.Windows.Forms.Label label_username;
        private System.Windows.Forms.Label label_2;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_1;
        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label_gender;
        public System.Windows.Forms.Label label_eligibility;
        public System.Windows.Forms.Label label_last_donation;
        public System.Windows.Forms.Label label_blood_group;
        public System.Windows.Forms.Label label_age;
        public System.Windows.Forms.Label label_birth;
        public System.Windows.Forms.Label label_address;
        public System.Windows.Forms.Label label_diseases;
        public System.Windows.Forms.Label label_city;
        public System.Windows.Forms.Label labe_email;
        public System.Windows.Forms.Label label_phone;
        public System.Windows.Forms.Label label_section;
        public System.Windows.Forms.Label label_intake;
        public System.Windows.Forms.Label label_dept;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_33;
        private System.Windows.Forms.Label label_14;
        private System.Windows.Forms.Label label_31;
        private System.Windows.Forms.Label label_7;
        private System.Windows.Forms.Label label_6;
        private System.Windows.Forms.Label label_32;
        private System.Windows.Forms.Label label_12;
        private System.Windows.Forms.Label label_8;
        private System.Windows.Forms.Label label_5;
        private System.Windows.Forms.Label label_4;
        private System.Windows.Forms.Label label_9;
        private System.Windows.Forms.Label label_30;
        private System.Windows.Forms.Label label_3;
    }
}