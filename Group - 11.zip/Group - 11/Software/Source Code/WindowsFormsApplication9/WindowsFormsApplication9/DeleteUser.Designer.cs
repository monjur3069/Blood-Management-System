﻿namespace WindowsFormsApplication9
{
    partial class DeleteUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_change_pwd = new System.Windows.Forms.Button();
            this.textBox_check_username = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_change_pwd
            // 
            this.button_change_pwd.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_change_pwd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_change_pwd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_change_pwd.ForeColor = System.Drawing.Color.DarkRed;
            this.button_change_pwd.Location = new System.Drawing.Point(509, 277);
            this.button_change_pwd.Name = "button_change_pwd";
            this.button_change_pwd.Size = new System.Drawing.Size(90, 35);
            this.button_change_pwd.TabIndex = 41;
            this.button_change_pwd.Text = "DELETE";
            this.button_change_pwd.UseVisualStyleBackColor = false;
            this.button_change_pwd.Click += new System.EventHandler(this.button_change_pwd_Click);
            // 
            // textBox_check_username
            // 
            this.textBox_check_username.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_check_username.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_check_username.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_check_username.Location = new System.Drawing.Point(256, 282);
            this.textBox_check_username.MaxLength = 20;
            this.textBox_check_username.Name = "textBox_check_username";
            this.textBox_check_username.Size = new System.Drawing.Size(197, 27);
            this.textBox_check_username.TabIndex = 40;
            this.textBox_check_username.Text = "Enter username";
            this.textBox_check_username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_check_username.Enter += new System.EventHandler(this.textBox_check_username_Enter);
            this.textBox_check_username.Leave += new System.EventHandler(this.textBox_check_username_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(101, 285);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 19);
            this.label4.TabIndex = 37;
            this.label4.Text = "USERNAME :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.Color.Green;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(387, 12);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(201, 40);
            this.button_admin_cp.TabIndex = 33;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Green;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(594, 11);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 34;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(369, 40);
            this.button_home.TabIndex = 32;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(12, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(678, 25);
            this.label3.TabIndex = 29;
            this.label3.Text = "DELETE USER";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(11, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(680, 28);
            this.label2.TabIndex = 30;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(11, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 32);
            this.label1.TabIndex = 31;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DeleteUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button_change_pwd);
            this.Controls.Add(this.textBox_check_username);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "DeleteUser";
            this.Text = "Admin CP Delete user";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_change_pwd;
        private System.Windows.Forms.TextBox textBox_check_username;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}