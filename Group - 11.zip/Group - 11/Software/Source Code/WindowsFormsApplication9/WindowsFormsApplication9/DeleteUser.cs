﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class DeleteUser : Form
    {
        public DeleteUser()
        {
            InitializeComponent();
        }

        private void button_change_pwd_Click(object sender, EventArgs e)
        {
            DeleteUSer();
        }

        private void DeleteUSer()
        {

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            string username = textBox_check_username.Text.Trim().ToString();
            string testUserName = null;

            if(!string.IsNullOrEmpty(username) && (username != "Enter username"))
            {
                try
                {
                    // taking textbox input into username and password variable.


                    // checking if username field is empty
                    if (!string.IsNullOrEmpty(username))
                    {

                        conn.Open();

                        DataTable dt = new DataTable();
                        MySqlDataReader myReader = null;
                        MySqlCommand myCommand = new MySqlCommand("select username from userlogin where username = '" + username + "' ", conn);
                        myReader = myCommand.ExecuteReader();
                        while (myReader.Read())
                        {
                            testUserName = (myReader["username"].ToString().Trim());

                        }
                        if (username == testUserName)
                        {
                            //myCommand.Cancel();
                            myReader.Close();
                            // MySqlCommand with reader has to be closed first before using another command.
                            MySqlCommand cmd = conn.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "DELETE FROM userlogin WHERE username = '" + username + "' ";
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Username " + username + " has been DELETED!");

                            textBox_check_username.Clear();

                            conn.Close();

                        }
                        else
                        {
                            conn.Close();
                            MessageBox.Show("Username " + username + " not found!");
                        }

                    }

                    else
                    {
                        MessageBox.Show("Empty Field. Input Value");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("input username!");
            }

        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_add_user_Click(object sender, EventArgs e)
        {

        }

        private void textBox_check_username_Enter(object sender, EventArgs e)
        {
            if(textBox_check_username.Text == "Enter username")
            {
                textBox_check_username.Text = "";
                textBox_check_username.ForeColor = Color.Black;
            }
        }

        private void textBox_check_username_Leave(object sender, EventArgs e)
        {
            if (textBox_check_username.Text == "")
            {
                textBox_check_username.Text = "Enter username";
                textBox_check_username.ForeColor = Color.Gray;
            }
        }
    }
}
