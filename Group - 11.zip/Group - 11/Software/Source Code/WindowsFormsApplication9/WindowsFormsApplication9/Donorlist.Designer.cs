﻿namespace WindowsFormsApplication9
{
    partial class Donorlist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView_donor_list = new System.Windows.Forms.DataGridView();
            this.button_home = new System.Windows.Forms.Button();
            this.button_home2 = new System.Windows.Forms.Button();
            this.button_donorlist_donorlist = new System.Windows.Forms.Button();
            this.button_login = new System.Windows.Forms.Button();
            this.combo_searh_eligibleDonor = new System.Windows.Forms.ComboBox();
            this.button_search = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_donor_list)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(10, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(682, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(10, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(682, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(10, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(682, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Our Donor List";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label2_Click);
            // 
            // dataGridView_donor_list
            // 
            this.dataGridView_donor_list.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView_donor_list.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_donor_list.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_donor_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_donor_list.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_donor_list.Location = new System.Drawing.Point(10, 253);
            this.dataGridView_donor_list.Name = "dataGridView_donor_list";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_donor_list.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_donor_list.Size = new System.Drawing.Size(682, 356);
            this.dataGridView_donor_list.TabIndex = 1;
            this.dataGridView_donor_list.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(66, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(293, 40);
            this.button_home.TabIndex = 2;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            this.button_home.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_home2
            // 
            this.button_home2.BackColor = System.Drawing.Color.Green;
            this.button_home2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_home2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home2.ForeColor = System.Drawing.Color.White;
            this.button_home2.Location = new System.Drawing.Point(366, 12);
            this.button_home2.Name = "button_home2";
            this.button_home2.Size = new System.Drawing.Size(82, 40);
            this.button_home2.TabIndex = 3;
            this.button_home2.Text = "Home";
            this.button_home2.UseVisualStyleBackColor = false;
            this.button_home2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_donorlist_donorlist
            // 
            this.button_donorlist_donorlist.BackColor = System.Drawing.Color.Green;
            this.button_donorlist_donorlist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_donorlist_donorlist.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_donorlist_donorlist.ForeColor = System.Drawing.Color.White;
            this.button_donorlist_donorlist.Location = new System.Drawing.Point(454, 12);
            this.button_donorlist_donorlist.Name = "button_donorlist_donorlist";
            this.button_donorlist_donorlist.Size = new System.Drawing.Size(94, 40);
            this.button_donorlist_donorlist.TabIndex = 3;
            this.button_donorlist_donorlist.Text = "Signup";
            this.button_donorlist_donorlist.UseVisualStyleBackColor = false;
            this.button_donorlist_donorlist.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_login
            // 
            this.button_login.BackColor = System.Drawing.Color.Green;
            this.button_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_login.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_login.ForeColor = System.Drawing.Color.White;
            this.button_login.Location = new System.Drawing.Point(554, 12);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(82, 40);
            this.button_login.TabIndex = 3;
            this.button_login.Text = "Log In";
            this.button_login.UseVisualStyleBackColor = false;
            this.button_login.Click += new System.EventHandler(this.button4_Click);
            // 
            // combo_searh_eligibleDonor
            // 
            this.combo_searh_eligibleDonor.BackColor = System.Drawing.SystemColors.Info;
            this.combo_searh_eligibleDonor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_searh_eligibleDonor.ForeColor = System.Drawing.SystemColors.GrayText;
            this.combo_searh_eligibleDonor.FormattingEnabled = true;
            this.combo_searh_eligibleDonor.Items.AddRange(new object[] {
            "  A+",
            "  B+",
            "  O+",
            "  AB+",
            "  A-",
            "  B-",
            "  O-",
            "  AB-",
            "  Other"});
            this.combo_searh_eligibleDonor.Location = new System.Drawing.Point(10, 208);
            this.combo_searh_eligibleDonor.Name = "combo_searh_eligibleDonor";
            this.combo_searh_eligibleDonor.Size = new System.Drawing.Size(538, 27);
            this.combo_searh_eligibleDonor.TabIndex = 4;
            this.combo_searh_eligibleDonor.Text = "Select Blood Group";
            this.combo_searh_eligibleDonor.SelectedIndexChanged += new System.EventHandler(this.combo_searh_eligibleDonor_SelectedIndexChanged);
            this.combo_searh_eligibleDonor.Enter += new System.EventHandler(this.combo_searh_eligibleDonor_Enter);
            this.combo_searh_eligibleDonor.Leave += new System.EventHandler(this.combo_searh_eligibleDonor_Leave);
            // 
            // button_search
            // 
            this.button_search.BackColor = System.Drawing.Color.AliceBlue;
            this.button_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_search.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_search.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button_search.Location = new System.Drawing.Point(594, 204);
            this.button_search.Name = "button_search";
            this.button_search.Size = new System.Drawing.Size(98, 33);
            this.button_search.TabIndex = 5;
            this.button_search.Text = "Search";
            this.button_search.UseVisualStyleBackColor = false;
            this.button_search.Click += new System.EventHandler(this.button_search_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(10, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "SEARCH ELIGIBLE DONOR";
            // 
            // Donorlist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_search);
            this.Controls.Add(this.combo_searh_eligibleDonor);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.button_donorlist_donorlist);
            this.Controls.Add(this.button_home2);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.dataGridView_donor_list);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Name = "Donorlist";
            this.Text = "Donor List";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_donor_list)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.DataGridView dataGridView_donor_list;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Button button_home2;
        private System.Windows.Forms.Button button_donorlist_donorlist;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.ComboBox combo_searh_eligibleDonor;
        private System.Windows.Forms.Button button_search;
        private System.Windows.Forms.Label label4;
    }
}