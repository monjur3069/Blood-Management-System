﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Donorlist : Form
    {
        public Donorlist()
        {
            InitializeComponent();
        }

        
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);
            this.Hide();
            
            home.ShowDialog();
            this.Close();
        }
        
        
        private void button3_Click(object sender, EventArgs e)
        {

            Signup signup = new Signup();
            signup.Width = this.Width;
            signup.Height = this.Height;
            signup.StartPosition = FormStartPosition.Manual;
            signup.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            signup.ShowDialog();
            this.Close();

            //DonorList(); Changed button to sign up
        }
       
        private void button4_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

                      
        private void EligibleDonorList()
        {
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            
            try
               { 
                   // string bloodType = combo_searh_eligibleDonor.SelectedItem.ToString().Trim().ToUpper();
                   // if (!string.IsNullOrEmpty(bloodType))
                   if(combo_searh_eligibleDonor.SelectedIndex!=-1)
                    {
                        string bloodType = combo_searh_eligibleDonor.SelectedItem.ToString().Trim().ToUpper();
                        conn.Open();
                        MySqlCommand query = conn.CreateCommand();
                        query.CommandType = CommandType.Text;

                        query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable where Eligibility = 'YES' and Blood_Group = '" + bloodType + "'  ";
                        //create adaptor to fill data from database
                        MySqlDataAdapter da = new MySqlDataAdapter(query);
                        //create datatable which holds the data
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        //bind your data to gridview
                        dataGridView_donor_list.DataSource = dt;
                        // dataGridView1.DataBind();
                                            
                        query.ExecuteNonQuery();
                        conn.Close();
                    }
                    else
                    {
                        combo_searh_eligibleDonor.Text = "Select Blood Group";
                        MessageBox.Show("SELECT BLOOD GROUP!");
                    }

                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        

        private void button_search_Click(object sender, EventArgs e)
        {
            EligibleDonorList();
        }

        private void combo_searh_eligibleDonor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void combo_searh_eligibleDonor_Enter(object sender, EventArgs e)
        {
            if(combo_searh_eligibleDonor.Text == "Select Blood Group")
            {
                combo_searh_eligibleDonor.Text = "";
                combo_searh_eligibleDonor.ForeColor = Color.Black;
            }
        }

        private void combo_searh_eligibleDonor_Leave(object sender, EventArgs e)
        {
            if (combo_searh_eligibleDonor.Text == "")
            {
                combo_searh_eligibleDonor.Text = "Select Blood Group";
                combo_searh_eligibleDonor.ForeColor = Color.Gray;
            }
        }
    }
}
