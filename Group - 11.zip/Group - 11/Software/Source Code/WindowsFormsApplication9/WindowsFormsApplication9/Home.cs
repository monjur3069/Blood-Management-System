﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// CODED BY TEAM 0000, BUBT, CSE. 
/// </summary>

namespace WindowsFormsApplication9
{
    public partial class Home : Form
    {

        public Home()
        {
            InitializeComponent();
            
        }
       
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Home home = new Home();
            Adminlogin adminlogin = new Adminlogin();

            adminlogin.Width = this.Width;
            adminlogin.Height = this.Height;

            adminlogin.StartPosition = FormStartPosition.Manual;
            adminlogin.Location = new Point(this.Location.X, this.Location.Y);

            //this.Visible = false;
            this.Hide();
            adminlogin.ShowDialog();
            this.Close();
            //this.Hide();
            //this.Visible = true;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Userlogin ulogin = new Userlogin();

            ulogin.Width = this.Width;
            ulogin.Height = this.Height;
            ulogin.StartPosition = FormStartPosition.Manual;
            ulogin.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            ulogin.ShowDialog();
            this.Close();

        }

        private void button_home2_Click(object sender, EventArgs e)
        {
            /*  
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
            */
        }


        private void button_donorlist_Click(object sender, EventArgs e)
        {
            Donorlist d = new Donorlist();
            d.Width = this.Width;
            d.Height = this.Height;
            d.StartPosition = FormStartPosition.Manual;
            d.Location = new Point(this.Location.X, this.Location.Y);
            //d.dataGridView_donor_list = new DataGridView();
           // d.dataGridView_donor_list.Enabled = true;
            //d.dataGridView_donor_list.Visible = true;

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                conn.Open();
                MySqlCommand query = conn.CreateCommand();
                query.CommandType = CommandType.Text;

                query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable";
                //create adaptor to fill data from database
                MySqlDataAdapter da = new MySqlDataAdapter(query);
                //create datatable which holds the data
                DataTable dt = new DataTable();
                da.Fill(dt);
                //bind your data to gridview
                d.dataGridView_donor_list.DataSource = dt;
                // dataGridView1.DataBind();



                query.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



            this.Hide();
            d.ShowDialog();
            this.Close();

        }

        

        private void button_home_Click(object sender, EventArgs e)
        {

        }

        private void button_login_Click(object sender, EventArgs e)
        {
            Signup signup = new Signup();
            signup.Width = this.Width;
            signup.Height = this.Height;
            signup.StartPosition = FormStartPosition.Manual;
            signup.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            signup.ShowDialog();
            this.Close();
        }

        

        private void label3_Click_1(object sender, EventArgs e)
        {
            DEVELOPERS devp = new DEVELOPERS();
            devp.Width = this.Width;
            devp.Height = this.Height;
            devp.StartPosition = FormStartPosition.Manual;
            devp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            devp.ShowDialog();
            this.Close();
        }
    }
}
