﻿namespace WindowsFormsApplication9
{
    partial class Patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Patient));
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_gender = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.text_age = new System.Windows.Forms.TextBox();
            this.label_age = new System.Windows.Forms.Label();
            this.dateTimePicker_birthday = new System.Windows.Forms.DateTimePicker();
            this.text_address = new System.Windows.Forms.TextBox();
            this.label_address = new System.Windows.Forms.Label();
            this.text_email = new System.Windows.Forms.TextBox();
            this.label_birthday = new System.Windows.Forms.Label();
            this.label_emali = new System.Windows.Forms.Label();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.label_phone = new System.Windows.Forms.Label();
            this.text_city = new System.Windows.Forms.TextBox();
            this.label_city = new System.Windows.Forms.Label();
            this.comboBox_bloodtype = new System.Windows.Forms.ComboBox();
            this.label_diseases = new System.Windows.Forms.Label();
            this.label_bloodtype = new System.Windows.Forms.Label();
            this.text_diseases = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.label_name = new System.Windows.Forms.Label();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.button_save = new System.Windows.Forms.Button();
            this.button_uploadimage = new System.Windows.Forms.Button();
            this.pictureBox1_dp = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).BeginInit();
            this.SuspendLayout();
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.Color.Green;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(387, 12);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(201, 40);
            this.button_admin_cp.TabIndex = 37;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Green;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(594, 11);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 38;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(369, 40);
            this.button_home.TabIndex = 36;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(11, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 32);
            this.label1.TabIndex = 35;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(12, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(680, 32);
            this.label2.TabIndex = 35;
            this.label2.Text = "PATIENT INFORMATION";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox_gender
            // 
            this.comboBox_gender.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_gender.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_gender.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_gender.FormattingEnabled = true;
            this.comboBox_gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.comboBox_gender.Location = new System.Drawing.Point(509, 444);
            this.comboBox_gender.Name = "comboBox_gender";
            this.comboBox_gender.Size = new System.Drawing.Size(125, 27);
            this.comboBox_gender.TabIndex = 234;
            this.comboBox_gender.Text = "Select";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(428, 449);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 15);
            this.label9.TabIndex = 233;
            this.label9.Text = "Gender";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(474, 445);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 26);
            this.label10.TabIndex = 227;
            this.label10.Text = "*";
            this.label10.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(169, 449);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 26);
            this.label5.TabIndex = 228;
            this.label5.Text = "*";
            this.label5.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(169, 352);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 26);
            this.label3.TabIndex = 229;
            this.label3.Text = "*";
            this.label3.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(169, 305);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 26);
            this.label7.TabIndex = 230;
            this.label7.Text = "*";
            this.label7.Visible = false;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(169, 221);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 26);
            this.label11.TabIndex = 231;
            this.label11.Text = "*";
            this.label11.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(169, 176);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 26);
            this.label12.TabIndex = 232;
            this.label12.Text = "*";
            this.label12.Visible = false;
            // 
            // text_age
            // 
            this.text_age.BackColor = System.Drawing.SystemColors.Info;
            this.text_age.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_age.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_age.Location = new System.Drawing.Point(418, 347);
            this.text_age.Name = "text_age";
            this.text_age.Size = new System.Drawing.Size(71, 27);
            this.text_age.TabIndex = 222;
            this.text_age.Text = "auto";
            this.text_age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_age.Enter += new System.EventHandler(this.text_age_Enter);
            this.text_age.Leave += new System.EventHandler(this.text_age_Leave);
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_age.Location = new System.Drawing.Point(328, 353);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(36, 15);
            this.label_age.TabIndex = 221;
            this.label_age.Text = "AGE :";
            // 
            // dateTimePicker_birthday
            // 
            this.dateTimePicker_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_birthday.Location = new System.Drawing.Point(197, 305);
            this.dateTimePicker_birthday.Name = "dateTimePicker_birthday";
            this.dateTimePicker_birthday.Size = new System.Drawing.Size(216, 23);
            this.dateTimePicker_birthday.TabIndex = 220;
            // 
            // text_address
            // 
            this.text_address.BackColor = System.Drawing.SystemColors.Info;
            this.text_address.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_address.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_address.Location = new System.Drawing.Point(197, 399);
            this.text_address.Name = "text_address";
            this.text_address.Size = new System.Drawing.Size(437, 27);
            this.text_address.TabIndex = 215;
            this.text_address.Text = "Enter your full adress";
            this.text_address.Enter += new System.EventHandler(this.text_address_Enter);
            this.text_address.Leave += new System.EventHandler(this.text_address_Leave);
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_address.Location = new System.Drawing.Point(71, 405);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(63, 15);
            this.label_address.TabIndex = 214;
            this.label_address.Text = "ADDRESS :";
            // 
            // text_email
            // 
            this.text_email.BackColor = System.Drawing.SystemColors.Info;
            this.text_email.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_email.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_email.Location = new System.Drawing.Point(197, 260);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(177, 27);
            this.text_email.TabIndex = 212;
            this.text_email.Text = "someone@example.com";
            this.text_email.Enter += new System.EventHandler(this.text_email_Enter);
            this.text_email.Leave += new System.EventHandler(this.text_email_Leave);
            // 
            // label_birthday
            // 
            this.label_birthday.AutoSize = true;
            this.label_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_birthday.Location = new System.Drawing.Point(73, 311);
            this.label_birthday.Name = "label_birthday";
            this.label_birthday.Size = new System.Drawing.Size(41, 15);
            this.label_birthday.TabIndex = 211;
            this.label_birthday.Text = "Birth :";
            // 
            // label_emali
            // 
            this.label_emali.AutoSize = true;
            this.label_emali.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_emali.Location = new System.Drawing.Point(73, 266);
            this.label_emali.Name = "label_emali";
            this.label_emali.Size = new System.Drawing.Size(48, 15);
            this.label_emali.TabIndex = 210;
            this.label_emali.Text = "EMAIL :";
            // 
            // text_phone
            // 
            this.text_phone.BackColor = System.Drawing.SystemColors.Info;
            this.text_phone.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_phone.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_phone.Location = new System.Drawing.Point(197, 215);
            this.text_phone.Name = "text_phone";
            this.text_phone.Size = new System.Drawing.Size(177, 27);
            this.text_phone.TabIndex = 213;
            this.text_phone.Text = "01700000XXX";
            this.text_phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_phone.Enter += new System.EventHandler(this.text_phone_Enter);
            this.text_phone.Leave += new System.EventHandler(this.text_phone_Leave);
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phone.Location = new System.Drawing.Point(70, 221);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(53, 15);
            this.label_phone.TabIndex = 209;
            this.label_phone.Text = "PHONE :";
            // 
            // text_city
            // 
            this.text_city.BackColor = System.Drawing.SystemColors.Info;
            this.text_city.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_city.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_city.Location = new System.Drawing.Point(197, 347);
            this.text_city.Name = "text_city";
            this.text_city.Size = new System.Drawing.Size(90, 27);
            this.text_city.TabIndex = 208;
            this.text_city.Text = "your city";
            this.text_city.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_city.Enter += new System.EventHandler(this.text_city_Enter);
            this.text_city.Leave += new System.EventHandler(this.text_city_Leave);
            // 
            // label_city
            // 
            this.label_city.AutoSize = true;
            this.label_city.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_city.Location = new System.Drawing.Point(71, 353);
            this.label_city.Name = "label_city";
            this.label_city.Size = new System.Drawing.Size(37, 15);
            this.label_city.TabIndex = 205;
            this.label_city.Text = "CITY :";
            // 
            // comboBox_bloodtype
            // 
            this.comboBox_bloodtype.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_bloodtype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_bloodtype.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_bloodtype.FormattingEnabled = true;
            this.comboBox_bloodtype.Items.AddRange(new object[] {
            "A+",
            "B+",
            "O+",
            "AB+",
            "A-",
            "B-",
            "O-",
            "AB-",
            "Other"});
            this.comboBox_bloodtype.Location = new System.Drawing.Point(197, 445);
            this.comboBox_bloodtype.Name = "comboBox_bloodtype";
            this.comboBox_bloodtype.Size = new System.Drawing.Size(108, 27);
            this.comboBox_bloodtype.TabIndex = 202;
            this.comboBox_bloodtype.Text = "Blood Group";
            // 
            // label_diseases
            // 
            this.label_diseases.AutoSize = true;
            this.label_diseases.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_diseases.Location = new System.Drawing.Point(71, 497);
            this.label_diseases.Name = "label_diseases";
            this.label_diseases.Size = new System.Drawing.Size(103, 15);
            this.label_diseases.TabIndex = 199;
            this.label_diseases.Text = "DISEASES (if any) :";
            // 
            // label_bloodtype
            // 
            this.label_bloodtype.AutoSize = true;
            this.label_bloodtype.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bloodtype.Location = new System.Drawing.Point(71, 451);
            this.label_bloodtype.Name = "label_bloodtype";
            this.label_bloodtype.Size = new System.Drawing.Size(82, 15);
            this.label_bloodtype.TabIndex = 198;
            this.label_bloodtype.Text = "BLOOD TYPE :";
            // 
            // text_diseases
            // 
            this.text_diseases.BackColor = System.Drawing.SystemColors.Info;
            this.text_diseases.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_diseases.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_diseases.Location = new System.Drawing.Point(197, 491);
            this.text_diseases.Name = "text_diseases";
            this.text_diseases.Size = new System.Drawing.Size(437, 27);
            this.text_diseases.TabIndex = 196;
            this.text_diseases.Text = "name of disease";
            this.text_diseases.Enter += new System.EventHandler(this.text_diseases_Enter);
            this.text_diseases.Leave += new System.EventHandler(this.text_diseases_Leave);
            // 
            // text_name
            // 
            this.text_name.BackColor = System.Drawing.SystemColors.Info;
            this.text_name.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_name.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_name.Location = new System.Drawing.Point(197, 170);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(299, 27);
            this.text_name.TabIndex = 195;
            this.text_name.Text = "Enter your full name";
            this.text_name.Enter += new System.EventHandler(this.text_name_Enter);
            this.text_name.Leave += new System.EventHandler(this.text_name_Leave);
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.Location = new System.Drawing.Point(71, 176);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(48, 15);
            this.label_name.TabIndex = 192;
            this.label_name.Text = "NAME :";
            // 
            // button_clear
            // 
            this.button_clear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear.ForeColor = System.Drawing.Color.White;
            this.button_clear.Location = new System.Drawing.Point(448, 555);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(90, 35);
            this.button_clear.TabIndex = 237;
            this.button_clear.Text = "CLEAR";
            this.button_clear.UseVisualStyleBackColor = false;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.SteelBlue;
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update.ForeColor = System.Drawing.Color.White;
            this.button_update.Location = new System.Drawing.Point(544, 555);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(90, 35);
            this.button_update.TabIndex = 236;
            this.button_update.Text = "EXIT";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.Green;
            this.button_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_save.ForeColor = System.Drawing.Color.White;
            this.button_save.Location = new System.Drawing.Point(352, 555);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(90, 35);
            this.button_save.TabIndex = 235;
            this.button_save.Text = "SAVE";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_uploadimage
            // 
            this.button_uploadimage.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_uploadimage.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uploadimage.ForeColor = System.Drawing.Color.GhostWhite;
            this.button_uploadimage.Location = new System.Drawing.Point(537, 305);
            this.button_uploadimage.Name = "button_uploadimage";
            this.button_uploadimage.Size = new System.Drawing.Size(97, 36);
            this.button_uploadimage.TabIndex = 299;
            this.button_uploadimage.Text = "UPLOAD";
            this.button_uploadimage.UseVisualStyleBackColor = false;
            this.button_uploadimage.Click += new System.EventHandler(this.button_uploadimage_Click);
            // 
            // pictureBox1_dp
            // 
            this.pictureBox1_dp.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox1_dp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_dp.Image")));
            this.pictureBox1_dp.Location = new System.Drawing.Point(536, 161);
            this.pictureBox1_dp.Name = "pictureBox1_dp";
            this.pictureBox1_dp.Padding = new System.Windows.Forms.Padding(3);
            this.pictureBox1_dp.Size = new System.Drawing.Size(98, 126);
            this.pictureBox1_dp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_dp.TabIndex = 298;
            this.pictureBox1_dp.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(520, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 15);
            this.label4.TabIndex = 192;
            this.label4.Text = "Passport : 35 x 45mm";
            // 
            // Patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button_uploadimage);
            this.Controls.Add(this.pictureBox1_dp);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.button_save);
            this.Controls.Add(this.comboBox_gender);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.text_age);
            this.Controls.Add(this.label_age);
            this.Controls.Add(this.dateTimePicker_birthday);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.text_email);
            this.Controls.Add(this.label_birthday);
            this.Controls.Add(this.label_emali);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.text_city);
            this.Controls.Add(this.label_city);
            this.Controls.Add(this.comboBox_bloodtype);
            this.Controls.Add(this.label_diseases);
            this.Controls.Add(this.label_bloodtype);
            this.Controls.Add(this.text_diseases);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Patient";
            this.Text = " Admin CP Reg Patient";
            this.Load += new System.EventHandler(this.Patient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_gender;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox text_age;
        private System.Windows.Forms.Label label_age;
        public System.Windows.Forms.DateTimePicker dateTimePicker_birthday;
        private System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.Label label_address;
        private System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.Label label_birthday;
        private System.Windows.Forms.Label label_emali;
        private System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Label label_phone;
        private System.Windows.Forms.TextBox text_city;
        private System.Windows.Forms.Label label_city;
        private System.Windows.Forms.ComboBox comboBox_bloodtype;
        private System.Windows.Forms.Label label_diseases;
        private System.Windows.Forms.Label label_bloodtype;
        private System.Windows.Forms.TextBox text_diseases;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_uploadimage;
        private System.Windows.Forms.PictureBox pictureBox1_dp;
        private System.Windows.Forms.Label label4;
    }
}