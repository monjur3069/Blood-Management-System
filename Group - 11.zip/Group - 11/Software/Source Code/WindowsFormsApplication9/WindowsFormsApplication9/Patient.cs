﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Patient : Form
    {

        private string tempImagePath = null;

        public Patient()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            patient_info();
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            text_name.Clear();
           
            //combo_dept combo box
            
            text_phone.Clear();
            text_email.Clear();
            //Birth_Day and donationDay reset
            //dateTimePicker_birthday.Value = DateTime.Now;
            //dateTimePicker_lastdonation.Value = DateTime.Now;
            DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
            dateTimePicker_birthday.Value = setBirthDayTime;
        
            text_age.Text = "auto";
            text_city.Clear();
            text_address.Clear();
            // Blood_Group combo box
            comboBox_bloodtype.Text = "Blood Group";
            comboBox_gender.Text = "Select";
            

            text_diseases.Clear();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void patient_info()
        {
            // database connection string
            string ConnectString = ConnectionString.connString;
            //string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                if ((comboBox_bloodtype.SelectedIndex != -1)  && (comboBox_gender.SelectedIndex != -1))
                {
                    // declearing local variable for input
                    //user name contain both login info table and personalinfotable for userREGbyUser to protect user to stop filling multiple form.
                    
                    string Patient_Name = text_name.Text.Trim();
                    string Phone_No = text_phone.Text.Trim().ToString();
                    string Email_ID = text_email.Text.Trim().ToString().ToLower();
                    string Birth_Day = birthday().ToString().ToUpper();
                    string Age = ageCalculation().ToString();
                    string City = text_city.Text.Trim().ToString().ToUpper();
                    string Address = text_address.Text.Trim().ToString();
                    string Blood_Group = comboBox_bloodtype.SelectedItem.ToString().Trim().ToUpper();
                    string Gender = comboBox_gender.SelectedItem.ToString().Trim();
                    string Diseases = text_diseases.Text.Trim().ToString();
                    string imgpathdonor = tempImagePath;
                    tempImagePath = null;

                    // checking if specific fields are empty
                    if (!string.IsNullOrEmpty(Patient_Name) && !string.IsNullOrEmpty(Gender) && (Patient_Name != "Enter your full name")
                        && !string.IsNullOrEmpty(Phone_No) && !string.IsNullOrEmpty(Birth_Day) && (Phone_No != "01700000XXX")
                        && !string.IsNullOrEmpty(Age) && !string.IsNullOrEmpty(City) && (City != "your city")
                        && !string.IsNullOrEmpty(Blood_Group))

                    {
                        //opening connection
                        conn.Open();
                        MySqlCommand cmd = conn.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "insert into patient values ('','" + Patient_Name + "', '" + Phone_No + "', '" + Email_ID + "', '" + Birth_Day + "', '" + City + "', '" + Age + "', '" + Address + "', '" + Blood_Group + "', '" + Gender + "' , '" + Diseases + "', imgNamednr = '" + imgpathdonor + "'  )";
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Registration Successful!");

                        Admincp admincp = new Admincp();
                        admincp.Width = this.Width;
                        admincp.Height = this.Height;
                        admincp.StartPosition = FormStartPosition.Manual;
                        admincp.Location = new Point(this.Location.X, this.Location.Y);

                        this.Hide();
                        admincp.ShowDialog();
                        this.Close();


                    }

                    else
                    {
                        label1.Visible = true;
                        label2.Visible = true;
                        label3.Visible = true;
                        
                        label5.Visible = true;
                        label11.Visible = true;
                        label12.Visible = true;

                        label7.Visible = true;
                        MessageBox.Show("Selected Field Can't be Empty!");
                    }
                }
                else
                {
                    label1.Visible = true;
                    label2.Visible = true;
                    label3.Visible = true;
                    label11.Visible = true;
                    label12.Visible = true;
                    label5.Visible = true;
                    
                    label7.Visible = true;
                    
                    label10.Visible = true;


                    MessageBox.Show("Complete Selected Fields!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private string birthday()
        {
            string birthDate = dateTimePicker_birthday.Value.ToString("yyyy-MM-dd");
            return birthDate;
        }

        
        private int ageCalculation()
        {
            // TimeSpan age = DateTime.Now - dateTimePicker_birthday.Value;

            int age = DateTime.Now.Year - dateTimePicker_birthday.Value.Year - (DateTime.Now.DayOfYear < dateTimePicker_birthday.Value.DayOfYear ? 1 : 0);
            return age;

            /*int years = DateTime.Now.Year - dateTimePicker.Value.Year;

            if (dateTimePicker.Value.AddYears(years) > DateTime.Now) years--; */
        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }


        private void text_name_Enter(object sender, EventArgs e)
        {
            if (text_name.Text == "Enter your full name")
            {
                text_name.Text = "";
                text_name.ForeColor = Color.Black;
            }
        }

        private void text_name_Leave(object sender, EventArgs e)
        {
            if (text_name.Text == "")
            {
                text_name.Text = "Enter your full name";
                text_name.ForeColor = Color.Gray;
            }
        }

        

        

        private void text_email_Enter(object sender, EventArgs e)
        {
            if (text_email.Text == "someone@example.com")
            {
                text_email.Text = "";
                text_email.ForeColor = Color.Black;
            }
        }

        private void text_email_Leave(object sender, EventArgs e)
        {
            if (text_email.Text == "")
            {
                text_email.Text = "someone@example.com";
                text_email.ForeColor = Color.Gray;
            }
        }

        

        

        private void text_phone_Enter(object sender, EventArgs e)
        {
            if (text_phone.Text == "01700000XXX")
            {
                text_phone.Text = "";
                text_phone.ForeColor = Color.Black;
            }
        }

        private void text_phone_Leave(object sender, EventArgs e)
        {
            if (text_phone.Text == "")
            {
                text_phone.Text = "01700000XXX";
                text_phone.ForeColor = Color.Gray;
            }
        }

       

        

        private void text_city_Enter(object sender, EventArgs e)
        {
            if (text_city.Text == "your city")
            {
                text_city.Text = "";
                text_city.ForeColor = Color.Black;
            }
        }

        private void text_city_Leave(object sender, EventArgs e)
        {
            if (text_city.Text == "")
            {
                text_city.Text = "your city";
                text_city.ForeColor = Color.Gray;
            }
        }

        private void text_age_Enter(object sender, EventArgs e)
        {
            if (text_age.Text == "auto")
            {
                text_age.Text = "";
                text_age.ForeColor = Color.Black;
            }
        }

        private void text_age_Leave(object sender, EventArgs e)
        {
            if (text_age.Text == "")
            {
                text_age.Text = "auto";
                text_age.ForeColor = Color.Gray;
            }
        }

       

       private void text_address_Enter(object sender, EventArgs e)
        {
            if (text_address.Text == "Enter your full adress")
            {
                text_address.Text = "";
                text_address.ForeColor = Color.Black;
            }
        }

        private void text_address_Leave(object sender, EventArgs e)
        {
            if (text_address.Text == "")
            {
                text_address.Text = "Enter your full adress";
                text_address.ForeColor = Color.Gray;
            }
        }

        private void text_diseases_Enter(object sender, EventArgs e)
        {
            if (text_diseases.Text == "name of disease")
            {
                text_diseases.Text = "";
                text_diseases.ForeColor = Color.Black;
            }
        }

        private void text_diseases_Leave(object sender, EventArgs e)
        {
            if (text_diseases.Text == "")
            {
                text_diseases.Text = "name of disease";
                text_diseases.ForeColor = Color.Gray;
            }
        }

        private void Patient_Load(object sender, EventArgs e)
        {

        }
       
        private void button_uploadimage_Click(object sender, EventArgs e)
        {
            uploadImage();
            string paths = Application.StartupPath;
            //string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 9));
            if (!string.IsNullOrEmpty(tempImagePath))
            {
                pictureBox1_dp.Image = Image.FromFile(paths + "\\patientimages\\" + tempImagePath);
                
            }
        }

        private void uploadImage()
        {

            OpenFileDialog ofdFindPhoto = new OpenFileDialog();

            ofdFindPhoto.InitialDirectory = @"C:\Desktop\";
            ofdFindPhoto.FileName = "";
            ofdFindPhoto.Multiselect = false;
            ofdFindPhoto.Filter = "JPEG Image|*.jpg|GIF Image|*.gif|PNG Image|*.png|BMP Image|*.bmp";
            if (ofdFindPhoto.ShowDialog() == DialogResult.OK)

            {
                if (ofdFindPhoto.CheckFileExists)

                {

                    //C: \Users\rajib\Documents\Visual Studio 2015\Projects\WindowsFormsApplication9\WindowsFormsApplication9\bin\Debug
                    // the length - 0 is for going back to project folder from bin\debug folder
                    //string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 9));

                    string paths = Application.StartupPath;
                    string getImageFileName = System.IO.Path.GetFileName(ofdFindPhoto.FileName);
                    System.IO.File.Copy(ofdFindPhoto.FileName, paths + "\\patientimages\\" + getImageFileName);
                    MessageBox.Show("Successfully Uploaded");
                    tempImagePath = getImageFileName;
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

    }
}
