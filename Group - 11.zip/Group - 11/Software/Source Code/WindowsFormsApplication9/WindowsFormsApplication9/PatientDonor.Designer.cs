﻿namespace WindowsFormsApplication9
{
    partial class PatientDonor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button__patient_search = new System.Windows.Forms.Button();
            this.textBox_input_ph_patient = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_patient_name = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_patient_index = new System.Windows.Forms.Label();
            this.label_donor_name = new System.Windows.Forms.Label();
            this.label_donor_index = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button_donor_search = new System.Windows.Forms.Button();
            this.textBox_input_ph_donor = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_patient_index = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_donor_index = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button_save = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_mainindexID = new System.Windows.Forms.TextBox();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.button_View = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.Color.Green;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(387, 12);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(201, 40);
            this.button_admin_cp.TabIndex = 41;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Green;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(594, 11);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 42;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(369, 40);
            this.button_home.TabIndex = 40;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(11, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 32);
            this.label1.TabIndex = 39;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button__patient_search
            // 
            this.button__patient_search.BackColor = System.Drawing.Color.AliceBlue;
            this.button__patient_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button__patient_search.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button__patient_search.ForeColor = System.Drawing.Color.DodgerBlue;
            this.button__patient_search.Location = new System.Drawing.Point(243, 152);
            this.button__patient_search.Name = "button__patient_search";
            this.button__patient_search.Size = new System.Drawing.Size(93, 34);
            this.button__patient_search.TabIndex = 45;
            this.button__patient_search.Text = "SEARCH";
            this.button__patient_search.UseVisualStyleBackColor = false;
            this.button__patient_search.Click += new System.EventHandler(this.button__patient_search_Click);
            // 
            // textBox_input_ph_patient
            // 
            this.textBox_input_ph_patient.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_input_ph_patient.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_input_ph_patient.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_input_ph_patient.Location = new System.Drawing.Point(17, 157);
            this.textBox_input_ph_patient.MaxLength = 50;
            this.textBox_input_ph_patient.Name = "textBox_input_ph_patient";
            this.textBox_input_ph_patient.Size = new System.Drawing.Size(193, 27);
            this.textBox_input_ph_patient.TabIndex = 44;
            this.textBox_input_ph_patient.Text = "Phone Number";
            this.textBox_input_ph_patient.Enter += new System.EventHandler(this.textBox_input_ph_patient_Enter);
            this.textBox_input_ph_patient.Leave += new System.EventHandler(this.textBox_input_ph_patient_Leave);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGreen;
            this.label5.Location = new System.Drawing.Point(13, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(213, 21);
            this.label5.TabIndex = 43;
            this.label5.Text = "Search Patient";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 19);
            this.label2.TabIndex = 46;
            this.label2.Text = "Patient Name :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label_patient_name
            // 
            this.label_patient_name.AutoSize = true;
            this.label_patient_name.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_patient_name.Location = new System.Drawing.Point(239, 203);
            this.label_patient_name.Name = "label_patient_name";
            this.label_patient_name.Size = new System.Drawing.Size(149, 19);
            this.label_patient_name.TabIndex = 46;
            this.label_patient_name.Text = "FirstName LastName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 241);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 19);
            this.label4.TabIndex = 46;
            this.label4.Text = "Patient Index : ";
            this.label4.Click += new System.EventHandler(this.label2_Click);
            // 
            // label_patient_index
            // 
            this.label_patient_index.AutoSize = true;
            this.label_patient_index.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_patient_index.Location = new System.Drawing.Point(239, 241);
            this.label_patient_index.Name = "label_patient_index";
            this.label_patient_index.Size = new System.Drawing.Size(41, 19);
            this.label_patient_index.TabIndex = 46;
            this.label_patient_index.Text = "9999";
            this.label_patient_index.Click += new System.EventHandler(this.label2_Click);
            // 
            // label_donor_name
            // 
            this.label_donor_name.AutoSize = true;
            this.label_donor_name.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_donor_name.Location = new System.Drawing.Point(239, 347);
            this.label_donor_name.Name = "label_donor_name";
            this.label_donor_name.Size = new System.Drawing.Size(149, 19);
            this.label_donor_name.TabIndex = 50;
            this.label_donor_name.Text = "FirstName LastName";
            // 
            // label_donor_index
            // 
            this.label_donor_index.AutoSize = true;
            this.label_donor_index.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_donor_index.Location = new System.Drawing.Point(239, 385);
            this.label_donor_index.Name = "label_donor_index";
            this.label_donor_index.Size = new System.Drawing.Size(41, 19);
            this.label_donor_index.TabIndex = 51;
            this.label_donor_index.Text = "9999";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(17, 385);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 19);
            this.label9.TabIndex = 52;
            this.label9.Text = "Donor Index : ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(17, 347);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 19);
            this.label10.TabIndex = 53;
            this.label10.Text = "Donor Name :";
            // 
            // button_donor_search
            // 
            this.button_donor_search.BackColor = System.Drawing.Color.AliceBlue;
            this.button_donor_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_donor_search.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_donor_search.ForeColor = System.Drawing.Color.DodgerBlue;
            this.button_donor_search.Location = new System.Drawing.Point(243, 296);
            this.button_donor_search.Name = "button_donor_search";
            this.button_donor_search.Size = new System.Drawing.Size(93, 34);
            this.button_donor_search.TabIndex = 49;
            this.button_donor_search.Text = "SEARCH";
            this.button_donor_search.UseVisualStyleBackColor = false;
            this.button_donor_search.Click += new System.EventHandler(this.button_donor_search_Click);
            // 
            // textBox_input_ph_donor
            // 
            this.textBox_input_ph_donor.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_input_ph_donor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_input_ph_donor.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_input_ph_donor.Location = new System.Drawing.Point(17, 301);
            this.textBox_input_ph_donor.MaxLength = 50;
            this.textBox_input_ph_donor.Name = "textBox_input_ph_donor";
            this.textBox_input_ph_donor.Size = new System.Drawing.Size(193, 27);
            this.textBox_input_ph_donor.TabIndex = 48;
            this.textBox_input_ph_donor.Text = "Phone Number";
            this.textBox_input_ph_donor.Enter += new System.EventHandler(this.textBox_input_ph_donor_Enter);
            this.textBox_input_ph_donor.Leave += new System.EventHandler(this.textBox_input_ph_donor_Leave);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkGreen;
            this.label11.Location = new System.Drawing.Point(13, 274);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(213, 21);
            this.label11.TabIndex = 47;
            this.label11.Text = "Search Donor";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_patient_index
            // 
            this.textBox_patient_index.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_patient_index.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_patient_index.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_patient_index.Location = new System.Drawing.Point(17, 481);
            this.textBox_patient_index.MaxLength = 50;
            this.textBox_patient_index.Name = "textBox_patient_index";
            this.textBox_patient_index.Size = new System.Drawing.Size(193, 27);
            this.textBox_patient_index.TabIndex = 48;
            this.textBox_patient_index.Text = "Patient Index";
            this.textBox_patient_index.Enter += new System.EventHandler(this.textBox_patient_index_Enter);
            this.textBox_patient_index.Leave += new System.EventHandler(this.textBox_patient_index_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(17, 446);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 19);
            this.label12.TabIndex = 53;
            this.label12.Text = "Patient Index :";
            // 
            // textBox_donor_index
            // 
            this.textBox_donor_index.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_donor_index.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_donor_index.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_donor_index.Location = new System.Drawing.Point(243, 481);
            this.textBox_donor_index.MaxLength = 50;
            this.textBox_donor_index.Name = "textBox_donor_index";
            this.textBox_donor_index.Size = new System.Drawing.Size(193, 27);
            this.textBox_donor_index.TabIndex = 48;
            this.textBox_donor_index.Text = "Donor Index";
            this.textBox_donor_index.Enter += new System.EventHandler(this.textBox_donor_index_Enter);
            this.textBox_donor_index.Leave += new System.EventHandler(this.textBox_donor_index_Leave);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(243, 446);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 19);
            this.label13.TabIndex = 53;
            this.label13.Text = "Donor Index :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DarkGreen;
            this.label14.Location = new System.Drawing.Point(17, 417);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 19);
            this.label14.TabIndex = 53;
            this.label14.Text = "INSERT DATA";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(17, 535);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(116, 19);
            this.label15.TabIndex = 53;
            this.label15.Text = "Donation Date :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(243, 533);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(209, 20);
            this.dateTimePicker1.TabIndex = 54;
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.Green;
            this.button_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_save.ForeColor = System.Drawing.Color.White;
            this.button_save.Location = new System.Drawing.Point(305, 574);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(90, 36);
            this.button_save.TabIndex = 173;
            this.button_save.Text = "SAVE";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(447, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 21);
            this.label3.TabIndex = 43;
            this.label3.Text = "Donor Patient Relation";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_mainindexID
            // 
            this.textBox_mainindexID.BackColor = System.Drawing.Color.LightSkyBlue;
            this.textBox_mainindexID.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mainindexID.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_mainindexID.Location = new System.Drawing.Point(451, 157);
            this.textBox_mainindexID.Name = "textBox_mainindexID";
            this.textBox_mainindexID.Size = new System.Drawing.Size(71, 27);
            this.textBox_mainindexID.TabIndex = 295;
            this.textBox_mainindexID.Text = "index";
            this.textBox_mainindexID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_mainindexID.Enter += new System.EventHandler(this.textBox_indexID_Enter);
            this.textBox_mainindexID.Leave += new System.EventHandler(this.textBox_indexID_Leave);
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.Red;
            this.button_delete.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete.ForeColor = System.Drawing.Color.White;
            this.button_delete.Location = new System.Drawing.Point(497, 574);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(90, 35);
            this.button_delete.TabIndex = 299;
            this.button_delete.Text = "DELETE";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_exit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit.ForeColor = System.Drawing.Color.White;
            this.button_exit.Location = new System.Drawing.Point(594, 573);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(90, 35);
            this.button_exit.TabIndex = 298;
            this.button_exit.Text = "BACK";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.SteelBlue;
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update.ForeColor = System.Drawing.Color.White;
            this.button_update.Location = new System.Drawing.Point(401, 574);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(90, 35);
            this.button_update.TabIndex = 297;
            this.button_update.Text = "UPDATE";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // button_View
            // 
            this.button_View.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_View.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_View.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_View.ForeColor = System.Drawing.SystemColors.Info;
            this.button_View.Location = new System.Drawing.Point(543, 157);
            this.button_View.Name = "button_View";
            this.button_View.Size = new System.Drawing.Size(71, 28);
            this.button_View.TabIndex = 300;
            this.button_View.Text = "VIEW";
            this.button_View.UseVisualStyleBackColor = false;
            this.button_View.Click += new System.EventHandler(this.button_View_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(513, 345);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 19);
            this.label6.TabIndex = 301;
            this.label6.Text = "2018-05-30";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(513, 272);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 19);
            this.label7.TabIndex = 46;
            this.label7.Text = "9999";
            this.label7.Click += new System.EventHandler(this.label2_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(513, 309);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 19);
            this.label8.TabIndex = 51;
            this.label8.Text = "9999";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(447, 222);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(111, 19);
            this.label16.TabIndex = 53;
            this.label16.Text = "index and date";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(447, 273);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 19);
            this.label17.TabIndex = 53;
            this.label17.Text = "Patient : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(447, 311);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 19);
            this.label18.TabIndex = 53;
            this.label18.Text = "Donor :";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(447, 347);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 19);
            this.label19.TabIndex = 53;
            this.label19.Text = "Date :";
            this.label19.Click += new System.EventHandler(this.label18_Click);
            // 
            // PatientDonor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_View);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.textBox_mainindexID);
            this.Controls.Add(this.button_save);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label_donor_name);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label_donor_index);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button_donor_search);
            this.Controls.Add(this.textBox_donor_index);
            this.Controls.Add(this.textBox_patient_index);
            this.Controls.Add(this.textBox_input_ph_donor);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label_patient_name);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label_patient_index);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button__patient_search);
            this.Controls.Add(this.textBox_input_ph_patient);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.label1);
            this.Name = "PatientDonor";
            this.Text = "Admin Tools";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button__patient_search;
        private System.Windows.Forms.TextBox textBox_input_ph_patient;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_patient_name;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_patient_index;
        private System.Windows.Forms.Label label_donor_name;
        private System.Windows.Forms.Label label_donor_index;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_donor_search;
        private System.Windows.Forms.TextBox textBox_input_ph_donor;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_patient_index;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_donor_index;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox textBox_mainindexID;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_View;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
    }
}