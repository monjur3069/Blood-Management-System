﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class PatientDonor : Form
    {
        public PatientDonor()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button__patient_search_Click(object sender, EventArgs e)
        {
            PatientIndex();
        }

        private void PatientIndex()
        {
            string PatientPhn = textBox_input_ph_patient.Text.Trim().ToString();
            string testPatientPhn = null; // for dumping DB PhoneNumber and check for matching

            // Checking Phone  matched or not.

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            if (!string.IsNullOrEmpty(PatientPhn) && (PatientPhn != "Phone Number"))
            {
                try
                {
                    conn.Open();
                    DataTable dt = new DataTable();
                    MySqlDataReader myReader = null;
                    MySqlCommand myCommand = new MySqlCommand("select Patient_Index, Patient_Name, Phone_Number from patient where Phone_Number ='" + PatientPhn + "' ", conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        testPatientPhn = (myReader["Phone_Number"].ToString().Trim());

                    }
                    if (PatientPhn == testPatientPhn)
                    {
                        label_patient_name.Text = (myReader["Patient_Name"].ToString());
                        label_patient_index.Text = (myReader["Patient_Index"].ToString());

                        myReader.Close();
                        conn.Close();
                    }
                    else
                    {
                        MessageBox.Show("Phone Number Did not Matched! Try again.");
                        textBox_input_ph_donor.Clear();

                        myReader.Close();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter Patient Phone Number");
            }
        }

        private void DonorIndex()
        {
            string DonorPhn = textBox_input_ph_donor.Text.Trim().ToString();
            string testDonorPhn = null; // for dumping DB PhoneNumber and check for matching

            // Checking Phone  matched or not.

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            if (!string.IsNullOrEmpty(DonorPhn) && (DonorPhn != "Phone Number"))
            {
                try
                {
                    conn.Open();
                    DataTable dt = new DataTable();
                    MySqlDataReader myReader = null;
                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, Student_Name, Phone_No from donortable where Phone_No ='" + DonorPhn + "' ", conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        testDonorPhn = (myReader["Phone_No"].ToString().Trim());
                      
                    }
                    if (DonorPhn == testDonorPhn)
                    {
                        label_donor_name.Text = (myReader["Student_Name"].ToString());
                        label_donor_index.Text = (myReader["Donor_Index"].ToString());

                        myReader.Close();
                        conn.Close();
                    }
                    else
                    {
                        MessageBox.Show("Phone Number Did not Matched! Try again.");
                        textBox_input_ph_donor.Clear();
                        
                        myReader.Close();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter Donor Phone Number");
            }
        }

        private void button_donor_search_Click(object sender, EventArgs e)
        {
            DonorIndex();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            DonorToPatient();
        }

        private void DonorToPatient()
        {
            // database connection string
            string ConnectString = ConnectionString.connString;
            //string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {                                   
                    string patientIndex = textBox_patient_index.Text.Trim();
                    string DonorIndex = textBox_donor_index.Text.Trim();
                    string DonationDate = Donation().ToString().ToUpper();

                // checking if specific fields are empty
                if ((patientIndex != "Patient Index")&&(DonorIndex != "Donor Index"))
                       {
                        //opening connection
                        conn.Open();
                        MySqlCommand cmd = conn.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "insert into patientdonor values ('', '" + DonorIndex + "' , '" + patientIndex + "', '" + DonationDate + "' )";
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Upload Successful!");

                    textBox_patient_index.Clear();
                    textBox_donor_index.Clear();
                    textBox_input_ph_patient.Clear();
                    textBox_input_ph_donor.Clear();

                    }

                    else
                    {
                        label1.Visible = true;
                        label2.Visible = true;
                        
                        label4.Visible = true;
                        label5.Visible = true;
                        
                        MessageBox.Show("Selected Field Can't be Empty!");
                    }
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private string Donation()
        {
            string DonationDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            return DonationDate;
        }

        private void textBox_input_ph_patient_Enter(object sender, EventArgs e)
        {
            if (textBox_input_ph_patient.Text == "Phone Number")
            {
                textBox_input_ph_patient.Text = "";
                textBox_input_ph_patient.ForeColor = Color.Black;
            }
        }

        private void textBox_input_ph_patient_Leave(object sender, EventArgs e)
        {
            if (textBox_input_ph_patient.Text == "")
            {
                textBox_input_ph_patient.Text = "Phone Number";
                textBox_input_ph_patient.ForeColor = Color.Gray;
            }
        }

        private void textBox_input_ph_donor_Enter(object sender, EventArgs e)
        {
            if (textBox_input_ph_donor.Text == "Phone Number")
            {
                textBox_input_ph_donor.Text = "";
                textBox_input_ph_donor.ForeColor = Color.Black;
            }
        }

        private void textBox_input_ph_donor_Leave(object sender, EventArgs e)
        {
            if (textBox_input_ph_donor.Text == "")
            {
                textBox_input_ph_donor.Text = "Phone Number";
                textBox_input_ph_donor.ForeColor = Color.Gray;
            }
        }

        private void textBox_patient_index_Enter(object sender, EventArgs e)
        {
            if (textBox_patient_index.Text == "Patient Index")
            {
                textBox_patient_index.Text = "";
                textBox_patient_index.ForeColor = Color.Black;
            }
        }

        private void textBox_patient_index_Leave(object sender, EventArgs e)
        {
            if (textBox_patient_index.Text == "")
            {
                textBox_patient_index.Text = "Patient Index";
                textBox_patient_index.ForeColor = Color.Gray;
            }
        }

        private void textBox_donor_index_Enter(object sender, EventArgs e)
        {
            if (textBox_donor_index.Text == "Donor Index")
            {
                textBox_donor_index.Text = "";
                textBox_donor_index.ForeColor = Color.Black;
            }
        }

        private void textBox_donor_index_Leave(object sender, EventArgs e)
        {
            if (textBox_donor_index.Text == "")
            {
                textBox_donor_index.Text = "Donor Index";
                textBox_donor_index.ForeColor = Color.Gray;
            }
        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void textBox_indexID_Enter(object sender, EventArgs e)
        {
            if (textBox_mainindexID.Text == "index")
            {
                textBox_mainindexID.Text = "";
                textBox_mainindexID.ForeColor = Color.Black;
            }
        }

        private void textBox_indexID_Leave(object sender, EventArgs e)
        {
            if (textBox_mainindexID.Text == "")
            {
                textBox_mainindexID.Text = "index";
                textBox_mainindexID.ForeColor = Color.Gray;
            }
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            UpdateDonorToPatient();
        }

        private void UpdateDonorToPatient()
        {
            // database connection string
            string ConnectString = ConnectionString.connString;
            //string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                string mainIndex = textBox_mainindexID.Text.Trim().ToString();
                string patientIndex = textBox_patient_index.Text.Trim();
                string DonorIndex = textBox_donor_index.Text.Trim();
                string DonationDate = Donation().ToString().ToUpper();

                // checking if specific fields are empty
                if ((patientIndex != "Patient Index") && (DonorIndex != "Donor Index")&&(!string.IsNullOrEmpty(mainIndex))&&(mainIndex!="index"))
                {
                    //opening connection
                    conn.Open();
                    MySqlCommand cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE patientdonor SET  Donor_Index = '" + DonorIndex + "', Patient_Index = '" + patientIndex + "' , donationdate = '" + DonationDate + "' where PD_Index = '" + mainIndex + "' ";
                        //"insert into patientdonor values ('', '" + DonorIndex + "' , '" + patientIndex + "', '" + DonationDate + "' )";
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Update Successful!");

                    textBox_patient_index.Clear();
                    textBox_mainindexID.Clear();
                    textBox_donor_index.Clear();
                    textBox_input_ph_patient.Clear();
                    textBox_input_ph_donor.Clear();

                }

                else
                {
                    label1.Visible = true;
                    label2.Visible = true;

                    label4.Visible = true;
                    label5.Visible = true;

                    MessageBox.Show("Selected Field Can't be Empty!");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button_View_Click(object sender, EventArgs e)
        {
            string mainIndex = textBox_mainindexID.Text.Trim().ToString();
            string testmainIndex = null; 
                        
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            if (!string.IsNullOrEmpty(mainIndex) && (mainIndex != "index"))
            {
                try
                {
                    conn.Open();
                    DataTable dt = new DataTable();
                    MySqlDataReader myReader = null;
                    MySqlCommand myCommand = new MySqlCommand("select PD_Index, Donor_Index, Patient_Index, donationdate from patientdonor where PD_Index ='" + mainIndex + "' ", conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        testmainIndex = (myReader["PD_Index"].ToString().Trim());

                    }
                    if (mainIndex == testmainIndex)
                    {
                        
                        label7.Text = (myReader["Patient_Index"].ToString());
                        label8.Text = (myReader["Donor_Index"].ToString());
                       
                        label6.Text = (myReader["donationdate"].ToString());

                       
                        label_patient_name.Text = "";
                        label_donor_name.Text = "";
                        textBox_input_ph_donor.Text = "";
                        textBox_input_ph_patient.Text = "";
                        textBox_patient_index.Text = "";
                        textBox_donor_index.Text = "";
                        label_donor_index.Text = "";
                        label_patient_index.Text = "";

                        myReader.Close();
                        conn.Close();
                    }
                    else
                    {
                        MessageBox.Show("indexID Not found! Try again.");
                        
                        myReader.Close();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter IndexId Number");
            }
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            string mainIndex = textBox_mainindexID.Text.Trim().ToString();
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);
            if (!string.IsNullOrEmpty(mainIndex) && (mainIndex != "index"))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "DELETE FROM patientdonor WHERE PD_Index = '" + mainIndex + "'  ";

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Info Has Been DELETED!");

                    conn.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Empty Index!");
            }
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }
    }
}
