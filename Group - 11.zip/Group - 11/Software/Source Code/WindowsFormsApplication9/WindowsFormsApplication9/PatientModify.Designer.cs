﻿namespace WindowsFormsApplication9
{
    partial class PatientModify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PatientModify));
            this.textBox_indexID = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button_uploadimage = new System.Windows.Forms.Button();
            this.pictureBox1_dp = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.comboBox_gender = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.text_age = new System.Windows.Forms.TextBox();
            this.label_age = new System.Windows.Forms.Label();
            this.dateTimePicker_birthday = new System.Windows.Forms.DateTimePicker();
            this.text_address = new System.Windows.Forms.TextBox();
            this.label_address = new System.Windows.Forms.Label();
            this.text_email = new System.Windows.Forms.TextBox();
            this.label_birthday = new System.Windows.Forms.Label();
            this.label_emali = new System.Windows.Forms.Label();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.label_phone = new System.Windows.Forms.Label();
            this.text_city = new System.Windows.Forms.TextBox();
            this.label_city = new System.Windows.Forms.Label();
            this.comboBox_bloodtype = new System.Windows.Forms.ComboBox();
            this.label_diseases = new System.Windows.Forms.Label();
            this.label_bloodtype = new System.Windows.Forms.Label();
            this.text_diseases = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.label_name = new System.Windows.Forms.Label();
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_delete = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_indexID
            // 
            this.textBox_indexID.BackColor = System.Drawing.Color.LightSkyBlue;
            this.textBox_indexID.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_indexID.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_indexID.Location = new System.Drawing.Point(196, 162);
            this.textBox_indexID.Name = "textBox_indexID";
            this.textBox_indexID.Size = new System.Drawing.Size(71, 27);
            this.textBox_indexID.TabIndex = 295;
            this.textBox_indexID.Text = "index";
            this.textBox_indexID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_indexID.Enter += new System.EventHandler(this.textBox_indexID_Enter);
            this.textBox_indexID.Leave += new System.EventHandler(this.textBox_indexID_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(148, 168);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 19);
            this.label12.TabIndex = 294;
            this.label12.Text = "***";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(70, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 15);
            this.label11.TabIndex = 293;
            this.label11.Text = "INDEX ID :";
            // 
            // button_uploadimage
            // 
            this.button_uploadimage.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_uploadimage.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uploadimage.ForeColor = System.Drawing.Color.GhostWhite;
            this.button_uploadimage.Location = new System.Drawing.Point(535, 305);
            this.button_uploadimage.Name = "button_uploadimage";
            this.button_uploadimage.Size = new System.Drawing.Size(98, 36);
            this.button_uploadimage.TabIndex = 336;
            this.button_uploadimage.Text = "UPLOAD";
            this.button_uploadimage.UseVisualStyleBackColor = false;
            this.button_uploadimage.Click += new System.EventHandler(this.button_uploadimage_Click);
            // 
            // pictureBox1_dp
            // 
            this.pictureBox1_dp.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox1_dp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_dp.Image")));
            this.pictureBox1_dp.Location = new System.Drawing.Point(535, 160);
            this.pictureBox1_dp.Name = "pictureBox1_dp";
            this.pictureBox1_dp.Padding = new System.Windows.Forms.Padding(3);
            this.pictureBox1_dp.Size = new System.Drawing.Size(98, 126);
            this.pictureBox1_dp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_dp.TabIndex = 335;
            this.pictureBox1_dp.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SteelBlue;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(255, 573);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 35);
            this.button1.TabIndex = 334;
            this.button1.Text = "UPDATE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_clear
            // 
            this.button_clear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear.ForeColor = System.Drawing.Color.White;
            this.button_clear.Location = new System.Drawing.Point(447, 574);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(90, 35);
            this.button_clear.TabIndex = 333;
            this.button_clear.Text = "CLEAR";
            this.button_clear.UseVisualStyleBackColor = false;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.SteelBlue;
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update.ForeColor = System.Drawing.Color.White;
            this.button_update.Location = new System.Drawing.Point(543, 574);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(90, 35);
            this.button_update.TabIndex = 332;
            this.button_update.Text = "EXIT";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // comboBox_gender
            // 
            this.comboBox_gender.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_gender.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_gender.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_gender.FormattingEnabled = true;
            this.comboBox_gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.comboBox_gender.Location = new System.Drawing.Point(508, 478);
            this.comboBox_gender.Name = "comboBox_gender";
            this.comboBox_gender.Size = new System.Drawing.Size(125, 27);
            this.comboBox_gender.TabIndex = 330;
            this.comboBox_gender.Text = "Select";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(427, 483);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 15);
            this.label9.TabIndex = 329;
            this.label9.Text = "Gender";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(473, 479);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 26);
            this.label10.TabIndex = 323;
            this.label10.Text = "*";
            this.label10.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(168, 483);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 26);
            this.label5.TabIndex = 324;
            this.label5.Text = "*";
            this.label5.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(168, 391);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 26);
            this.label3.TabIndex = 325;
            this.label3.Text = "*";
            this.label3.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(166, 346);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 26);
            this.label7.TabIndex = 326;
            this.label7.Text = "*";
            this.label7.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(166, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 26);
            this.label1.TabIndex = 327;
            this.label1.Text = "*";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(166, 215);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 26);
            this.label2.TabIndex = 328;
            this.label2.Text = "*";
            this.label2.Visible = false;
            // 
            // text_age
            // 
            this.text_age.BackColor = System.Drawing.SystemColors.Info;
            this.text_age.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_age.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_age.Location = new System.Drawing.Point(417, 386);
            this.text_age.Name = "text_age";
            this.text_age.Size = new System.Drawing.Size(71, 27);
            this.text_age.TabIndex = 322;
            this.text_age.Text = "auto";
            this.text_age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_age.Enter += new System.EventHandler(this.text_age_Enter);
            this.text_age.Leave += new System.EventHandler(this.text_age_Leave);
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_age.Location = new System.Drawing.Point(327, 392);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(36, 15);
            this.label_age.TabIndex = 321;
            this.label_age.Text = "AGE :";
            // 
            // dateTimePicker_birthday
            // 
            this.dateTimePicker_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_birthday.Location = new System.Drawing.Point(196, 346);
            this.dateTimePicker_birthday.Name = "dateTimePicker_birthday";
            this.dateTimePicker_birthday.Size = new System.Drawing.Size(216, 23);
            this.dateTimePicker_birthday.TabIndex = 320;
            // 
            // text_address
            // 
            this.text_address.BackColor = System.Drawing.SystemColors.Info;
            this.text_address.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_address.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_address.Location = new System.Drawing.Point(196, 433);
            this.text_address.Name = "text_address";
            this.text_address.Size = new System.Drawing.Size(437, 27);
            this.text_address.TabIndex = 319;
            this.text_address.Text = "Enter your full adress";
            this.text_address.Enter += new System.EventHandler(this.text_address_Enter);
            this.text_address.Leave += new System.EventHandler(this.text_address_Leave);
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_address.Location = new System.Drawing.Point(70, 439);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(63, 15);
            this.label_address.TabIndex = 318;
            this.label_address.Text = "ADDRESS :";
            // 
            // text_email
            // 
            this.text_email.BackColor = System.Drawing.SystemColors.Info;
            this.text_email.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_email.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_email.Location = new System.Drawing.Point(196, 299);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(177, 27);
            this.text_email.TabIndex = 316;
            this.text_email.Text = "someone@example.com";
            this.text_email.Enter += new System.EventHandler(this.text_email_Enter);
            this.text_email.Leave += new System.EventHandler(this.text_email_Leave);
            // 
            // label_birthday
            // 
            this.label_birthday.AutoSize = true;
            this.label_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_birthday.Location = new System.Drawing.Point(70, 352);
            this.label_birthday.Name = "label_birthday";
            this.label_birthday.Size = new System.Drawing.Size(41, 15);
            this.label_birthday.TabIndex = 315;
            this.label_birthday.Text = "Birth :";
            // 
            // label_emali
            // 
            this.label_emali.AutoSize = true;
            this.label_emali.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_emali.Location = new System.Drawing.Point(70, 305);
            this.label_emali.Name = "label_emali";
            this.label_emali.Size = new System.Drawing.Size(48, 15);
            this.label_emali.TabIndex = 314;
            this.label_emali.Text = "EMAIL :";
            // 
            // text_phone
            // 
            this.text_phone.BackColor = System.Drawing.SystemColors.Info;
            this.text_phone.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_phone.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_phone.Location = new System.Drawing.Point(196, 254);
            this.text_phone.Name = "text_phone";
            this.text_phone.Size = new System.Drawing.Size(177, 27);
            this.text_phone.TabIndex = 317;
            this.text_phone.Text = "01700000XXX";
            this.text_phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_phone.Enter += new System.EventHandler(this.text_phone_Enter);
            this.text_phone.Leave += new System.EventHandler(this.text_phone_Leave);
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phone.Location = new System.Drawing.Point(67, 260);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(53, 15);
            this.label_phone.TabIndex = 313;
            this.label_phone.Text = "PHONE :";
            // 
            // text_city
            // 
            this.text_city.BackColor = System.Drawing.SystemColors.Info;
            this.text_city.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_city.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_city.Location = new System.Drawing.Point(196, 386);
            this.text_city.Name = "text_city";
            this.text_city.Size = new System.Drawing.Size(90, 27);
            this.text_city.TabIndex = 312;
            this.text_city.Text = "your city";
            this.text_city.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_city.Enter += new System.EventHandler(this.text_city_Enter);
            this.text_city.Leave += new System.EventHandler(this.text_city_Leave);
            // 
            // label_city
            // 
            this.label_city.AutoSize = true;
            this.label_city.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_city.Location = new System.Drawing.Point(70, 392);
            this.label_city.Name = "label_city";
            this.label_city.Size = new System.Drawing.Size(37, 15);
            this.label_city.TabIndex = 311;
            this.label_city.Text = "CITY :";
            // 
            // comboBox_bloodtype
            // 
            this.comboBox_bloodtype.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_bloodtype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_bloodtype.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_bloodtype.FormattingEnabled = true;
            this.comboBox_bloodtype.Items.AddRange(new object[] {
            "A+",
            "B+",
            "O+",
            "AB+",
            "A-",
            "B-",
            "O-",
            "AB-",
            "Other"});
            this.comboBox_bloodtype.Location = new System.Drawing.Point(196, 479);
            this.comboBox_bloodtype.Name = "comboBox_bloodtype";
            this.comboBox_bloodtype.Size = new System.Drawing.Size(108, 27);
            this.comboBox_bloodtype.TabIndex = 310;
            this.comboBox_bloodtype.Text = "Blood Group";
            // 
            // label_diseases
            // 
            this.label_diseases.AutoSize = true;
            this.label_diseases.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_diseases.Location = new System.Drawing.Point(70, 531);
            this.label_diseases.Name = "label_diseases";
            this.label_diseases.Size = new System.Drawing.Size(103, 15);
            this.label_diseases.TabIndex = 309;
            this.label_diseases.Text = "DISEASES (if any) :";
            // 
            // label_bloodtype
            // 
            this.label_bloodtype.AutoSize = true;
            this.label_bloodtype.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bloodtype.Location = new System.Drawing.Point(70, 485);
            this.label_bloodtype.Name = "label_bloodtype";
            this.label_bloodtype.Size = new System.Drawing.Size(82, 15);
            this.label_bloodtype.TabIndex = 308;
            this.label_bloodtype.Text = "BLOOD TYPE :";
            // 
            // text_diseases
            // 
            this.text_diseases.BackColor = System.Drawing.SystemColors.Info;
            this.text_diseases.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_diseases.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_diseases.Location = new System.Drawing.Point(196, 525);
            this.text_diseases.Name = "text_diseases";
            this.text_diseases.Size = new System.Drawing.Size(437, 27);
            this.text_diseases.TabIndex = 307;
            this.text_diseases.Text = "name of disease";
            this.text_diseases.Enter += new System.EventHandler(this.text_diseases_Enter);
            this.text_diseases.Leave += new System.EventHandler(this.text_diseases_Leave);
            // 
            // text_name
            // 
            this.text_name.BackColor = System.Drawing.SystemColors.Info;
            this.text_name.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_name.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_name.Location = new System.Drawing.Point(196, 209);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(299, 27);
            this.text_name.TabIndex = 306;
            this.text_name.Text = "Enter your full name";
            this.text_name.Enter += new System.EventHandler(this.text_name_Enter);
            this.text_name.Leave += new System.EventHandler(this.text_name_Leave);
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.Location = new System.Drawing.Point(68, 215);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(48, 15);
            this.label_name.TabIndex = 305;
            this.label_name.Text = "NAME :";
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.Color.Green;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(386, 12);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(201, 40);
            this.button_admin_cp.TabIndex = 303;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Green;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(593, 11);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 304;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(11, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(369, 40);
            this.button_home.TabIndex = 302;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkGreen;
            this.label6.Location = new System.Drawing.Point(5, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(680, 32);
            this.label6.TabIndex = 300;
            this.label6.Text = "BUBT BLOOD DONATION CENTER";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(10, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(680, 32);
            this.label4.TabIndex = 301;
            this.label4.Text = "PATIENT INFORMATION";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.Red;
            this.button_delete.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete.ForeColor = System.Drawing.Color.White;
            this.button_delete.Location = new System.Drawing.Point(351, 574);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(90, 35);
            this.button_delete.TabIndex = 352;
            this.button_delete.Text = "DELETE";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(518, 138);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 15);
            this.label8.TabIndex = 353;
            this.label8.Text = "Passport : 35 x 45mm";
            // 
            // PatientModify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_uploadimage);
            this.Controls.Add(this.pictureBox1_dp);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.comboBox_gender);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.text_age);
            this.Controls.Add(this.label_age);
            this.Controls.Add(this.dateTimePicker_birthday);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.text_email);
            this.Controls.Add(this.label_birthday);
            this.Controls.Add(this.label_emali);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.text_city);
            this.Controls.Add(this.label_city);
            this.Controls.Add(this.comboBox_bloodtype);
            this.Controls.Add(this.label_diseases);
            this.Controls.Add(this.label_bloodtype);
            this.Controls.Add(this.text_diseases);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_indexID);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Name = "PatientModify";
            this.Text = "Modify Patient Profile";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox textBox_indexID;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_uploadimage;
        private System.Windows.Forms.PictureBox pictureBox1_dp;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.ComboBox comboBox_gender;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox text_age;
        private System.Windows.Forms.Label label_age;
        public System.Windows.Forms.DateTimePicker dateTimePicker_birthday;
        private System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.Label label_address;
        private System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.Label label_birthday;
        private System.Windows.Forms.Label label_emali;
        private System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Label label_phone;
        private System.Windows.Forms.TextBox text_city;
        private System.Windows.Forms.Label label_city;
        private System.Windows.Forms.ComboBox comboBox_bloodtype;
        private System.Windows.Forms.Label label_diseases;
        private System.Windows.Forms.Label label_bloodtype;
        private System.Windows.Forms.TextBox text_diseases;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Label label8;
    }
}