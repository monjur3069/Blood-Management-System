﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication9
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            SignUpValidation();
        }

       // Poor Code not using anymore
       /*
        private void Signup_page()
        {

            string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                // taking textbox input into username and password variable.
                string username = textBox_username.Text.Trim().ToString();
                string password = textBox_password.Text.Trim().ToString();
                string password2 = textBox_password2.Text.Trim().ToString();


                // checking if username field is empty
                if (!string.IsNullOrEmpty(username)&& !string.IsNullOrEmpty(password)&& !string.IsNullOrEmpty(password2))
                {
                    if(password==password2)
                    {
                        //opening connection
                        conn.Open();
                        MySqlDataAdapter sda = new MySqlDataAdapter("Select Count(*) From userlogin where username='" + username + "' ", conn);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        //checking if user name already exist
                        if (dt.Rows[0][0].ToString() != "1")
                        {

                            MySqlCommand cmd = conn.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "insert into userlogin values ('', '" + username + "', '" + password + "' )";
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Registration Successful! Please login.");

                            textBox_username.Clear();
                            textBox_password.Clear();
                            conn.Close();

                            //redirecting to login page which is home page also.
                            Home home = new Home();
                            home.Width = this.Width;
                            home.Height = this.Height;
                            home.StartPosition = FormStartPosition.Manual;
                            home.Location = new Point(this.Location.X, this.Location.Y);

                            this.Hide();
                            home.ShowDialog();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("User Already Exist, Try New User Name");
                            textBox_username.Clear();
                            textBox_password.Clear();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password Didn't Matched!");
                    }
                }

                else
                {
                    MessageBox.Show("Empty Field. Input Value");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
          
        }
        */


        private void SignUpValidation()
        {
            //string string ConnectString = ConnectionString.connString;
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                // taking textbox input into username and password variable.
                string username = textBox_username.Text.Trim().ToString();
                string testUserName = null;
                string password = textBox_password.Text.Trim().ToString();
                string password2 = textBox_password2.Text.Trim().ToString();

                


                // checking if username field is empty
                if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(password2) && (username != "username") && (password != "password") && (password2 != "password"))
                {
                    if (password == password2)
                    {
                        conn.Open();
                        DataTable dt = new DataTable();
                        MySqlDataReader myReader = null;
                        MySqlCommand myCommand = new MySqlCommand("select username from userlogin where username = '" + username + "' ", conn);
                        myReader = myCommand.ExecuteReader();
                        while (myReader.Read())
                        {
                            testUserName = (myReader["username"].ToString().Trim());
                           
                        }
                        if (username != testUserName)
                        {
                            myCommand.Cancel();
                            myReader.Close(); // MySqlCommand with reader has to be closed first before using another command.
                            MySqlCommand cmd = conn.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "insert into userlogin values ('', '" + username + "', '" + password + "' )";
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Registration Successful! Please login.");

                            textBox_username.Clear();
                            textBox_password.Clear();
                            textBox_password2.Clear();
                            myReader.Close();
                            conn.Close();

                            //redirecting to login page which is home page also.
                            Home home = new Home();
                            home.Width = this.Width;
                            home.Height = this.Height;
                            home.StartPosition = FormStartPosition.Manual;
                            home.Location = new Point(this.Location.X, this.Location.Y);

                            this.Hide();
                            home.ShowDialog();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("User Already Exist, Try New User Name");
                            textBox_username.Clear();
                            textBox_password.Clear();
                            myReader.Close();
                            conn.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password Didn't Matched!");
                    }
                }

                else
                {
                    MessageBox.Show("Empty Field. Input Value");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox_username_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_password_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_login_inactive_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_home2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_donorlist_Click(object sender, EventArgs e)
        {
            Donorlist d = new Donorlist();
            d.Width = this.Width;
            d.Height = this.Height;
            d.StartPosition = FormStartPosition.Manual;
            d.Location = new Point(this.Location.X, this.Location.Y);
            //d.dataGridView_donor_list = new DataGridView();
            // d.dataGridView_donor_list.Enabled = true;
            //d.dataGridView_donor_list.Visible = true;

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                conn.Open();
                MySqlCommand query = conn.CreateCommand();
                query.CommandType = CommandType.Text;

                query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable";
                //create adaptor to fill data from database
                MySqlDataAdapter da = new MySqlDataAdapter(query);
                //create datatable which holds the data
                DataTable dt = new DataTable();
                da.Fill(dt);
                //bind your data to gridview
                d.dataGridView_donor_list.DataSource = dt;
                // dataGridView1.DataBind();



                query.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



            this.Hide();
            d.ShowDialog();
            this.Close();
        }

        private void button_home_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox_username_Enter(object sender, EventArgs e)
        {
            if(textBox_username.Text == "username")
            {
                textBox_username.Text = "";
                textBox_username.ForeColor = Color.Black;
            }
        }

        private void textBox_username_Leave(object sender, EventArgs e)
        {
            if (textBox_username.Text == "")
            {
                textBox_username.Text = "username";
                textBox_username.ForeColor = Color.Gray;
            }
        }

        private void textBox_password_Enter(object sender, EventArgs e)
        {
            if (textBox_password.Text == "password")
            {
                textBox_password.Text = "";
                textBox_password.ForeColor = Color.Black;
            }
        }

        private void textBox_password_Leave(object sender, EventArgs e)
        {
            if (textBox_password.Text == "")
            {
                textBox_password.Text = "password";
                textBox_password.ForeColor = Color.Gray;
            }
        }

        private void textBox_password2_Enter(object sender, EventArgs e)
        {
            if (textBox_password2.Text == "password")
            {
                textBox_password2.Text = "";
                textBox_password2.ForeColor = Color.Black;
            }
        }

        private void textBox_password2_Leave(object sender, EventArgs e)
        {
            if (textBox_password2.Text == "")
            {
                textBox_password2.Text = "password";
                textBox_password2.ForeColor = Color.Gray;
            }
        }
    }
}
