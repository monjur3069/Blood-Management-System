﻿namespace WindowsFormsApplication9
{
    partial class UpdateDonorProfileAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateDonorProfileAdmin));
            this.button_exit = new System.Windows.Forms.Button();
            this.comboBox_gender = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_home = new System.Windows.Forms.Button();
            this.button_adminOR_user = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.dateTimePicker_lastdonation = new System.Windows.Forms.DateTimePicker();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.text_age = new System.Windows.Forms.TextBox();
            this.label_age = new System.Windows.Forms.Label();
            this.dateTimePicker_birthday = new System.Windows.Forms.DateTimePicker();
            this.label_lastdonation = new System.Windows.Forms.Label();
            this.radioButton_donated_no = new System.Windows.Forms.RadioButton();
            this.radioButton_donated_yes = new System.Windows.Forms.RadioButton();
            this.text_address = new System.Windows.Forms.TextBox();
            this.label_address = new System.Windows.Forms.Label();
            this.text_email = new System.Windows.Forms.TextBox();
            this.label_birthday = new System.Windows.Forms.Label();
            this.label_emali = new System.Windows.Forms.Label();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.label_phone = new System.Windows.Forms.Label();
            this.text_city = new System.Windows.Forms.TextBox();
            this.label_city = new System.Windows.Forms.Label();
            this.text_section = new System.Windows.Forms.TextBox();
            this.label_section = new System.Windows.Forms.Label();
            this.text_intake = new System.Windows.Forms.TextBox();
            this.label_intake = new System.Windows.Forms.Label();
            this.comboBox_bloodtype = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label_donatedbefore = new System.Windows.Forms.Label();
            this.label_diseases = new System.Windows.Forms.Label();
            this.label_bloodtype = new System.Windows.Forms.Label();
            this.combo_dept = new System.Windows.Forms.ComboBox();
            this.label_dept = new System.Windows.Forms.Label();
            this.text_student_id = new System.Windows.Forms.TextBox();
            this.label_id = new System.Windows.Forms.Label();
            this.text_diseases = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.label_name = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_indexID = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.button_View = new System.Windows.Forms.Button();
            this.button_previous = new System.Windows.Forms.Button();
            this.button_Next = new System.Windows.Forms.Button();
            this.button_uploadimage = new System.Windows.Forms.Button();
            this.pictureBox1_dp = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).BeginInit();
            this.SuspendLayout();
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_exit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit.ForeColor = System.Drawing.Color.White;
            this.button_exit.Location = new System.Drawing.Point(467, 575);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(90, 35);
            this.button_exit.TabIndex = 288;
            this.button_exit.Text = "EXIT";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // comboBox_gender
            // 
            this.comboBox_gender.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_gender.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_gender.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_gender.FormattingEnabled = true;
            this.comboBox_gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.comboBox_gender.Location = new System.Drawing.Point(510, 487);
            this.comboBox_gender.Name = "comboBox_gender";
            this.comboBox_gender.Size = new System.Drawing.Size(125, 27);
            this.comboBox_gender.TabIndex = 287;
            this.comboBox_gender.Text = "Select";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(170, 197);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 26);
            this.label8.TabIndex = 286;
            this.label8.Text = "*";
            this.label8.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(170, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 26);
            this.label4.TabIndex = 284;
            this.label4.Text = "*";
            this.label4.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(474, 496);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 26);
            this.label10.TabIndex = 283;
            this.label10.Text = "*";
            this.label10.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(162, 493);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 26);
            this.label6.TabIndex = 282;
            this.label6.Text = "*";
            this.label6.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(162, 453);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 26);
            this.label5.TabIndex = 281;
            this.label5.Text = "*";
            this.label5.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(170, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 26);
            this.label3.TabIndex = 280;
            this.label3.Text = "*";
            this.label3.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(170, 368);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 26);
            this.label7.TabIndex = 279;
            this.label7.Text = "*";
            this.label7.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(434, 329);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 26);
            this.label2.TabIndex = 278;
            this.label2.Text = "*";
            this.label2.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(170, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 26);
            this.label1.TabIndex = 285;
            this.label1.Text = "*";
            this.label1.Visible = false;
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.DarkGreen;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(10, 4);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(342, 40);
            this.button_home.TabIndex = 275;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // button_adminOR_user
            // 
            this.button_adminOR_user.BackColor = System.Drawing.Color.SteelBlue;
            this.button_adminOR_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_adminOR_user.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_adminOR_user.ForeColor = System.Drawing.Color.White;
            this.button_adminOR_user.Location = new System.Drawing.Point(358, 4);
            this.button_adminOR_user.Name = "button_adminOR_user";
            this.button_adminOR_user.Size = new System.Drawing.Size(240, 40);
            this.button_adminOR_user.TabIndex = 276;
            this.button_adminOR_user.Text = "Admin";
            this.button_adminOR_user.UseVisualStyleBackColor = false;
            this.button_adminOR_user.Click += new System.EventHandler(this.button_adminOR_user_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Red;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(604, 4);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(90, 40);
            this.button_logout.TabIndex = 277;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            // 
            // dateTimePicker_lastdonation
            // 
            this.dateTimePicker_lastdonation.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_lastdonation.Location = new System.Drawing.Point(198, 487);
            this.dateTimePicker_lastdonation.Name = "dateTimePicker_lastdonation";
            this.dateTimePicker_lastdonation.Size = new System.Drawing.Size(216, 23);
            this.dateTimePicker_lastdonation.TabIndex = 274;
            // 
            // button_clear
            // 
            this.button_clear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_clear.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear.ForeColor = System.Drawing.Color.White;
            this.button_clear.Location = new System.Drawing.Point(371, 575);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(90, 35);
            this.button_clear.TabIndex = 273;
            this.button_clear.Text = "CLEAR";
            this.button_clear.UseVisualStyleBackColor = false;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.SteelBlue;
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update.ForeColor = System.Drawing.Color.White;
            this.button_update.Location = new System.Drawing.Point(275, 575);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(90, 35);
            this.button_update.TabIndex = 272;
            this.button_update.Text = "UPDATE";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // text_age
            // 
            this.text_age.BackColor = System.Drawing.SystemColors.Info;
            this.text_age.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_age.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_age.Location = new System.Drawing.Point(563, 366);
            this.text_age.Name = "text_age";
            this.text_age.Size = new System.Drawing.Size(71, 27);
            this.text_age.TabIndex = 271;
            this.text_age.Text = "auto";
            this.text_age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_age.Enter += new System.EventHandler(this.text_age_Enter);
            this.text_age.Leave += new System.EventHandler(this.text_age_Leave);
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_age.Location = new System.Drawing.Point(438, 372);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(36, 15);
            this.label_age.TabIndex = 270;
            this.label_age.Text = "AGE :";
            // 
            // dateTimePicker_birthday
            // 
            this.dateTimePicker_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_birthday.Location = new System.Drawing.Point(198, 366);
            this.dateTimePicker_birthday.Name = "dateTimePicker_birthday";
            this.dateTimePicker_birthday.Size = new System.Drawing.Size(216, 23);
            this.dateTimePicker_birthday.TabIndex = 269;
            // 
            // label_lastdonation
            // 
            this.label_lastdonation.AutoSize = true;
            this.label_lastdonation.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_lastdonation.Location = new System.Drawing.Point(72, 493);
            this.label_lastdonation.Name = "label_lastdonation";
            this.label_lastdonation.Size = new System.Drawing.Size(89, 15);
            this.label_lastdonation.TabIndex = 268;
            this.label_lastdonation.Text = "Last Donation :";
            // 
            // radioButton_donated_no
            // 
            this.radioButton_donated_no.AutoSize = true;
            this.radioButton_donated_no.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_donated_no.Location = new System.Drawing.Point(584, 453);
            this.radioButton_donated_no.Name = "radioButton_donated_no";
            this.radioButton_donated_no.Size = new System.Drawing.Size(43, 19);
            this.radioButton_donated_no.TabIndex = 267;
            this.radioButton_donated_no.TabStop = true;
            this.radioButton_donated_no.Text = "NO";
            this.radioButton_donated_no.UseVisualStyleBackColor = true;
            // 
            // radioButton_donated_yes
            // 
            this.radioButton_donated_yes.AutoSize = true;
            this.radioButton_donated_yes.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_donated_yes.Location = new System.Drawing.Point(502, 453);
            this.radioButton_donated_yes.Name = "radioButton_donated_yes";
            this.radioButton_donated_yes.Size = new System.Drawing.Size(44, 19);
            this.radioButton_donated_yes.TabIndex = 266;
            this.radioButton_donated_yes.TabStop = true;
            this.radioButton_donated_yes.Text = "YES";
            this.radioButton_donated_yes.UseVisualStyleBackColor = true;
            // 
            // text_address
            // 
            this.text_address.BackColor = System.Drawing.SystemColors.Info;
            this.text_address.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_address.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_address.Location = new System.Drawing.Point(198, 401);
            this.text_address.Name = "text_address";
            this.text_address.Size = new System.Drawing.Size(437, 27);
            this.text_address.TabIndex = 264;
            this.text_address.Text = "Enter your full adress";
            this.text_address.TextChanged += new System.EventHandler(this.text_address_TextChanged);
            this.text_address.Enter += new System.EventHandler(this.text_address_Enter);
            this.text_address.Leave += new System.EventHandler(this.text_address_Leave);
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_address.Location = new System.Drawing.Point(72, 407);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(63, 15);
            this.label_address.TabIndex = 263;
            this.label_address.Text = "ADDRESS :";
            // 
            // text_email
            // 
            this.text_email.BackColor = System.Drawing.SystemColors.Info;
            this.text_email.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_email.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_email.Location = new System.Drawing.Point(458, 290);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(177, 27);
            this.text_email.TabIndex = 261;
            this.text_email.Text = "someone@example.com";
            this.text_email.Enter += new System.EventHandler(this.text_email_Enter);
            this.text_email.Leave += new System.EventHandler(this.text_email_Leave);
            // 
            // label_birthday
            // 
            this.label_birthday.AutoSize = true;
            this.label_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_birthday.Location = new System.Drawing.Point(72, 372);
            this.label_birthday.Name = "label_birthday";
            this.label_birthday.Size = new System.Drawing.Size(45, 15);
            this.label_birthday.TabIndex = 260;
            this.label_birthday.Text = "BIRTH :";
            // 
            // label_emali
            // 
            this.label_emali.AutoSize = true;
            this.label_emali.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_emali.Location = new System.Drawing.Point(344, 296);
            this.label_emali.Name = "label_emali";
            this.label_emali.Size = new System.Drawing.Size(48, 15);
            this.label_emali.TabIndex = 259;
            this.label_emali.Text = "EMAIL :";
            // 
            // text_phone
            // 
            this.text_phone.BackColor = System.Drawing.SystemColors.Info;
            this.text_phone.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_phone.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_phone.Location = new System.Drawing.Point(458, 328);
            this.text_phone.Name = "text_phone";
            this.text_phone.Size = new System.Drawing.Size(177, 27);
            this.text_phone.TabIndex = 262;
            this.text_phone.Text = "01700000XXX";
            this.text_phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_phone.Enter += new System.EventHandler(this.text_phone_Enter);
            this.text_phone.Leave += new System.EventHandler(this.text_phone_Leave);
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phone.Location = new System.Drawing.Point(344, 337);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(53, 15);
            this.label_phone.TabIndex = 258;
            this.label_phone.Text = "PHONE :";
            // 
            // text_city
            // 
            this.text_city.BackColor = System.Drawing.SystemColors.Info;
            this.text_city.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_city.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_city.Location = new System.Drawing.Point(198, 325);
            this.text_city.Name = "text_city";
            this.text_city.Size = new System.Drawing.Size(90, 27);
            this.text_city.TabIndex = 257;
            this.text_city.Text = "your city";
            this.text_city.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_city.Enter += new System.EventHandler(this.text_city_Enter);
            this.text_city.Leave += new System.EventHandler(this.text_city_Leave);
            // 
            // label_city
            // 
            this.label_city.AutoSize = true;
            this.label_city.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_city.Location = new System.Drawing.Point(72, 331);
            this.label_city.Name = "label_city";
            this.label_city.Size = new System.Drawing.Size(37, 15);
            this.label_city.TabIndex = 254;
            this.label_city.Text = "CITY :";
            // 
            // text_section
            // 
            this.text_section.BackColor = System.Drawing.SystemColors.Info;
            this.text_section.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_section.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_section.Location = new System.Drawing.Point(198, 284);
            this.text_section.Name = "text_section";
            this.text_section.Size = new System.Drawing.Size(90, 27);
            this.text_section.TabIndex = 256;
            this.text_section.Text = "Section";
            this.text_section.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_section.Enter += new System.EventHandler(this.text_section_Enter);
            this.text_section.Leave += new System.EventHandler(this.text_section_Leave);
            // 
            // label_section
            // 
            this.label_section.AutoSize = true;
            this.label_section.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_section.Location = new System.Drawing.Point(72, 290);
            this.label_section.Name = "label_section";
            this.label_section.Size = new System.Drawing.Size(33, 15);
            this.label_section.TabIndex = 253;
            this.label_section.Text = "SEC :";
            // 
            // text_intake
            // 
            this.text_intake.BackColor = System.Drawing.SystemColors.Info;
            this.text_intake.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_intake.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_intake.Location = new System.Drawing.Point(198, 240);
            this.text_intake.Name = "text_intake";
            this.text_intake.Size = new System.Drawing.Size(90, 27);
            this.text_intake.TabIndex = 255;
            this.text_intake.Text = "Intake";
            this.text_intake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_intake.Enter += new System.EventHandler(this.text_intake_Enter);
            this.text_intake.Leave += new System.EventHandler(this.text_intake_Leave);
            // 
            // label_intake
            // 
            this.label_intake.AutoSize = true;
            this.label_intake.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_intake.Location = new System.Drawing.Point(72, 246);
            this.label_intake.Name = "label_intake";
            this.label_intake.Size = new System.Drawing.Size(52, 15);
            this.label_intake.TabIndex = 252;
            this.label_intake.Text = "INTAKE :";
            // 
            // comboBox_bloodtype
            // 
            this.comboBox_bloodtype.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_bloodtype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_bloodtype.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_bloodtype.FormattingEnabled = true;
            this.comboBox_bloodtype.Items.AddRange(new object[] {
            "A+",
            "B+",
            "O+",
            "AB+",
            "A-",
            "B-",
            "O-",
            "AB-",
            "Other"});
            this.comboBox_bloodtype.Location = new System.Drawing.Point(198, 443);
            this.comboBox_bloodtype.Name = "comboBox_bloodtype";
            this.comboBox_bloodtype.Size = new System.Drawing.Size(108, 27);
            this.comboBox_bloodtype.TabIndex = 251;
            this.comboBox_bloodtype.Text = "Blood Group";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(428, 493);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 15);
            this.label9.TabIndex = 249;
            this.label9.Text = "Gender";
            // 
            // label_donatedbefore
            // 
            this.label_donatedbefore.AutoSize = true;
            this.label_donatedbefore.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_donatedbefore.Location = new System.Drawing.Point(428, 455);
            this.label_donatedbefore.Name = "label_donatedbefore";
            this.label_donatedbefore.Size = new System.Drawing.Size(52, 15);
            this.label_donatedbefore.TabIndex = 248;
            this.label_donatedbefore.Text = "ELIGIBLE";
            // 
            // label_diseases
            // 
            this.label_diseases.AutoSize = true;
            this.label_diseases.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_diseases.Location = new System.Drawing.Point(71, 533);
            this.label_diseases.Name = "label_diseases";
            this.label_diseases.Size = new System.Drawing.Size(103, 15);
            this.label_diseases.TabIndex = 247;
            this.label_diseases.Text = "DISEASES (if any) :";
            // 
            // label_bloodtype
            // 
            this.label_bloodtype.AutoSize = true;
            this.label_bloodtype.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bloodtype.Location = new System.Drawing.Point(71, 455);
            this.label_bloodtype.Name = "label_bloodtype";
            this.label_bloodtype.Size = new System.Drawing.Size(82, 15);
            this.label_bloodtype.TabIndex = 246;
            this.label_bloodtype.Text = "BLOOD TYPE :";
            // 
            // combo_dept
            // 
            this.combo_dept.BackColor = System.Drawing.SystemColors.Info;
            this.combo_dept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_dept.ForeColor = System.Drawing.SystemColors.GrayText;
            this.combo_dept.FormattingEnabled = true;
            this.combo_dept.Items.AddRange(new object[] {
            "CSE",
            "EEE",
            "ARCHITECTURE",
            "TEXTILE",
            "BBA",
            "LLB",
            "ENGLISH",
            "ECONOMICS"});
            this.combo_dept.Location = new System.Drawing.Point(198, 196);
            this.combo_dept.Name = "combo_dept";
            this.combo_dept.Size = new System.Drawing.Size(108, 27);
            this.combo_dept.TabIndex = 250;
            this.combo_dept.Text = "Select Dept.";
            // 
            // label_dept
            // 
            this.label_dept.AutoSize = true;
            this.label_dept.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dept.Location = new System.Drawing.Point(72, 202);
            this.label_dept.Name = "label_dept";
            this.label_dept.Size = new System.Drawing.Size(41, 15);
            this.label_dept.TabIndex = 245;
            this.label_dept.Text = "DEPT :";
            // 
            // text_student_id
            // 
            this.text_student_id.BackColor = System.Drawing.SystemColors.Info;
            this.text_student_id.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_student_id.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_student_id.Location = new System.Drawing.Point(198, 151);
            this.text_student_id.Name = "text_student_id";
            this.text_student_id.Size = new System.Drawing.Size(263, 27);
            this.text_student_id.TabIndex = 242;
            this.text_student_id.Text = "Enter your institution ID";
            this.text_student_id.Enter += new System.EventHandler(this.text_student_id_Enter);
            this.text_student_id.Leave += new System.EventHandler(this.text_student_id_Leave);
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_id.Location = new System.Drawing.Point(72, 157);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(46, 15);
            this.label_id.TabIndex = 241;
            this.label_id.Text = "ID NO :";
            // 
            // text_diseases
            // 
            this.text_diseases.BackColor = System.Drawing.SystemColors.Info;
            this.text_diseases.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_diseases.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_diseases.Location = new System.Drawing.Point(198, 527);
            this.text_diseases.Name = "text_diseases";
            this.text_diseases.Size = new System.Drawing.Size(437, 27);
            this.text_diseases.TabIndex = 244;
            this.text_diseases.Text = "name of disease";
            this.text_diseases.Enter += new System.EventHandler(this.text_diseases_Enter);
            this.text_diseases.Leave += new System.EventHandler(this.text_diseases_Leave);
            // 
            // text_name
            // 
            this.text_name.BackColor = System.Drawing.SystemColors.Info;
            this.text_name.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_name.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_name.Location = new System.Drawing.Point(198, 107);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(263, 27);
            this.text_name.TabIndex = 243;
            this.text_name.Text = "Enter your full name";
            this.text_name.Enter += new System.EventHandler(this.text_name_Enter);
            this.text_name.Leave += new System.EventHandler(this.text_name_Leave);
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.Location = new System.Drawing.Point(72, 113);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(48, 15);
            this.label_name.TabIndex = 240;
            this.label_name.Text = "NAME :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(71, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 15);
            this.label11.TabIndex = 290;
            this.label11.Text = "INDEX ID :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(149, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 19);
            this.label12.TabIndex = 291;
            this.label12.Text = "***";
            // 
            // textBox_indexID
            // 
            this.textBox_indexID.BackColor = System.Drawing.Color.LightSkyBlue;
            this.textBox_indexID.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_indexID.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_indexID.Location = new System.Drawing.Point(198, 64);
            this.textBox_indexID.Name = "textBox_indexID";
            this.textBox_indexID.Size = new System.Drawing.Size(71, 27);
            this.textBox_indexID.TabIndex = 292;
            this.textBox_indexID.Text = "index";
            this.textBox_indexID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_indexID.Enter += new System.EventHandler(this.textBox_indexID_Enter);
            this.textBox_indexID.Leave += new System.EventHandler(this.textBox_indexID_Leave);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(277, 70);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 15);
            this.label13.TabIndex = 290;
            this.label13.Text = "USERNAME :";
            // 
            // textBox_username
            // 
            this.textBox_username.BackColor = System.Drawing.Color.LightSkyBlue;
            this.textBox_username.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_username.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_username.Location = new System.Drawing.Point(358, 64);
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(162, 27);
            this.textBox_username.TabIndex = 292;
            this.textBox_username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_View
            // 
            this.button_View.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_View.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_View.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_View.ForeColor = System.Drawing.SystemColors.Info;
            this.button_View.Location = new System.Drawing.Point(545, 59);
            this.button_View.Name = "button_View";
            this.button_View.Size = new System.Drawing.Size(90, 35);
            this.button_View.TabIndex = 293;
            this.button_View.Text = "VIEW";
            this.button_View.UseVisualStyleBackColor = false;
            this.button_View.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_previous
            // 
            this.button_previous.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_previous.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_previous.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_previous.ForeColor = System.Drawing.SystemColors.Info;
            this.button_previous.Location = new System.Drawing.Point(179, 575);
            this.button_previous.Name = "button_previous";
            this.button_previous.Size = new System.Drawing.Size(90, 35);
            this.button_previous.TabIndex = 294;
            this.button_previous.Text = "PREV";
            this.button_previous.UseVisualStyleBackColor = false;
            this.button_previous.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button_Next
            // 
            this.button_Next.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_Next.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Next.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Next.ForeColor = System.Drawing.SystemColors.Info;
            this.button_Next.Location = new System.Drawing.Point(563, 574);
            this.button_Next.Name = "button_Next";
            this.button_Next.Size = new System.Drawing.Size(90, 35);
            this.button_Next.TabIndex = 295;
            this.button_Next.Text = "NEXT";
            this.button_Next.UseVisualStyleBackColor = false;
            this.button_Next.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_uploadimage
            // 
            this.button_uploadimage.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_uploadimage.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uploadimage.ForeColor = System.Drawing.Color.GhostWhite;
            this.button_uploadimage.Location = new System.Drawing.Point(538, 244);
            this.button_uploadimage.Name = "button_uploadimage";
            this.button_uploadimage.Size = new System.Drawing.Size(97, 36);
            this.button_uploadimage.TabIndex = 297;
            this.button_uploadimage.Text = "UPLOAD";
            this.button_uploadimage.UseVisualStyleBackColor = false;
            this.button_uploadimage.Click += new System.EventHandler(this.button_uploadimage_Click);
            // 
            // pictureBox1_dp
            // 
            this.pictureBox1_dp.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox1_dp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_dp.Image")));
            this.pictureBox1_dp.Location = new System.Drawing.Point(537, 100);
            this.pictureBox1_dp.Name = "pictureBox1_dp";
            this.pictureBox1_dp.Padding = new System.Windows.Forms.Padding(3);
            this.pictureBox1_dp.Size = new System.Drawing.Size(98, 126);
            this.pictureBox1_dp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_dp.TabIndex = 296;
            this.pictureBox1_dp.TabStop = false;
            // 
            // UpdateDonorProfileAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button_uploadimage);
            this.Controls.Add(this.pictureBox1_dp);
            this.Controls.Add(this.button_Next);
            this.Controls.Add(this.button_previous);
            this.Controls.Add(this.button_View);
            this.Controls.Add(this.textBox_username);
            this.Controls.Add(this.textBox_indexID);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.comboBox_gender);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.button_adminOR_user);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.dateTimePicker_lastdonation);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.text_age);
            this.Controls.Add(this.label_age);
            this.Controls.Add(this.dateTimePicker_birthday);
            this.Controls.Add(this.label_lastdonation);
            this.Controls.Add(this.radioButton_donated_no);
            this.Controls.Add(this.radioButton_donated_yes);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.text_email);
            this.Controls.Add(this.label_birthday);
            this.Controls.Add(this.label_emali);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.text_city);
            this.Controls.Add(this.label_city);
            this.Controls.Add(this.text_section);
            this.Controls.Add(this.label_section);
            this.Controls.Add(this.text_intake);
            this.Controls.Add(this.label_intake);
            this.Controls.Add(this.comboBox_bloodtype);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label_donatedbefore);
            this.Controls.Add(this.label_diseases);
            this.Controls.Add(this.label_bloodtype);
            this.Controls.Add(this.combo_dept);
            this.Controls.Add(this.label_dept);
            this.Controls.Add(this.text_student_id);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.text_diseases);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.label_name);
            this.Name = "UpdateDonorProfileAdmin";
            this.Text = "Admin CP update donor";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_exit;
        public System.Windows.Forms.ComboBox comboBox_gender;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_home;
        public System.Windows.Forms.Button button_adminOR_user;
        private System.Windows.Forms.Button button_logout;
        public System.Windows.Forms.DateTimePicker dateTimePicker_lastdonation;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_update;
        public System.Windows.Forms.TextBox text_age;
        private System.Windows.Forms.Label label_age;
        public System.Windows.Forms.DateTimePicker dateTimePicker_birthday;
        private System.Windows.Forms.Label label_lastdonation;
        public System.Windows.Forms.RadioButton radioButton_donated_no;
        public System.Windows.Forms.RadioButton radioButton_donated_yes;
        public System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.Label label_address;
        public System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.Label label_birthday;
        private System.Windows.Forms.Label label_emali;
        public System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Label label_phone;
        public System.Windows.Forms.TextBox text_city;
        private System.Windows.Forms.Label label_city;
        public System.Windows.Forms.TextBox text_section;
        private System.Windows.Forms.Label label_section;
        public System.Windows.Forms.TextBox text_intake;
        private System.Windows.Forms.Label label_intake;
        public System.Windows.Forms.ComboBox comboBox_bloodtype;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_donatedbefore;
        private System.Windows.Forms.Label label_diseases;
        private System.Windows.Forms.Label label_bloodtype;
        public System.Windows.Forms.ComboBox combo_dept;
        private System.Windows.Forms.Label label_dept;
        public System.Windows.Forms.TextBox text_student_id;
        private System.Windows.Forms.Label label_id;
        public System.Windows.Forms.TextBox text_diseases;
        public System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox textBox_indexID;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_username;
        private System.Windows.Forms.Button button_View;
        private System.Windows.Forms.Button button_previous;
        private System.Windows.Forms.Button button_Next;
        private System.Windows.Forms.Button button_uploadimage;
        private System.Windows.Forms.PictureBox pictureBox1_dp;
    }
}