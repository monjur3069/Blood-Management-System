﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class UpdateDonorProfileAdmin : Form
    {
        private string tempImagePath = null;

        public UpdateDonorProfileAdmin()
        {
            InitializeComponent();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            updateProfileByAdmin();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {

        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            textBox_indexID.Text = null;
            textBox_username.Text = "";
            
            text_name.Text = "";
            text_student_id.Text = "";
            //combo_dept combo box
            combo_dept.Text = "Select Dept.";
            text_intake.Text = "";
            text_section.Text = "";
            text_phone.Text = "";
            text_email.Text = "";
            //Birth_Day and donationDay reset
            //dateTimePicker_birthday.Value = DateTime.Now;
            //dateTimePicker_lastdonation.Value = DateTime.Now;
            DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
            dateTimePicker_birthday.Value = setBirthDayTime;

            DateTime setLastDonationTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
            dateTimePicker_lastdonation.Value = setLastDonationTime;

            text_age.Text = "";
            text_city.Text = "";
            text_address.Text = "";
            // Blood_Group combo box
            comboBox_bloodtype.Text = "Blood Group";
            comboBox_gender.Text = "Select";
            radioButton_donated_no.Checked = false;
            radioButton_donated_yes.Checked = false;

            text_diseases.Text = "";
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewDonorInfobyIndex();
        }

        private void ViewDonorInfobyIndex()
        {
            
            string indexID = textBox_indexID.Text.Trim().ToString();
           // string username = textBox_username.Text.Trim().ToString();
            string testIndex = null;

            if ((!string.IsNullOrEmpty(indexID)) && (indexID != "index"))
            {
                string ConnectString = ConnectionString.connString;
                MySqlConnection conn = new MySqlConnection(ConnectString);

                try
                {

                    //opening connection
                    conn.Open();

                    DataTable dt = new DataTable();

                    MySqlDataReader myReader = null;

                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases, imgName from donortable where Donor_Index = '" + indexID + "' ", conn);
                    myReader = myCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        testIndex = (myReader["Donor_Index"].ToString());
                    }
                    if (testIndex != indexID)
                    {
                        textBox_indexID.ForeColor = Color.Gray;
                        text_name.ForeColor = Color.Gray;
                        text_student_id.ForeColor = Color.Gray;
                        text_intake.ForeColor = Color.Gray;
                        text_section.ForeColor = Color.Gray;
                        combo_dept.ForeColor = Color.Gray; ;
                        comboBox_gender.ForeColor = Color.Gray;
                        comboBox_bloodtype.ForeColor = Color.Gray;
                        text_city.ForeColor = Color.Gray;

                        text_email.ForeColor = Color.Gray;
                        text_phone.ForeColor = Color.Gray;
                        text_age.ForeColor = Color.Gray;
                        text_address.ForeColor = Color.Gray;
                        text_diseases.ForeColor = Color.Gray;

                        string paths = Application.StartupPath;
                        pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + "imagedefault.jpg");

                        MessageBox.Show(" Donor Not Found! ");

                        myReader.Close();
                        conn.Close();

                    }
                    else
                    {
                        //assigning color property.

                        textBox_username.ForeColor = Color.Black;
                        textBox_indexID.ForeColor = Color.Black;
                        text_name.ForeColor = Color.Black;
                        text_student_id.ForeColor = Color.Black;
                        text_intake.ForeColor = Color.Black;
                        text_section.ForeColor = Color.Black;
                        combo_dept.ForeColor = Color.Black; ;
                        comboBox_gender.ForeColor = Color.Black;
                        comboBox_bloodtype.ForeColor = Color.Black;
                        text_city.ForeColor = Color.Black; 
                       
                        text_email.ForeColor = Color.Black;
                        text_phone.ForeColor = Color.Black;
                        text_age.ForeColor = Color.Black;
                        text_address.ForeColor = Color.Black;
                        text_diseases.ForeColor = Color.Black;


                        //assigning DB value to fields
                        textBox_username.Text = (myReader["username"].ToString());
                        
                        textBox_indexID.Text = (myReader["Donor_Index"].ToString());
                        text_name.Text = (myReader["Student_Name"].ToString());
                        text_student_id.Text = (myReader["Student_ID"].ToString());
                        combo_dept.Text = (myReader["Department"].ToString());
                        text_intake.Text = (myReader["Intake"].ToString());
                        text_section.Text = (myReader["Section"].ToString());
                        text_phone.Text = (myReader["Phone_No"].ToString());
                        text_email.Text = (myReader["Email_ID"].ToString().ToLower());

                        // Saving DB BirthDay string information to a local string
                        string BirthDayTemp = (myReader["Birth_Day"].ToString());

                        text_age.Text = (myReader["Age"].ToString());
                        text_city.Text = (myReader["City"].ToString());
                        text_address.Text = (myReader["Address"].ToString());
                        comboBox_bloodtype.Text = (myReader["Blood_Group"].ToString());
                        comboBox_gender.Text = (myReader["Gender"].ToString());
                        // eligibility need to check first and then need to convert to radio button value.
                        string EligibilityTemp = (myReader["Eligibility"].ToString().ToUpper());

                        //same as birthday as it is same type
                        string LastDonationTemp = (myReader["Last_Donation"].ToString());

                        text_diseases.Text = (myReader["Diseases"].ToString());

                        string tempLoadImagePath = (myReader["imgName"].ToString());

                        myReader.Close();
                        conn.Close();

                        // Birthday need to first stored into birthday string yyyy-MM-dd then push back to Date Time.
                        DateTime BirthDayTemp2 = DateTime.ParseExact(BirthDayTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_birthday.Value = BirthDayTemp2;

                        DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_lastdonation.Value = LastDonationTemp2;

                        /***************IMGAE PATH *****************/
                        if ((tempLoadImagePath == "0") || (string.IsNullOrEmpty(tempLoadImagePath)))
                        {
                            tempLoadImagePath = "imagedefault.jpg";
                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        else
                        {

                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        /***************IMGAE PATH *****************/


                        /***************** Eligibility Issue*********************/
                        DateTime lastDonationDate = LastDonationTemp2;
                        DateTime currentDate = DateTime.Now;

                        TimeSpan difference = currentDate - lastDonationDate;

                        int differenceInDays = difference.Days;

                        // int differenceInHours = difference.Hours;
                        //string totalDays = differenceInDays.ToString();
                        //return differenceInDays;

                       // string radioValue = "";

                        if (differenceInDays >= 90)
                        {
                            radioButton_donated_yes.Checked = true;
                            radioButton_donated_no.Checked = false;
                           // radioValue = "YES";
                        }
                        else
                        {
                            radioButton_donated_yes.Checked = false;
                            radioButton_donated_no.Checked = true;
                            //radioValue = "NO";
                        }
                        /***************** Eligibility Issue*********************/


                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Empty index!");
            }
            

        }

      

        private void button2_Click(object sender, EventArgs e)
        {
            ViewNextProfile();

        }

        private void ViewNextProfile()
        {
            string indexID = textBox_indexID.Text.Trim().ToString();
            int tempIndexID = 0;
            string testIndex = null;

            if ((!string.IsNullOrEmpty(indexID)) && (indexID != "index"))
            {
                tempIndexID = int.Parse(indexID) + 1;
                indexID = tempIndexID.ToString();

                string ConnectString = ConnectionString.connString;
                MySqlConnection conn = new MySqlConnection(ConnectString);

                try
                {

                    //opening connection
                    conn.Open();

                    DataTable dt = new DataTable();

                    MySqlDataReader myReader = null;

                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases, imgName from donortable where Donor_Index = '" + indexID + "' ", conn);
                    myReader = myCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        testIndex = (myReader["Donor_Index"].ToString());
                    }
                    if (testIndex != indexID)
                    {
                        textBox_indexID.Text = tempIndexID.ToString();
                       
                        myReader.Close();
                        conn.Close();

                        textBox_indexID.ForeColor = Color.Gray;
                        text_name.ForeColor = Color.Gray;
                        text_student_id.ForeColor = Color.Gray;
                        text_intake.ForeColor = Color.Gray;
                        text_section.ForeColor = Color.Gray;
                        combo_dept.ForeColor = Color.Gray; ;
                        comboBox_gender.ForeColor = Color.Gray;
                        comboBox_bloodtype.ForeColor = Color.Gray;
                        text_city.ForeColor = Color.Gray;

                        text_email.ForeColor = Color.Gray;
                        text_phone.ForeColor = Color.Gray;
                        text_age.ForeColor = Color.Gray;
                        text_address.ForeColor = Color.Gray;
                        text_diseases.ForeColor = Color.Gray;

                        textBox_username.Text = "";
                        text_name.Text = "Enter your full name";
                        text_student_id.Text = "Enter your Institution ID";
                        //combo_dept combo box
                        combo_dept.Text = "Select Dept.";
                        text_intake.Text = "Intake";
                        text_section.Text = "Section";
                        text_phone.Text = "01700000XXX";
                        text_email.Text = "someone@example.com";
                        //Birth_Day and donationDay reset
                        //dateTimePicker_birthday.Value = DateTime.Now;
                        //dateTimePicker_lastdonation.Value = DateTime.Now;
                        DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_birthday.Value = setBirthDayTime;

                        DateTime setLastDonationTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_lastdonation.Value = setLastDonationTime;

                        text_age.Text = "auto";
                        text_city.Text = "your city";
                        text_address.Text = "Enter your full address";
                        // Blood_Group combo box
                        comboBox_bloodtype.Text = "Blood Group";
                        comboBox_gender.Text = "Select";
                        radioButton_donated_no.Checked = false;
                        radioButton_donated_yes.Checked = false;

                        text_diseases.Text = "name of disease";
                        //MessageBox.Show(" Donor Not Found! ");

                        string paths = Application.StartupPath;
                        pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + "imagedefault.jpg");

                    }
                    else
                    {
                        //assigning color property otherwise it will show default gray color

                        textBox_username.ForeColor = Color.Black;
                        textBox_indexID.ForeColor = Color.Black;
                        text_name.ForeColor = Color.Black;
                        text_student_id.ForeColor = Color.Black;
                        text_intake.ForeColor = Color.Black;
                        text_section.ForeColor = Color.Black;
                        combo_dept.ForeColor = Color.Black; ;
                        comboBox_gender.ForeColor = Color.Black;
                        comboBox_bloodtype.ForeColor = Color.Black;
                        text_city.ForeColor = Color.Black;

                        text_email.ForeColor = Color.Black;
                        text_phone.ForeColor = Color.Black;
                        text_age.ForeColor = Color.Black;
                        text_address.ForeColor = Color.Black;
                        text_diseases.ForeColor = Color.Black;

                        //Assigning DB value to fields

                        textBox_indexID.Text = (myReader["Donor_Index"].ToString());
                        textBox_username.Text = (myReader["username"].ToString());

                        text_name.Text = (myReader["Student_Name"].ToString());
                        text_student_id.Text = (myReader["Student_ID"].ToString());
                        combo_dept.Text = (myReader["Department"].ToString());
                        text_intake.Text = (myReader["Intake"].ToString());
                        text_section.Text = (myReader["Section"].ToString());
                        text_phone.Text = (myReader["Phone_No"].ToString());
                        text_email.Text = (myReader["Email_ID"].ToString());

                        // Saving DB BirthDay string information to a local string
                        string BirthDayTemp = (myReader["Birth_Day"].ToString());

                        text_age.Text = (myReader["Age"].ToString());
                        text_city.Text = (myReader["City"].ToString());
                        text_address.Text = (myReader["Address"].ToString());
                        comboBox_bloodtype.Text = (myReader["Blood_Group"].ToString());
                        comboBox_gender.Text = (myReader["Gender"].ToString());
                        // eligibility need to check first and then need to convert to radio button value.
                        string EligibilityTemp = (myReader["Eligibility"].ToString().ToUpper());

                        //same as birthday as it is same type
                        string LastDonationTemp = (myReader["Last_Donation"].ToString());
                        string tempLoadImagePath = (myReader["imgName"].ToString());

                        text_diseases.Text = (myReader["Diseases"].ToString());

                        myReader.Close();
                        conn.Close();

                        // Birthday need to first stored into birthday string yyyy-MM-dd then push back to Date Time.
                        DateTime BirthDayTemp2 = DateTime.ParseExact(BirthDayTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_birthday.Value = BirthDayTemp2;

                        if (EligibilityTemp == "YES")
                        {
                            radioButton_donated_yes.Checked = true;
                            radioButton_donated_no.Checked = false;
                        }
                        else
                        {
                            radioButton_donated_yes.Checked = false;
                            radioButton_donated_no.Checked = true;
                        }


                        DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_lastdonation.Value = LastDonationTemp2;


                        /***************IMGAE PATH *****************/

                                         
                        if ((tempLoadImagePath=="0")||(string.IsNullOrEmpty(tempLoadImagePath)))
                        {
                            tempLoadImagePath = "imagedefault.jpg";
                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        else
                        {

                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        } 
                        /***************IMGAE PATH *****************/

                        /***************** Eligibility Issue*********************/
                        DateTime lastDonationDate = LastDonationTemp2;
                        DateTime currentDate = DateTime.Now;

                        TimeSpan difference = currentDate - lastDonationDate;

                        int differenceInDays = difference.Days;

                        // int differenceInHours = difference.Hours;
                        //string totalDays = differenceInDays.ToString();
                        //return differenceInDays;

                        //string radioValue = "";

                        if (differenceInDays >= 90)
                        {
                            radioButton_donated_yes.Checked = true;
                            radioButton_donated_no.Checked = false;
                            //radioValue = "YES";
                        }
                        else
                        {
                            radioButton_donated_yes.Checked = false;
                            radioButton_donated_no.Checked = true;
                            //radioValue = "NO";
                        }
                        /***************** Eligibility Issue*********************/
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Empty Index!");
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ViewPreviousProfile();
        }

        private void ViewPreviousProfile()
        {
            string indexID = textBox_indexID.Text.Trim().ToString();
            int tempIndexID = 0;
            string testIndex = null;

            if ((!string.IsNullOrEmpty(indexID)) && (indexID != "index"))
            {
                tempIndexID = int.Parse(indexID) - 1;
                indexID = tempIndexID.ToString();

                string ConnectString = ConnectionString.connString;
                MySqlConnection conn = new MySqlConnection(ConnectString);

                try
                {

                    //opening connection
                    conn.Open();

                    DataTable dt = new DataTable();

                    MySqlDataReader myReader = null;

                    MySqlCommand myCommand = new MySqlCommand("select Donor_Index, username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases, imgName from donortable where Donor_Index = '" + indexID + "' ", conn);
                    myReader = myCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        testIndex = (myReader["Donor_Index"].ToString());
                    }
                    if (testIndex != indexID)
                    {
                        textBox_indexID.Text = tempIndexID.ToString();
                        
                        myReader.Close();
                        conn.Close();

                        textBox_indexID.ForeColor = Color.Gray;
                        text_name.ForeColor = Color.Gray;
                        text_student_id.ForeColor = Color.Gray;
                        text_intake.ForeColor = Color.Gray;
                        text_section.ForeColor = Color.Gray;
                        combo_dept.ForeColor = Color.Gray; ;
                        comboBox_gender.ForeColor = Color.Gray;
                        comboBox_bloodtype.ForeColor = Color.Gray;
                        text_city.ForeColor = Color.Gray;

                        text_email.ForeColor = Color.Gray;
                        text_phone.ForeColor = Color.Gray;
                        text_age.ForeColor = Color.Gray;
                        text_address.ForeColor = Color.Gray;
                        text_diseases.ForeColor = Color.Gray;

                        textBox_username.Text = "";
                        text_name.Text = "Enter your full name";
                        text_student_id.Text = "Enter your Institution ID";
                        //combo_dept combo box
                        combo_dept.Text = "Select Dept.";
                        text_intake.Text = "Intake";
                        text_section.Text = "Section";
                        text_phone.Text = "01700000XXX";
                        text_email.Text = "someone@example.com";
                        //Birth_Day and donationDay reset
                        //dateTimePicker_birthday.Value = DateTime.Now;
                        //dateTimePicker_lastdonation.Value = DateTime.Now;
                        DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_birthday.Value = setBirthDayTime;

                        DateTime setLastDonationTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_lastdonation.Value = setLastDonationTime;

                        text_age.Text = "auto";
                        text_city.Text = "your city";
                        text_address.Text = "Enter your full address";
                        // Blood_Group combo box
                        comboBox_bloodtype.Text = "Blood Group";
                        comboBox_gender.Text = "Select";
                        radioButton_donated_no.Checked = false;
                        radioButton_donated_yes.Checked = false;

                        text_diseases.Text = "name of disease";
                        // MessageBox.Show(" Donor Not Found! ");
                        string paths = Application.StartupPath;
                        pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + "imagedefault.jpg");

                    }
                    else
                    {
                        //assigning color property otherwise it will show default gray color
                        
                        textBox_username.ForeColor = Color.Black;
                        textBox_indexID.ForeColor = Color.Black;
                        text_name.ForeColor = Color.Black;
                        text_student_id.ForeColor = Color.Black;
                        text_intake.ForeColor = Color.Black;
                        text_section.ForeColor = Color.Black;
                        combo_dept.ForeColor = Color.Black; ;
                        comboBox_gender.ForeColor = Color.Black;
                        comboBox_bloodtype.ForeColor = Color.Black;
                        text_city.ForeColor = Color.Black;

                        text_email.ForeColor = Color.Black;
                        text_phone.ForeColor = Color.Black;
                        text_age.ForeColor = Color.Black;
                        text_address.ForeColor = Color.Black;
                        text_diseases.ForeColor = Color.Black;

                        //Assigning DB value to fields
                        textBox_indexID.Text = (myReader["Donor_Index"].ToString());
                        textBox_username.Text = (myReader["username"].ToString());

                        text_name.Text = (myReader["Student_Name"].ToString());
                        text_student_id.Text = (myReader["Student_ID"].ToString());
                        combo_dept.Text = (myReader["Department"].ToString());
                        text_intake.Text = (myReader["Intake"].ToString());
                        text_section.Text = (myReader["Section"].ToString());
                        text_phone.Text = (myReader["Phone_No"].ToString());
                        text_email.Text = (myReader["Email_ID"].ToString());

                        // Saving DB BirthDay string information to a local string
                        string BirthDayTemp = (myReader["Birth_Day"].ToString());

                        text_age.Text = (myReader["Age"].ToString());
                        text_city.Text = (myReader["City"].ToString());
                        text_address.Text = (myReader["Address"].ToString());
                        comboBox_bloodtype.Text = (myReader["Blood_Group"].ToString());
                        comboBox_gender.Text = (myReader["Gender"].ToString());
                        // eligibility need to check first and then need to convert to radio button value.
                        string EligibilityTemp = (myReader["Eligibility"].ToString().ToUpper());

                        //same as birthday as it is same type
                        string LastDonationTemp = (myReader["Last_Donation"].ToString());
                        string tempLoadImagePath = (myReader["imgName"].ToString());


                        text_diseases.Text = (myReader["Diseases"].ToString());

                        myReader.Close();
                        conn.Close();

                        /***************IMGAE PATH *****************/
                        if ((tempLoadImagePath == "0") || (string.IsNullOrEmpty(tempLoadImagePath)))
                        {
                            tempLoadImagePath = "imagedefault.jpg";
                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        else
                        {

                            string paths = Application.StartupPath;
                            pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                        }
                        /***************IMGAE PATH *****************/

                        // Birthday need to first stored into birthday string yyyy-MM-dd then push back to Date Time.
                        DateTime BirthDayTemp2 = DateTime.ParseExact(BirthDayTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_birthday.Value = BirthDayTemp2;

                        
                        DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        dateTimePicker_lastdonation.Value = LastDonationTemp2;
                        /***************** Eligibility Issue*********************/
                        DateTime lastDonationDate = LastDonationTemp2;
                        DateTime currentDate = DateTime.Now;

                        TimeSpan difference = currentDate - lastDonationDate;

                        int differenceInDays = difference.Days;

                        // int differenceInHours = difference.Hours;
                        //string totalDays = differenceInDays.ToString();
                        //return differenceInDays;

                        //string radioValue = "";

                        if (differenceInDays >= 90)
                        {
                            radioButton_donated_yes.Checked = true;
                            radioButton_donated_no.Checked = false;
                            //radioValue = "YES";
                        }
                        else
                        {
                            radioButton_donated_yes.Checked = false;
                            radioButton_donated_no.Checked = true;
                            //radioValue = "NO";
                        }
                        /***************** Eligibility Issue*********************/
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Empty Index!");
            }
        }

        private void button_adminOR_user_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void updateProfileByAdmin()
        {
            // database connection string
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                if ((comboBox_bloodtype.SelectedIndex != -1) && (combo_dept.SelectedIndex != -1) && (comboBox_gender.SelectedIndex != -1))
                {
                    // declearing local variable for input
                    //user name exist both in login info table and personalinfotable for updateUserInfoByUser to protect user to stop filling multiple form.
                    string username = textBox_username.Text.Trim().ToString();
                    string indexID = textBox_indexID.Text.Trim().ToString();

                    string Student_Name = text_name.Text.Trim();
                    string Student_ID = text_student_id.Text.Trim();
                    string Department = combo_dept.SelectedItem.ToString().Trim().ToUpper();
                    string Intake = text_intake.Text.Trim().ToString();
                    string Section = text_section.Text.Trim().ToString();
                    string Phone_No = text_phone.Text.Trim().ToString();
                    string Email_ID = text_email.Text.Trim().ToString().ToLower();
                    string Birth_Day = birthday().ToString().ToUpper();
                    string Age = ageCalculation().ToString();
                    string City = text_city.Text.Trim().ToString().ToUpper();
                    string Address = text_address.Text.Trim().ToString();
                    string Blood_Group = comboBox_bloodtype.SelectedItem.ToString().Trim().ToUpper();
                    string Eligibility = checkEligibility().ToUpper();
                    string Gender = comboBox_gender.SelectedItem.ToString().Trim();
                    string Last_Donation = lastDonation().ToString();
                    string Diseases = text_diseases.Text.Trim().ToString();

                    string imagePath = tempImagePath;
                    tempImagePath = null;


                    // checking if specific fields are empty
                    if (!string.IsNullOrEmpty(Student_Name) && !string.IsNullOrEmpty(Student_ID) && !string.IsNullOrEmpty(Gender) && (Student_Name != "Enter your full name")
                        && !string.IsNullOrEmpty(Phone_No) && !string.IsNullOrEmpty(Birth_Day) && !string.IsNullOrEmpty(Last_Donation)
                        && !string.IsNullOrEmpty(Age) && !string.IsNullOrEmpty(City) && !string.IsNullOrEmpty(Age) && !string.IsNullOrEmpty(indexID) && (indexID!="index")
                        && !string.IsNullOrEmpty(Address) && !string.IsNullOrEmpty(Blood_Group) && !string.IsNullOrEmpty(Eligibility))

                    {
                        //opening connection
                        conn.Open();
                        MySqlCommand cmd = conn.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "UPDATE donortable SET username = '" + username + "', Student_Name = '" + Student_Name + "', Student_ID = '" + Student_ID + "' , Department = '" + Department + "', Intake = '" + Intake + "', Section = '" + Section + "', Phone_No = '" + Phone_No + "', Email_ID = '" + Email_ID + "', Birth_Day = '" + Birth_Day + "', Age = '" + Age + "', City = '" + City + "', Address = '" + Address + "', Blood_Group = '" + Blood_Group + "', Eligibility = '" + Eligibility + "', Gender = '" + Gender + "', Last_Donation = '" + Last_Donation + "', Diseases = '" + Diseases + "', imgName = '" + imagePath + "' WHERE Donor_Index = '" + indexID + "' ";
                        //    "insert into donortable values ('', '" + username + "', '" + Student_Name + "', '" + Student_ID + "' , '" + Department + "', '" + Intake + "', '" + Section + "', '" + Phone_No + "', '" + Email_ID + "', '" + Birth_Day + "', '" + Age + "', '" + City + "', '" + Address + "', '" + Blood_Group + "', '" + Eligibility + "', '" + Gender + "' , '" + Last_Donation + "', '" + Diseases + "' )";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Profile has been UPDATED!");
                        cmd.Cancel();
                        conn.Close();


                        string paths = Application.StartupPath;
                        string defaultpath = "imagedefault.jpg";
                        //string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 9));
                        pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + defaultpath);

                        text_name.Clear();
                        text_student_id.Clear();
                        comboBox_bloodtype.Text = "Select blood type";
                        comboBox_gender.Text = "Select";
                        combo_dept.Text = "Select Dept.";
                        radioButton_donated_no.Checked = false;
                        radioButton_donated_yes.Checked = false;
                        //Department
                        text_intake.Clear();
                        text_section.Clear();
                        text_phone.Clear();
                        text_email.Clear();
                        //Birth_Day
                        text_age.Clear();
                        text_city.Clear();
                        text_address.Clear();
                        // Blood_Group
                        //Eligibility
                        // Last_Donation.Clear();
                        text_diseases.Clear();
                        

                    }

                    else
                    {
                        label1.Visible = true;
                        label2.Visible = true;
                        label3.Visible = true;
                        label4.Visible = true;
                        label5.Visible = true;
                        label6.Visible = true;
                        label7.Visible = true;
                        
                        MessageBox.Show("Selected Field Can't be Empty!");
                    }
                }
                else
                {
                    
                    label1.Visible = true;
                    label2.Visible = true;
                    label3.Visible = true;
                    label4.Visible = true;
                    label5.Visible = true;
                    label6.Visible = true;
                    label7.Visible = true;
                    label8.Visible = true;
                    label10.Visible = true;


                    MessageBox.Show("Complete Selected Fields!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private string birthday()
        {
            string birthDate = dateTimePicker_birthday.Value.ToString("yyyy-MM-dd");
            return birthDate;
        }

        private string lastDonation()
        {
            string lastDonationDate = dateTimePicker_lastdonation.Value.ToString("yyyy-MM-dd");
            return lastDonationDate;
        }

        private int ageCalculation()
        {
            // TimeSpan age = DateTime.Now - dateTimePicker_birthday.Value;

            int _age = DateTime.Now.Year - dateTimePicker_birthday.Value.Year - (DateTime.Now.DayOfYear < dateTimePicker_birthday.Value.DayOfYear ? 1 : 0);
            return _age;

            /*int years = DateTime.Now.Year - dateTimePicker.Value.Year;

            if (dateTimePicker.Value.AddYears(years) > DateTime.Now) years--; */
        }

        private string checkEligibility()
        {

            DateTime lastDonationDate = dateTimePicker_lastdonation.Value;
            DateTime currentDate = DateTime.Now;

            TimeSpan difference = currentDate - lastDonationDate;

            int differenceInDays = difference.Days;

            // int differenceInHours = difference.Hours;
            //string totalDays = differenceInDays.ToString();
            //return differenceInDays;

            string radioValue = null;

            if (differenceInDays >= 90)
            {
                radioButton_donated_yes.Checked = true;
                radioButton_donated_no.Checked = false;
                radioValue = radioButton_donated_yes.Text.Trim();
            }
            else
            {
                radioButton_donated_yes.Checked = false;
                radioButton_donated_no.Checked = true;
                radioValue = radioButton_donated_no.Text.Trim();
            }

            return radioValue;

        }

        private void text_address_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_name_Enter(object sender, EventArgs e)
        {
            if (text_name.Text == "Enter your full name")
            {
                text_name.Text = "";
                text_name.ForeColor = Color.Black;
            }
        }

        private void text_name_Leave(object sender, EventArgs e)
        {
            if (text_name.Text == "")
            {
                text_name.Text = "Enter your full name";
                text_name.ForeColor = Color.Gray;
            }
        }

        private void text_student_id_Enter(object sender, EventArgs e)
        {
            if (text_student_id.Text == "Enter your institution ID")
            {
                text_student_id.Text = "";
                text_student_id.ForeColor = Color.Black;
            }
        }

        private void text_student_id_Leave(object sender, EventArgs e)
        {
            if (text_student_id.Text == "")
            {
                text_student_id.Text = "Enter your institution ID";
                text_student_id.ForeColor = Color.Gray;
            }
        }

        private void text_email_Enter(object sender, EventArgs e)
        {
            if (text_email.Text == "someone@example.com")
            {
                text_email.Text = "";
                text_email.ForeColor = Color.Black;
            }
        }

        private void text_email_Leave(object sender, EventArgs e)
        {
            if (text_email.Text == "")
            {
                text_email.Text = "someone@example.com";
                text_email.ForeColor = Color.Gray;
            }
        }

        private void text_intake_Enter(object sender, EventArgs e)
        {
            if (text_intake.Text == "Intake")
            {
                text_intake.Text = "";
                text_intake.ForeColor = Color.Black;
            }
        }

        private void text_intake_Leave(object sender, EventArgs e)
        {
            if (text_intake.Text == "")
            {
                text_intake.Text = "Intake";
                text_intake.ForeColor = Color.Gray;
            }
        }

        private void text_phone_Enter(object sender, EventArgs e)
        {
            if (text_phone.Text == "01700000XXX")
            {
                text_phone.Text = "";
                text_phone.ForeColor = Color.Black;
            }
        }

        private void text_phone_Leave(object sender, EventArgs e)
        {
            if (text_phone.Text == "")
            {
                text_phone.Text = "01700000XXX";
                text_phone.ForeColor = Color.Gray;
            }
        }

        private void text_section_Enter(object sender, EventArgs e)
        {
            if (text_section.Text == "Section")
            {
                text_section.Text = "";
                text_section.ForeColor = Color.Black;
            }
        }

        private void text_section_Leave(object sender, EventArgs e)
        {
            if (text_section.Text == "")
            {
                text_section.Text = "Section";
                text_section.ForeColor = Color.Gray;
            }
        }

        private void text_city_Enter(object sender, EventArgs e)
        {
            if (text_city.Text == "your city")
            {
                text_city.Text = "";
                text_city.ForeColor = Color.Black;
            }
        }

        private void text_city_Leave(object sender, EventArgs e)
        {
            if (text_city.Text == "")
            {
                text_city.Text = "your city";
                text_city.ForeColor = Color.Gray;
            }
        }

        private void text_age_Enter(object sender, EventArgs e)
        {
            if (text_age.Text == "auto")
            {
                text_age.Text = "";
                text_age.ForeColor = Color.Black;
            }
        }

        private void text_age_Leave(object sender, EventArgs e)
        {
            if (text_age.Text == "")
            {
                text_age.Text = "auto";
                text_age.ForeColor = Color.Gray;
            }
        }



        private void text_address_Enter(object sender, EventArgs e)
        {
            if (text_address.Text == "Enter your full adress")
            {
                text_address.Text = "";
                text_address.ForeColor = Color.Black;
            }
        }

        private void text_address_Leave(object sender, EventArgs e)
        {
            if (text_address.Text == "")
            {
                text_address.Text = "Enter your full adress";
                text_address.ForeColor = Color.Gray;
            }
        }

        private void text_diseases_Enter(object sender, EventArgs e)
        {
            if (text_diseases.Text == "name of disease")
            {
                text_diseases.Text = "";
                text_diseases.ForeColor = Color.Black;
            }
        }

        private void text_diseases_Leave(object sender, EventArgs e)
        {
            if (text_diseases.Text == "")
            {
                text_diseases.Text = "name of disease";
                text_diseases.ForeColor = Color.Gray;
            }
        }

       

        private void textBox_indexID_Enter(object sender, EventArgs e)
        {
            if(textBox_indexID.Text == "index")
            {
                textBox_indexID.Text = "";
                textBox_indexID.ForeColor = Color.Black;
            } 
        }

        private void textBox_indexID_Leave(object sender, EventArgs e)
        {
            if (textBox_indexID.Text == "")
            {
                textBox_indexID.Text = "index";
                textBox_indexID.ForeColor = Color.Gray;
            }
        }

        private void button_uploadimage_Click(object sender, EventArgs e)
        {
            uploadImage();
            string paths = Application.StartupPath;
            //string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 9));
            if (!string.IsNullOrEmpty(tempImagePath))
            {
                pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempImagePath);
                
            }

        }
        private void uploadImage()
        {

            OpenFileDialog ofdFindPhoto = new OpenFileDialog();

            ofdFindPhoto.InitialDirectory = @"C:\Desktop\";
            ofdFindPhoto.FileName = "";
            ofdFindPhoto.Multiselect = false;
            ofdFindPhoto.Filter = "JPEG Image|*.jpg|GIF Image|*.gif|PNG Image|*.png|BMP Image|*.bmp";
                   
                DialogResult result = ofdFindPhoto.ShowDialog();


                if (result == DialogResult.OK)

                {
                    if (ofdFindPhoto.CheckFileExists)

                    {

                        //C: \Users\rajib\Documents\Visual Studio 2015\Projects\WindowsFormsApplication9\WindowsFormsApplication9\bin\Debug
                        // the length - 0 is for going back to project folder from bin\debug folder
                        //string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 9));

                        string paths = Application.StartupPath;
                        string getImageFileName = System.IO.Path.GetFileName(ofdFindPhoto.FileName);
                        System.IO.File.Copy(ofdFindPhoto.FileName, paths + "\\donorImages\\" + getImageFileName);
                        MessageBox.Show("Successfully Uploaded");
                        tempImagePath = getImageFileName;

                    }


                }
            
        }

    }
}
