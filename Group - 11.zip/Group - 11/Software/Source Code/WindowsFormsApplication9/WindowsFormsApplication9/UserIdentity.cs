﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication9
{
    //For accessing : GlobalClass.GlobalVar = "any string value"

    static class GlobalUserName
    {
        private static string _username = null;

        public static string GlobalUser
        {
            get { return _username; }
            set { _username = value; }
        }
    }
    /*
    static class Global
    {
        private static string _globalVar = "";

        public static string GlobalVar
        {
            get { return _globalVar; }
            set { _globalVar = value; }
        }
    }
    */

    
}
