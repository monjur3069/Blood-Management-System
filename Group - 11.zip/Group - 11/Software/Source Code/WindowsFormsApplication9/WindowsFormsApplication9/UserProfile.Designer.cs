﻿namespace WindowsFormsApplication9
{
    partial class UserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserProfile));
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_home = new System.Windows.Forms.Button();
            this.button_adminOR_user = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.dateTimePicker_lastdonation = new System.Windows.Forms.DateTimePicker();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.text_age = new System.Windows.Forms.TextBox();
            this.label_age = new System.Windows.Forms.Label();
            this.dateTimePicker_birthday = new System.Windows.Forms.DateTimePicker();
            this.label_lastdonation = new System.Windows.Forms.Label();
            this.radioButton_donated_no = new System.Windows.Forms.RadioButton();
            this.radioButton_donated_yes = new System.Windows.Forms.RadioButton();
            this.text_address = new System.Windows.Forms.TextBox();
            this.label_address = new System.Windows.Forms.Label();
            this.text_email = new System.Windows.Forms.TextBox();
            this.label_birthday = new System.Windows.Forms.Label();
            this.label_emali = new System.Windows.Forms.Label();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.label_phone = new System.Windows.Forms.Label();
            this.text_city = new System.Windows.Forms.TextBox();
            this.label_city = new System.Windows.Forms.Label();
            this.text_section = new System.Windows.Forms.TextBox();
            this.label_section = new System.Windows.Forms.Label();
            this.text_intake = new System.Windows.Forms.TextBox();
            this.label_intake = new System.Windows.Forms.Label();
            this.comboBox_bloodtype = new System.Windows.Forms.ComboBox();
            this.label_donatedbefore = new System.Windows.Forms.Label();
            this.label_diseases = new System.Windows.Forms.Label();
            this.label_bloodtype = new System.Windows.Forms.Label();
            this.combo_dept = new System.Windows.Forms.ComboBox();
            this.label_dept = new System.Windows.Forms.Label();
            this.text_student_id = new System.Windows.Forms.TextBox();
            this.label_id = new System.Windows.Forms.Label();
            this.text_diseases = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.label_name = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox_gender = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_uploadimage = new System.Windows.Forms.Button();
            this.pictureBox1_dp = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(157, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 26);
            this.label8.TabIndex = 188;
            this.label8.Text = "*";
            this.label8.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(155, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 26);
            this.label4.TabIndex = 186;
            this.label4.Text = "*";
            this.label4.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(157, 486);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 26);
            this.label6.TabIndex = 185;
            this.label6.Text = "*";
            this.label6.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(157, 443);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 26);
            this.label5.TabIndex = 184;
            this.label5.Text = "*";
            this.label5.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(157, 318);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 26);
            this.label3.TabIndex = 183;
            this.label3.Text = "*";
            this.label3.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(157, 352);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 26);
            this.label7.TabIndex = 182;
            this.label7.Text = "*";
            this.label7.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(421, 312);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 26);
            this.label2.TabIndex = 181;
            this.label2.Text = "*";
            this.label2.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(155, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 26);
            this.label1.TabIndex = 187;
            this.label1.Text = "*";
            this.label1.Visible = false;
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.DarkGreen;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(8, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(342, 40);
            this.button_home.TabIndex = 178;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // button_adminOR_user
            // 
            this.button_adminOR_user.BackColor = System.Drawing.Color.SteelBlue;
            this.button_adminOR_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_adminOR_user.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_adminOR_user.ForeColor = System.Drawing.Color.White;
            this.button_adminOR_user.Location = new System.Drawing.Point(356, 12);
            this.button_adminOR_user.Name = "button_adminOR_user";
            this.button_adminOR_user.Size = new System.Drawing.Size(240, 40);
            this.button_adminOR_user.TabIndex = 179;
            this.button_adminOR_user.Text = "USER CP";
            this.button_adminOR_user.UseVisualStyleBackColor = false;
            this.button_adminOR_user.Click += new System.EventHandler(this.button_adminOR_user_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Red;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(602, 12);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(90, 40);
            this.button_logout.TabIndex = 180;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // dateTimePicker_lastdonation
            // 
            this.dateTimePicker_lastdonation.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_lastdonation.Location = new System.Drawing.Point(185, 486);
            this.dateTimePicker_lastdonation.Name = "dateTimePicker_lastdonation";
            this.dateTimePicker_lastdonation.Size = new System.Drawing.Size(216, 23);
            this.dateTimePicker_lastdonation.TabIndex = 177;
            // 
            // button_clear
            // 
            this.button_clear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear.ForeColor = System.Drawing.Color.White;
            this.button_clear.Location = new System.Drawing.Point(364, 576);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(90, 35);
            this.button_clear.TabIndex = 176;
            this.button_clear.Text = "CLEAR";
            this.button_clear.UseVisualStyleBackColor = false;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.SteelBlue;
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update.ForeColor = System.Drawing.Color.White;
            this.button_update.Location = new System.Drawing.Point(268, 576);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(90, 35);
            this.button_update.TabIndex = 174;
            this.button_update.Text = "UPDATE";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // text_age
            // 
            this.text_age.BackColor = System.Drawing.SystemColors.Info;
            this.text_age.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_age.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_age.Location = new System.Drawing.Point(551, 347);
            this.text_age.MaxLength = 3;
            this.text_age.Name = "text_age";
            this.text_age.Size = new System.Drawing.Size(71, 27);
            this.text_age.TabIndex = 172;
            this.text_age.Text = "auto";
            this.text_age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_age.Enter += new System.EventHandler(this.text_age_Enter);
            this.text_age.Leave += new System.EventHandler(this.text_age_Leave);
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_age.Location = new System.Drawing.Point(476, 353);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(36, 15);
            this.label_age.TabIndex = 171;
            this.label_age.Text = "AGE :";
            this.label_age.Click += new System.EventHandler(this.label_age_Click);
            // 
            // dateTimePicker_birthday
            // 
            this.dateTimePicker_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_birthday.Location = new System.Drawing.Point(185, 351);
            this.dateTimePicker_birthday.Name = "dateTimePicker_birthday";
            this.dateTimePicker_birthday.Size = new System.Drawing.Size(216, 23);
            this.dateTimePicker_birthday.TabIndex = 170;
            // 
            // label_lastdonation
            // 
            this.label_lastdonation.AutoSize = true;
            this.label_lastdonation.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_lastdonation.Location = new System.Drawing.Point(66, 492);
            this.label_lastdonation.Name = "label_lastdonation";
            this.label_lastdonation.Size = new System.Drawing.Size(89, 15);
            this.label_lastdonation.TabIndex = 169;
            this.label_lastdonation.Text = "Last Donation :";
            // 
            // radioButton_donated_no
            // 
            this.radioButton_donated_no.AutoSize = true;
            this.radioButton_donated_no.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_donated_no.Location = new System.Drawing.Point(579, 443);
            this.radioButton_donated_no.Name = "radioButton_donated_no";
            this.radioButton_donated_no.Size = new System.Drawing.Size(43, 19);
            this.radioButton_donated_no.TabIndex = 168;
            this.radioButton_donated_no.TabStop = true;
            this.radioButton_donated_no.Text = "NO";
            this.radioButton_donated_no.UseVisualStyleBackColor = true;
            this.radioButton_donated_no.CheckedChanged += new System.EventHandler(this.radioButton_donated_no_CheckedChanged);
            // 
            // radioButton_donated_yes
            // 
            this.radioButton_donated_yes.AutoSize = true;
            this.radioButton_donated_yes.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_donated_yes.Location = new System.Drawing.Point(497, 443);
            this.radioButton_donated_yes.Name = "radioButton_donated_yes";
            this.radioButton_donated_yes.Size = new System.Drawing.Size(44, 19);
            this.radioButton_donated_yes.TabIndex = 167;
            this.radioButton_donated_yes.TabStop = true;
            this.radioButton_donated_yes.Text = "YES";
            this.radioButton_donated_yes.UseVisualStyleBackColor = true;
            this.radioButton_donated_yes.CheckedChanged += new System.EventHandler(this.radioButton_donated_yes_CheckedChanged);
            // 
            // text_address
            // 
            this.text_address.BackColor = System.Drawing.SystemColors.Info;
            this.text_address.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_address.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_address.Location = new System.Drawing.Point(185, 392);
            this.text_address.MaxLength = 150;
            this.text_address.Name = "text_address";
            this.text_address.Size = new System.Drawing.Size(437, 27);
            this.text_address.TabIndex = 165;
            this.text_address.Text = "Enter your full adress";
            this.text_address.Enter += new System.EventHandler(this.text_address_Enter);
            this.text_address.Leave += new System.EventHandler(this.text_address_Leave);
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_address.Location = new System.Drawing.Point(66, 398);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(63, 15);
            this.label_address.TabIndex = 164;
            this.label_address.Text = "ADDRESS :";
            // 
            // text_email
            // 
            this.text_email.BackColor = System.Drawing.SystemColors.Info;
            this.text_email.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_email.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_email.Location = new System.Drawing.Point(445, 266);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(177, 27);
            this.text_email.TabIndex = 162;
            this.text_email.Text = "someone@example.com";
            this.text_email.Enter += new System.EventHandler(this.text_email_Enter);
            this.text_email.Leave += new System.EventHandler(this.text_email_Leave);
            // 
            // label_birthday
            // 
            this.label_birthday.AutoSize = true;
            this.label_birthday.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_birthday.Location = new System.Drawing.Point(66, 357);
            this.label_birthday.Name = "label_birthday";
            this.label_birthday.Size = new System.Drawing.Size(41, 15);
            this.label_birthday.TabIndex = 161;
            this.label_birthday.Text = "Birth :";
            this.label_birthday.Click += new System.EventHandler(this.label_birthday_Click);
            // 
            // label_emali
            // 
            this.label_emali.AutoSize = true;
            this.label_emali.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_emali.Location = new System.Drawing.Point(361, 272);
            this.label_emali.Name = "label_emali";
            this.label_emali.Size = new System.Drawing.Size(48, 15);
            this.label_emali.TabIndex = 160;
            this.label_emali.Text = "EMAIL :";
            this.label_emali.Click += new System.EventHandler(this.label_emali_Click);
            // 
            // text_phone
            // 
            this.text_phone.BackColor = System.Drawing.SystemColors.Info;
            this.text_phone.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_phone.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_phone.Location = new System.Drawing.Point(445, 311);
            this.text_phone.MaxLength = 15;
            this.text_phone.Name = "text_phone";
            this.text_phone.Size = new System.Drawing.Size(177, 27);
            this.text_phone.TabIndex = 163;
            this.text_phone.Text = "01700000XXX";
            this.text_phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_phone.Enter += new System.EventHandler(this.text_phone_Enter);
            this.text_phone.Leave += new System.EventHandler(this.text_phone_Leave);
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phone.Location = new System.Drawing.Point(362, 317);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(53, 15);
            this.label_phone.TabIndex = 159;
            this.label_phone.Text = "PHONE :";
            this.label_phone.Click += new System.EventHandler(this.label_phone_Click);
            // 
            // text_city
            // 
            this.text_city.BackColor = System.Drawing.SystemColors.Info;
            this.text_city.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_city.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_city.Location = new System.Drawing.Point(185, 311);
            this.text_city.MaxLength = 20;
            this.text_city.Name = "text_city";
            this.text_city.Size = new System.Drawing.Size(108, 27);
            this.text_city.TabIndex = 158;
            this.text_city.Text = "your city";
            this.text_city.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_city.Enter += new System.EventHandler(this.text_city_Enter);
            this.text_city.Leave += new System.EventHandler(this.text_city_Leave);
            // 
            // label_city
            // 
            this.label_city.AutoSize = true;
            this.label_city.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_city.Location = new System.Drawing.Point(66, 323);
            this.label_city.Name = "label_city";
            this.label_city.Size = new System.Drawing.Size(37, 15);
            this.label_city.TabIndex = 155;
            this.label_city.Text = "CITY :";
            // 
            // text_section
            // 
            this.text_section.BackColor = System.Drawing.SystemColors.Info;
            this.text_section.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_section.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_section.Location = new System.Drawing.Point(185, 266);
            this.text_section.MaxLength = 5;
            this.text_section.Name = "text_section";
            this.text_section.Size = new System.Drawing.Size(108, 27);
            this.text_section.TabIndex = 157;
            this.text_section.Text = "Section";
            this.text_section.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_section.Enter += new System.EventHandler(this.text_section_Enter);
            this.text_section.Leave += new System.EventHandler(this.text_section_Leave);
            // 
            // label_section
            // 
            this.label_section.AutoSize = true;
            this.label_section.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_section.Location = new System.Drawing.Point(66, 278);
            this.label_section.Name = "label_section";
            this.label_section.Size = new System.Drawing.Size(33, 15);
            this.label_section.TabIndex = 154;
            this.label_section.Text = "SEC :";
            // 
            // text_intake
            // 
            this.text_intake.BackColor = System.Drawing.SystemColors.Info;
            this.text_intake.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_intake.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_intake.Location = new System.Drawing.Point(183, 226);
            this.text_intake.MaxLength = 5;
            this.text_intake.Name = "text_intake";
            this.text_intake.Size = new System.Drawing.Size(108, 27);
            this.text_intake.TabIndex = 156;
            this.text_intake.Text = "Intake";
            this.text_intake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_intake.Enter += new System.EventHandler(this.text_intake_Enter);
            this.text_intake.Leave += new System.EventHandler(this.text_intake_Leave);
            // 
            // label_intake
            // 
            this.label_intake.AutoSize = true;
            this.label_intake.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_intake.Location = new System.Drawing.Point(64, 229);
            this.label_intake.Name = "label_intake";
            this.label_intake.Size = new System.Drawing.Size(52, 15);
            this.label_intake.TabIndex = 153;
            this.label_intake.Text = "INTAKE :";
            // 
            // comboBox_bloodtype
            // 
            this.comboBox_bloodtype.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_bloodtype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_bloodtype.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_bloodtype.FormattingEnabled = true;
            this.comboBox_bloodtype.Items.AddRange(new object[] {
            "A+",
            "B+",
            "O+",
            "AB+",
            "A-",
            "B-",
            "O-",
            "AB-",
            "Other"});
            this.comboBox_bloodtype.Location = new System.Drawing.Point(185, 439);
            this.comboBox_bloodtype.Name = "comboBox_bloodtype";
            this.comboBox_bloodtype.Size = new System.Drawing.Size(108, 27);
            this.comboBox_bloodtype.TabIndex = 152;
            this.comboBox_bloodtype.Text = "Blood Group";
            // 
            // label_donatedbefore
            // 
            this.label_donatedbefore.AutoSize = true;
            this.label_donatedbefore.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_donatedbefore.Location = new System.Drawing.Point(423, 445);
            this.label_donatedbefore.Name = "label_donatedbefore";
            this.label_donatedbefore.Size = new System.Drawing.Size(52, 15);
            this.label_donatedbefore.TabIndex = 150;
            this.label_donatedbefore.Text = "ELIGIBLE";
            this.label_donatedbefore.Click += new System.EventHandler(this.label_donatedbefore_Click);
            // 
            // label_diseases
            // 
            this.label_diseases.AutoSize = true;
            this.label_diseases.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_diseases.Location = new System.Drawing.Point(66, 534);
            this.label_diseases.Name = "label_diseases";
            this.label_diseases.Size = new System.Drawing.Size(103, 15);
            this.label_diseases.TabIndex = 149;
            this.label_diseases.Text = "DISEASES (if any) :";
            // 
            // label_bloodtype
            // 
            this.label_bloodtype.AutoSize = true;
            this.label_bloodtype.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bloodtype.Location = new System.Drawing.Point(66, 445);
            this.label_bloodtype.Name = "label_bloodtype";
            this.label_bloodtype.Size = new System.Drawing.Size(82, 15);
            this.label_bloodtype.TabIndex = 148;
            this.label_bloodtype.Text = "BLOOD TYPE :";
            // 
            // combo_dept
            // 
            this.combo_dept.BackColor = System.Drawing.SystemColors.Info;
            this.combo_dept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_dept.ForeColor = System.Drawing.SystemColors.GrayText;
            this.combo_dept.FormattingEnabled = true;
            this.combo_dept.Items.AddRange(new object[] {
            "CSE",
            "EEE",
            "ARCHITECTURE",
            "TEXTILE",
            "BBA",
            "LLB",
            "ENGLISH",
            "ECONOMICS"});
            this.combo_dept.Location = new System.Drawing.Point(185, 185);
            this.combo_dept.Name = "combo_dept";
            this.combo_dept.Size = new System.Drawing.Size(108, 27);
            this.combo_dept.TabIndex = 151;
            this.combo_dept.Text = "Select Dept.";
            // 
            // label_dept
            // 
            this.label_dept.AutoSize = true;
            this.label_dept.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dept.Location = new System.Drawing.Point(66, 188);
            this.label_dept.Name = "label_dept";
            this.label_dept.Size = new System.Drawing.Size(41, 15);
            this.label_dept.TabIndex = 147;
            this.label_dept.Text = "DEPT :";
            // 
            // text_student_id
            // 
            this.text_student_id.BackColor = System.Drawing.SystemColors.Info;
            this.text_student_id.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_student_id.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_student_id.Location = new System.Drawing.Point(183, 142);
            this.text_student_id.MaxLength = 20;
            this.text_student_id.Name = "text_student_id";
            this.text_student_id.Size = new System.Drawing.Size(306, 27);
            this.text_student_id.TabIndex = 144;
            this.text_student_id.Text = "Enter your institution ID";
            this.text_student_id.Enter += new System.EventHandler(this.text_student_id_Enter);
            this.text_student_id.Leave += new System.EventHandler(this.text_student_id_Leave);
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_id.Location = new System.Drawing.Point(64, 148);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(46, 15);
            this.label_id.TabIndex = 143;
            this.label_id.Text = "ID NO :";
            // 
            // text_diseases
            // 
            this.text_diseases.BackColor = System.Drawing.SystemColors.Info;
            this.text_diseases.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_diseases.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_diseases.Location = new System.Drawing.Point(185, 534);
            this.text_diseases.MaxLength = 100;
            this.text_diseases.Name = "text_diseases";
            this.text_diseases.Size = new System.Drawing.Size(437, 27);
            this.text_diseases.TabIndex = 146;
            this.text_diseases.Text = "name of disease";
            this.text_diseases.Enter += new System.EventHandler(this.text_diseases_Enter);
            this.text_diseases.Leave += new System.EventHandler(this.text_diseases_Leave);
            // 
            // text_name
            // 
            this.text_name.BackColor = System.Drawing.SystemColors.Info;
            this.text_name.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_name.ForeColor = System.Drawing.SystemColors.GrayText;
            this.text_name.Location = new System.Drawing.Point(183, 98);
            this.text_name.MaxLength = 50;
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(306, 27);
            this.text_name.TabIndex = 145;
            this.text_name.Text = "Enter your full name";
            this.text_name.Enter += new System.EventHandler(this.text_name_Enter);
            this.text_name.Leave += new System.EventHandler(this.text_name_Leave);
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.Location = new System.Drawing.Point(64, 104);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(48, 15);
            this.label_name.TabIndex = 142;
            this.label_name.Text = "NAME :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(423, 492);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 15);
            this.label9.TabIndex = 150;
            this.label9.Text = "Gender";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // comboBox_gender
            // 
            this.comboBox_gender.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_gender.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_gender.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_gender.FormattingEnabled = true;
            this.comboBox_gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.comboBox_gender.Location = new System.Drawing.Point(497, 488);
            this.comboBox_gender.Name = "comboBox_gender";
            this.comboBox_gender.Size = new System.Drawing.Size(125, 27);
            this.comboBox_gender.TabIndex = 189;
            this.comboBox_gender.Text = "Select";
            this.comboBox_gender.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(469, 489);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 26);
            this.label10.TabIndex = 185;
            this.label10.Text = "*";
            this.label10.Visible = false;
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_exit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit.ForeColor = System.Drawing.Color.White;
            this.button_exit.Location = new System.Drawing.Point(460, 576);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(90, 35);
            this.button_exit.TabIndex = 239;
            this.button_exit.Text = "EXIT";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_uploadimage
            // 
            this.button_uploadimage.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_uploadimage.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uploadimage.ForeColor = System.Drawing.Color.GhostWhite;
            this.button_uploadimage.Location = new System.Drawing.Point(524, 220);
            this.button_uploadimage.Name = "button_uploadimage";
            this.button_uploadimage.Size = new System.Drawing.Size(98, 36);
            this.button_uploadimage.TabIndex = 241;
            this.button_uploadimage.Text = "UPLOAD";
            this.button_uploadimage.UseVisualStyleBackColor = false;
            this.button_uploadimage.Click += new System.EventHandler(this.button_uploadimage_Click);
            // 
            // pictureBox1_dp
            // 
            this.pictureBox1_dp.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox1_dp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_dp.Image")));
            this.pictureBox1_dp.Location = new System.Drawing.Point(524, 88);
            this.pictureBox1_dp.Name = "pictureBox1_dp";
            this.pictureBox1_dp.Padding = new System.Windows.Forms.Padding(3);
            this.pictureBox1_dp.Size = new System.Drawing.Size(98, 126);
            this.pictureBox1_dp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_dp.TabIndex = 240;
            this.pictureBox1_dp.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(510, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 15);
            this.label11.TabIndex = 242;
            this.label11.Text = "Passport : 35 x 45mm";
            // 
            // UserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button_uploadimage);
            this.Controls.Add(this.pictureBox1_dp);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.comboBox_gender);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.button_adminOR_user);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.dateTimePicker_lastdonation);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.text_age);
            this.Controls.Add(this.label_age);
            this.Controls.Add(this.dateTimePicker_birthday);
            this.Controls.Add(this.label_lastdonation);
            this.Controls.Add(this.radioButton_donated_no);
            this.Controls.Add(this.radioButton_donated_yes);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.text_email);
            this.Controls.Add(this.label_birthday);
            this.Controls.Add(this.label_emali);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.text_city);
            this.Controls.Add(this.label_city);
            this.Controls.Add(this.text_section);
            this.Controls.Add(this.label_section);
            this.Controls.Add(this.text_intake);
            this.Controls.Add(this.label_intake);
            this.Controls.Add(this.comboBox_bloodtype);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label_donatedbefore);
            this.Controls.Add(this.label_diseases);
            this.Controls.Add(this.label_bloodtype);
            this.Controls.Add(this.combo_dept);
            this.Controls.Add(this.label_dept);
            this.Controls.Add(this.text_student_id);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.text_diseases);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.label_name);
            this.Name = "UserProfile";
            this.Text = "User Profile";
            this.Load += new System.EventHandler(this.UserProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_dp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_home;
        public System.Windows.Forms.Button button_adminOR_user;
        private System.Windows.Forms.Button button_logout;
        public System.Windows.Forms.DateTimePicker dateTimePicker_lastdonation;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_update;
        public System.Windows.Forms.TextBox text_age;
        private System.Windows.Forms.Label label_age;
        public System.Windows.Forms.DateTimePicker dateTimePicker_birthday;
        private System.Windows.Forms.Label label_lastdonation;
        public System.Windows.Forms.RadioButton radioButton_donated_no;
        public System.Windows.Forms.RadioButton radioButton_donated_yes;
        public System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.Label label_address;
        public System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.Label label_birthday;
        private System.Windows.Forms.Label label_emali;
        public System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Label label_phone;
        public System.Windows.Forms.TextBox text_city;
        private System.Windows.Forms.Label label_city;
        public System.Windows.Forms.TextBox text_section;
        private System.Windows.Forms.Label label_section;
        public System.Windows.Forms.TextBox text_intake;
        private System.Windows.Forms.Label label_intake;
        public System.Windows.Forms.ComboBox comboBox_bloodtype;
        private System.Windows.Forms.Label label_donatedbefore;
        private System.Windows.Forms.Label label_diseases;
        private System.Windows.Forms.Label label_bloodtype;
        public System.Windows.Forms.ComboBox combo_dept;
        private System.Windows.Forms.Label label_dept;
        public System.Windows.Forms.TextBox text_student_id;
        private System.Windows.Forms.Label label_id;
        public System.Windows.Forms.TextBox text_diseases;
        public System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.ComboBox comboBox_gender;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_uploadimage;
        public System.Windows.Forms.PictureBox pictureBox1_dp;
        private System.Windows.Forms.Label label11;
    }
}