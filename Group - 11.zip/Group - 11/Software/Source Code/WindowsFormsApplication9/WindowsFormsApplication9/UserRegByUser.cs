﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class UserRegByUser : Form
    {
       private string tempImagePath = null;

        public UserRegByUser()
        {
            InitializeComponent();
        }

        private void button_adminOR_user_Click(object sender, EventArgs e)
        {
            Usercp ucp = new Usercp();
            ucp.Width = this.Width;
            ucp.Height = this.Height;
            ucp.StartPosition = FormStartPosition.Manual;
            ucp.Location = new Point(this.Location.X, this.Location.Y);

            // asigning username to _userName variable for detecting which user has logged in.
            
            ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

            this.Hide();
            ucp.ShowDialog();
            this.Close();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            donor_info_regByUser();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            Usercp ucp = new Usercp();
            ucp.Width = this.Width;
            ucp.Height = this.Height;
            ucp.StartPosition = FormStartPosition.Manual;
            ucp.Location = new Point(this.Location.X, this.Location.Y);

            // asigning username to _userName variable for detecting which user has logged in.

            ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

            this.Hide();
            ucp.ShowDialog();
            this.Close();
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            text_name.Clear();
            text_student_id.Clear();
            //combo_dept combo box
            combo_dept.Text = "Select Dept.";
            text_intake.Clear();
            text_section.Clear();
            text_phone.Clear();
            text_email.Clear();
            //Birth_Day and donationDay reset
            //dateTimePicker_birthday.Value = DateTime.Now;
            //dateTimePicker_lastdonation.Value = DateTime.Now;
            DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
            dateTimePicker_birthday.Value = setBirthDayTime;

            DateTime setLastDonationTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
            dateTimePicker_lastdonation.Value = setLastDonationTime;

            text_age.Text = "Default";
            text_city.Clear();
            text_address.Clear();
            // Blood_Group combo box
            comboBox_bloodtype.Text = "Blood Group";
            comboBox_gender.Text = "Select";
            radioButton_donated_no.Checked = false;
            radioButton_donated_yes.Checked = false;

            text_diseases.Clear();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {

        }


        private void donor_info_regByUser()
        {
            // database connection string
            string ConnectString = ConnectionString.connString;
            //string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                if((comboBox_bloodtype.SelectedIndex != -1) && (combo_dept.SelectedIndex != -1) && (comboBox_gender.SelectedIndex != -1))
                {
                    // declearing local variable for input
                    //user name contain both login info table and personalinfotable for userREGbyUser to protect user to stop filling multiple form.
                    string username = GlobalUserName.GlobalUser;

                    string Student_Name = text_name.Text.Trim();
                    string Student_ID = text_student_id.Text.Trim();
                    string Department = combo_dept.SelectedItem.ToString().Trim().ToUpper();
                    string Intake = text_intake.Text.Trim().ToString();
                    string Section = text_section.Text.Trim().ToString();
                    string Phone_No = text_phone.Text.Trim().ToString();
                    string Email_ID = text_email.Text.Trim().ToString().ToLower();
                    string Birth_Day = birthday().ToString().ToUpper();
                    string Age = ageCalculation().ToString();
                    string City = text_city.Text.Trim().ToString().ToUpper();
                    string Address = text_address.Text.Trim().ToString();
                    string Blood_Group = comboBox_bloodtype.SelectedItem.ToString().Trim().ToUpper();
                    string Eligibility = checkEligibility().ToUpper();
                    string Gender = comboBox_gender.SelectedItem.ToString().Trim();
                    string Last_Donation = lastDonation().ToString();
                    string Diseases = text_diseases.Text.Trim().ToString();

                    string imagepath = tempImagePath;
                    tempImagePath = null;

                    // checking if specific fields are empty
                    if (!string.IsNullOrEmpty(Student_Name) && !string.IsNullOrEmpty(Student_ID) && !string.IsNullOrEmpty(Gender) && (Student_Name != "Enter your full name")
                        && !string.IsNullOrEmpty(Phone_No) && !string.IsNullOrEmpty(Birth_Day) && !string.IsNullOrEmpty(Last_Donation)
                        && !string.IsNullOrEmpty(Age) && !string.IsNullOrEmpty(City) && !string.IsNullOrEmpty(Age) && !string.IsNullOrEmpty(username)
                        && !string.IsNullOrEmpty(Address) && !string.IsNullOrEmpty(Blood_Group) && !string.IsNullOrEmpty(Eligibility))

                    {
                        //opening connection
                        conn.Open();
                        MySqlCommand cmd = conn.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "insert into donortable values ('', '" + username + "', '" + Student_Name + "', '" + Student_ID + "' , '" + Department + "', '" + Intake + "', '" + Section + "', '" + Phone_No + "', '" + Email_ID + "', '" + Birth_Day + "', '" + Age + "', '" + City + "', '" + Address + "', '" + Blood_Group + "', '" + Eligibility + "', '" + Gender + "' , '" + Last_Donation + "', '" + Diseases + "' , '" + imagepath + "' )";
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Registration Successful!");

                        //user cp

                        Usercp ucp = new Usercp();
                        ucp.Width = this.Width;
                        ucp.Height = this.Height;
                        ucp.StartPosition = FormStartPosition.Manual;
                        ucp.Location = new Point(this.Location.X, this.Location.Y);

                        // asigning username to _userName variable for detecting which user has logged in.

                        ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

                        this.Hide();
                        ucp.ShowDialog();
                        this.Close();

                        /* CHANGING THIS PAGE TO PREVENT ADDING MULTIPLE ROW for the same username so the clear task is no further needed.

                        text_name.Clear();
                        text_student_id.Clear();
                        //Department
                        text_intake.Clear();
                        text_section.Clear();
                        text_phone.Clear();
                        text_email.Clear();
                        //Birth_Day
                        text_age.Clear();
                        text_city.Clear();
                        text_address.Clear();
                        // Blood_Group
                        //Eligibility
                        // Last_Donation.Clear();
                        text_diseases.Clear();
                        */

                    }

                    else
                    {
                        label1.Visible = true;
                        label2.Visible = true;
                        label3.Visible = true;
                        label4.Visible = true;
                        label5.Visible = true;
                        label6.Visible = true;
                        label7.Visible = true;
                        MessageBox.Show("Selected Field Can't be Empty!");
                    }
                }
                else
                {
                    label1.Visible = true;
                    label2.Visible = true;
                    label3.Visible = true;
                    label4.Visible = true;
                    label5.Visible = true;
                    label6.Visible = true;
                    label7.Visible = true;
                    label8.Visible = true;
                    label10.Visible = true;
                    
                    
                    MessageBox.Show("Complete Selected Fields!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /*
        private string radioButtonValue()
        {
            string radioValue = "";
            bool isChecked = radioButton_donated_yes.Checked;
            if (isChecked)
                radioValue = radioButton_donated_yes.Text;
            else
                radioValue = radioButton_donated_no.Text;
            return radioValue;
        }
        */

        private string birthday()
        {
            string birthDate = dateTimePicker_birthday.Value.ToString("yyyy-MM-dd");
            return birthDate;
        }

        private string lastDonation()
        {
            string lastDonationDate = dateTimePicker_lastdonation.Value.ToString("yyyy-MM-dd");
            return lastDonationDate;
        }

        private int ageCalculation()
        {
            // TimeSpan age = DateTime.Now - dateTimePicker_birthday.Value;

            int age = DateTime.Now.Year - dateTimePicker_birthday.Value.Year - (DateTime.Now.DayOfYear < dateTimePicker_birthday.Value.DayOfYear ? 1 : 0);
            return age;

            /*int years = DateTime.Now.Year - dateTimePicker.Value.Year;

            if (dateTimePicker.Value.AddYears(years) > DateTime.Now) years--; */
        }

        private string checkEligibility()
        {

            DateTime lastDonationDate = dateTimePicker_lastdonation.Value;
            DateTime currentDate = DateTime.Now;

            TimeSpan difference = currentDate - lastDonationDate;

            int differenceInDays = difference.Days;

            // int differenceInHours = difference.Hours;
            //string totalDays = differenceInDays.ToString();
            //return differenceInDays;

            string radioValue = "";

            if (differenceInDays >= 90)
            {
                radioButton_donated_yes.Checked = true;
                radioButton_donated_no.Checked = false;
                radioValue = radioButton_donated_yes.Text.Trim();
            }
            else
            {
                radioButton_donated_yes.Checked = false;
                radioButton_donated_no.Checked = true;
                radioValue = radioButton_donated_no.Text.Trim();
            }

            return radioValue;

        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);
            GlobalUserName.GlobalUser = null;
            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void userProfileOrRegPage()
        {
            string uniqueUser = GlobalUserName.GlobalUser;
            string testUsername = null;
            // Checking if this user already fill personal information form or not. if already field he can only be able to update his own profile. if not filed he can fill the personal info form.

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {

                //opening connection
                conn.Open();

                DataTable dt = new DataTable();

                MySqlDataReader myReader = null;

                MySqlCommand myCommand = new MySqlCommand("select username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases from donortable where username = '" + uniqueUser + "' ", conn);
                myReader = myCommand.ExecuteReader();

                while (myReader.Read())
                {
                    testUsername = (myReader["username"].ToString().Trim());
                }
                if (uniqueUser != testUsername)
                {
                    UserRegByUser regByUser = new UserRegByUser();

                    regByUser.Width = this.Width;
                    regByUser.Height = this.Height;
                    regByUser.StartPosition = FormStartPosition.Manual;
                    regByUser.Location = new Point(this.Location.X, this.Location.Y);
                    regByUser.button_adminOR_user.Text = GlobalUserName.GlobalUser;

                    // Setting Default Value of Date Time Picker to 1990's date.
                    DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    regByUser.dateTimePicker_birthday.Value = setBirthDayTime;

                    DateTime setLastDonationTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    regByUser.dateTimePicker_lastdonation.Value = setLastDonationTime;

                    myReader.Close();
                    conn.Close();
                    this.Hide();
                    regByUser.ShowDialog();
                    this.Close();
                }
                else
                {


                    UserProfile up = new UserProfile();
                    up.Width = this.Width;
                    up.Height = this.Height;
                    up.StartPosition = FormStartPosition.Manual;
                    up.Location = new Point(this.Location.X, this.Location.Y);

                    up.text_name.Text = (myReader["Student_Name"].ToString());
                    up.text_student_id.Text = (myReader["Student_ID"].ToString());
                    up.combo_dept.Text = (myReader["Department"].ToString());
                    up.text_intake.Text = (myReader["Intake"].ToString());
                    up.text_section.Text = (myReader["Section"].ToString());
                    up.text_phone.Text = (myReader["Phone_No"].ToString());
                    up.text_email.Text = (myReader["Email_ID"].ToString());

                    // Saving DB BirthDay string information to a local string
                    string BirthDayTemp = (myReader["Birth_Day"].ToString());

                    up.text_age.Text = (myReader["Age"].ToString());
                    up.text_city.Text = (myReader["City"].ToString());
                    up.text_address.Text = (myReader["Address"].ToString());
                    up.comboBox_bloodtype.Text = (myReader["Blood_Group"].ToString());
                    up.comboBox_gender.Text = (myReader["Gender"].ToString());
                    // eligibility need to check first and then need to convert to radio button value.
                    string EligibilityTemp = (myReader["Eligibility"].ToString().ToUpper());

                    //same as birthday as it is same type
                    string LastDonationTemp = (myReader["Last_Donation"].ToString());

                    up.text_diseases.Text = (myReader["Diseases"].ToString());
                    up.button_adminOR_user.Text = GlobalUserName.GlobalUser;

                    myReader.Close();
                    conn.Close();

                    // Birthday need to first stored into birthday string yyyy-MM-dd then push back to Date Time.
                    DateTime BirthDayTemp2 = DateTime.ParseExact(BirthDayTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    up.dateTimePicker_birthday.Value = BirthDayTemp2;

                    if (EligibilityTemp == "YES")
                    {
                        up.radioButton_donated_yes.Checked = true;
                        up.radioButton_donated_no.Checked = false;
                    }
                    else
                    {
                        up.radioButton_donated_yes.Checked = false;
                        up.radioButton_donated_no.Checked = true;
                    }


                    DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    up.dateTimePicker_lastdonation.Value = LastDonationTemp2;

                    this.Hide();
                    up.ShowDialog();
                    this.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void text_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_name_Enter(object sender, EventArgs e)
        {
            if (text_name.Text == "Enter your full name")
            {
                text_name.Text = "";
                text_name.ForeColor = Color.Black;
            }
        }

        private void text_name_Leave(object sender, EventArgs e)
        {
            if (text_name.Text == "")
            {
                text_name.Text = "Enter your full name";
                text_name.ForeColor = Color.Gray;
            }
        }

        private void text_student_id_Enter(object sender, EventArgs e)
        {
            if (text_student_id.Text == "Enter your institution ID")
            {
                text_student_id.Text = "";
                text_student_id.ForeColor = Color.Black;
            }
        }

        private void text_student_id_Leave(object sender, EventArgs e)
        {
            if (text_student_id.Text == "")
            {
                text_student_id.Text = "Enter your institution ID";
                text_student_id.ForeColor = Color.Gray;
            }
        }

        private void text_email_Enter(object sender, EventArgs e)
        {
            if (text_email.Text == "someone@example.com")
            {
                text_email.Text = "";
                text_email.ForeColor = Color.Black;
            }
        }

        private void text_email_Leave(object sender, EventArgs e)
        {
            if (text_email.Text == "")
            {
                text_email.Text = "someone@example.com";
                text_email.ForeColor = Color.Gray;
            }
        }

        private void text_intake_Enter(object sender, EventArgs e)
        {
            if (text_intake.Text == "Intake")
            {
                text_intake.Text = "";
                text_intake.ForeColor = Color.Black;
            }
        }

        private void text_intake_Leave(object sender, EventArgs e)
        {
            if (text_intake.Text == "")
            {
                text_intake.Text = "Intake";
                text_intake.ForeColor = Color.Gray;
            }
        }

        private void text_phone_Enter(object sender, EventArgs e)
        {
            if (text_phone.Text == "01700000XXX")
            {
                text_phone.Text = "";
                text_phone.ForeColor = Color.Black;
            }
        }

        private void text_phone_Leave(object sender, EventArgs e)
        {
            if (text_phone.Text == "")
            {
                text_phone.Text = "01700000XXX";
                text_phone.ForeColor = Color.Gray;
            }
        }

        private void text_section_Enter(object sender, EventArgs e)
        {
            if (text_section.Text == "Section")
            {
                text_section.Text = "";
                text_section.ForeColor = Color.Black;
            }
        }

        private void text_section_Leave(object sender, EventArgs e)
        {
            if (text_section.Text == "")
            {
                text_section.Text = "Section";
                text_section.ForeColor = Color.Gray;
            }
        }

        private void text_city_Enter(object sender, EventArgs e)
        {
            if (text_city.Text == "your city")
            {
                text_city.Text = "";
                text_city.ForeColor = Color.Black;
            }
        }

        private void text_city_Leave(object sender, EventArgs e)
        {
            if (text_city.Text == "")
            {
                text_city.Text = "your city";
                text_city.ForeColor = Color.Gray;
            }
        }

        private void text_age_Enter(object sender, EventArgs e)
        {
            if (text_age.Text == "auto")
            {
                text_age.Text = "";
                text_age.ForeColor = Color.Black;
            }
        }

        private void text_age_Leave(object sender, EventArgs e)
        {
            if (text_age.Text == "")
            {
                text_age.Text = "auto";
                text_age.ForeColor = Color.Gray;
            }
        }

        private void text_address_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_address_Enter(object sender, EventArgs e)
        {
            if (text_address.Text == "Enter your full adress")
            {
                text_address.Text = "";
                text_address.ForeColor = Color.Black;
            }
        }

        private void text_address_Leave(object sender, EventArgs e)
        {
            if (text_address.Text == "")
            {
                text_address.Text = "Enter your full adress";
                text_address.ForeColor = Color.Gray;
            }
        }

        private void text_diseases_Enter(object sender, EventArgs e)
        {
            if (text_diseases.Text == "name of disease")
            {
                text_diseases.Text = "";
                text_diseases.ForeColor = Color.Black;
            }
        }

        private void text_diseases_Leave(object sender, EventArgs e)
        {
            if (text_diseases.Text == "")
            {
                text_diseases.Text = "name of disease";
                text_diseases.ForeColor = Color.Gray;
            }
        }

        private void UserRegByUser_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button_uploadimage_Click(object sender, EventArgs e)
        {
            uploadImage();
            string paths = Application.StartupPath;
            //string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 9));
            if (!string.IsNullOrEmpty(tempImagePath))
            {
                pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempImagePath);
                
            }
        }

        private void uploadImage()
        {
            
            OpenFileDialog ofdFindPhoto = new OpenFileDialog();

            ofdFindPhoto.InitialDirectory = @"C:\Desktop\";
            ofdFindPhoto.FileName = "";
            ofdFindPhoto.Multiselect = false;
            ofdFindPhoto.Filter = "JPEG Image|*.jpg|GIF Image|*.gif|PNG Image|*.png|BMP Image|*.bmp";
            if (ofdFindPhoto.ShowDialog() == DialogResult.OK)
            
            {
                if (ofdFindPhoto.CheckFileExists)
                
                {

                    //C: \Users\rajib\Documents\Visual Studio 2015\Projects\WindowsFormsApplication9\WindowsFormsApplication9\bin\Debug
                    // the length - 0 is for going back to project folder from bin\debug folder
                    //string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 9));

                    string paths = Application.StartupPath;
                    string getImageFileName = System.IO.Path.GetFileName(ofdFindPhoto.FileName);
                    System.IO.File.Copy(ofdFindPhoto.FileName, paths + "\\donorImages\\" + getImageFileName);
                    MessageBox.Show("Successfully Uploaded");
                    tempImagePath = getImageFileName;
                }
            }
            
        }
       


    }
}
