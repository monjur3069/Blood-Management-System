﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class UserViewProfile : Form
    {
        public UserViewProfile()
        {
            InitializeComponent();
        }

        private void label_age_Click(object sender, EventArgs e)
        {

        }

        private void button_update_Click(object sender, EventArgs e)
        {
            userProfileUpdateOrRegPage();
        }
        private void userProfileUpdateOrRegPage()
        {
            string uniqueUser = GlobalUserName.GlobalUser;
            string testUsername = null;
            // Checking if this user already fill personal information form or not. if already field he can only be able to update his own profile. if not filed he can fill the personal info form.

            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {

                //opening connection
                conn.Open();

                DataTable dt = new DataTable();

                MySqlDataReader myReader = null;

                MySqlCommand myCommand = new MySqlCommand("select username, Student_Name, Student_ID, Department, Intake, Section, Phone_No, Email_ID, Birth_Day, Age, City, Address, Blood_Group, Eligibility, Gender, Last_Donation, Diseases, imgName from donortable where username = '" + uniqueUser + "' ", conn);
                myReader = myCommand.ExecuteReader();

                while (myReader.Read())
                {
                    testUsername = (myReader["username"].ToString().Trim());
                }
                if (uniqueUser != testUsername)
                {
                    UserRegByUser regByUser = new UserRegByUser();

                    regByUser.Width = this.Width;
                    regByUser.Height = this.Height;
                    regByUser.StartPosition = FormStartPosition.Manual;
                    regByUser.Location = new Point(this.Location.X, this.Location.Y);
                    regByUser.button_adminOR_user.Text = GlobalUserName.GlobalUser;

                    // Setting Default Value of Date Time Picker to 1990's date.
                    DateTime setBirthDayTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    regByUser.dateTimePicker_birthday.Value = setBirthDayTime;

                    DateTime setLastDonationTime = DateTime.ParseExact("1990-01-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    regByUser.dateTimePicker_lastdonation.Value = setLastDonationTime;

                    myReader.Close();
                    conn.Close();
                    this.Hide();
                    regByUser.ShowDialog();
                    this.Close();
                }
                else
                {


                    UserProfile up = new UserProfile();
                    up.Width = this.Width;
                    up.Height = this.Height;
                    up.StartPosition = FormStartPosition.Manual;
                    up.Location = new Point(this.Location.X, this.Location.Y);

                    up.text_name.Text = (myReader["Student_Name"].ToString());
                    up.text_student_id.Text = (myReader["Student_ID"].ToString());
                    up.combo_dept.Text = (myReader["Department"].ToString());
                    up.text_intake.Text = (myReader["Intake"].ToString());
                    up.text_section.Text = (myReader["Section"].ToString());
                    up.text_phone.Text = (myReader["Phone_No"].ToString());
                    up.text_email.Text = (myReader["Email_ID"].ToString());

                    // Saving DB BirthDay string information to a local string
                    string BirthDayTemp = (myReader["Birth_Day"].ToString());

                    up.text_age.Text = (myReader["Age"].ToString());
                    up.text_city.Text = (myReader["City"].ToString());
                    up.text_address.Text = (myReader["Address"].ToString());
                    up.comboBox_bloodtype.Text = (myReader["Blood_Group"].ToString());
                    up.comboBox_gender.Text = (myReader["Gender"].ToString());
                    // eligibility need to check first and then need to convert to radio button value.
                    string EligibilityTemp = (myReader["Eligibility"].ToString().ToUpper());

                    //same as birthday as it is same type
                    string LastDonationTemp = (myReader["Last_Donation"].ToString());
                    string tempLoadImagePath = (myReader["imgName"].ToString());

                    up.text_diseases.Text = (myReader["Diseases"].ToString());
                    up.button_adminOR_user.Text = GlobalUserName.GlobalUser;

                    myReader.Close();
                    conn.Close();

                    // Birthday need to first stored into birthday string yyyy-MM-dd then push back to Date Time.
                    DateTime BirthDayTemp2 = DateTime.ParseExact(BirthDayTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    up.dateTimePicker_birthday.Value = BirthDayTemp2;



                    DateTime LastDonationTemp2 = DateTime.ParseExact(LastDonationTemp, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    up.dateTimePicker_lastdonation.Value = LastDonationTemp2;

                    /***************IMGAE PATH *****************/


                    if ((tempLoadImagePath == "0") || (string.IsNullOrEmpty(tempLoadImagePath)))
                    {
                        tempLoadImagePath = "imagedefault.jpg";
                        string paths = Application.StartupPath;
                        up.pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                    }
                    else
                    {

                        string paths = Application.StartupPath;
                        up.pictureBox1_dp.Image = Image.FromFile(paths + "\\donorImages\\" + tempLoadImagePath);

                    }
                    /***************IMGAE PATH *****************/

                    /***************** Eligibility Issue*********************/
                    DateTime lastDonationDate = LastDonationTemp2;
                    DateTime currentDate = DateTime.Now;

                    TimeSpan difference = currentDate - lastDonationDate;

                    int differenceInDays = difference.Days;

                    // int differenceInHours = difference.Hours;
                    //string totalDays = differenceInDays.ToString();
                    //return differenceInDays;

                    //string radioValue = "";

                    if (differenceInDays >= 90)
                    {
                        up.radioButton_donated_yes.Checked = true;
                        up.radioButton_donated_no.Checked = false;
                        //radioValue = "YES";
                    }
                    else
                    {
                        up.radioButton_donated_yes.Checked = false;
                        up.radioButton_donated_no.Checked = true;
                        //radioValue = "NO";
                    }
                    /***************** Eligibility Issue*********************/


                    this.Hide();
                    up.ShowDialog();
                    this.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button_adminOR_user_Click(object sender, EventArgs e)
        {
            Usercp ucp = new Usercp();
            ucp.Width = this.Width;
            ucp.Height = this.Height;
            ucp.StartPosition = FormStartPosition.Manual;
            ucp.Location = new Point(this.Location.X, this.Location.Y);

            // asigning username to _userName variable for detecting which user has logged in.

            ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

            this.Hide();
            ucp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);
            GlobalUserName.GlobalUser = null;
            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            string username = GlobalUserName.GlobalUser;
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);
            try
            {
                conn.Open();
                MySqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM donortable WHERE username = '" + username + "'  ";

                cmd.ExecuteNonQuery();
                MessageBox.Show("User's Personal Information Has been DELETED.");

                conn.Close();
                Usercp ucp = new Usercp();
                ucp.Width = this.Width;
                ucp.Height = this.Height;
                ucp.StartPosition = FormStartPosition.Manual;
                ucp.Location = new Point(this.Location.X, this.Location.Y);

                // asigning username to _userName variable for detecting which user has logged in.

                ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

                this.Hide();
                ucp.ShowDialog();
                this.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Usercp ucp = new Usercp();
            ucp.Width = this.Width;
            ucp.Height = this.Height;
            ucp.StartPosition = FormStartPosition.Manual;
            ucp.Location = new Point(this.Location.X, this.Location.Y);

            // asigning username to _userName variable for detecting which user has logged in.

            ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

            this.Hide();
            ucp.ShowDialog();
            this.Close();
        }
    }
}
