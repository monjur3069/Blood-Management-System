﻿namespace WindowsFormsApplication9
{
    partial class Usercp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_home = new System.Windows.Forms.Button();
            this.button_user_cp = new System.Windows.Forms.Button();
            this.button_user_logout = new System.Windows.Forms.Button();
            this.button_searchdonor = new System.Windows.Forms.Button();
            this.button_regdonor = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_view_profile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(372, 40);
            this.button_home.TabIndex = 25;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // button_user_cp
            // 
            this.button_user_cp.BackColor = System.Drawing.Color.Green;
            this.button_user_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_user_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_user_cp.ForeColor = System.Drawing.Color.White;
            this.button_user_cp.Location = new System.Drawing.Point(390, 12);
            this.button_user_cp.Name = "button_user_cp";
            this.button_user_cp.Size = new System.Drawing.Size(191, 40);
            this.button_user_cp.TabIndex = 26;
            this.button_user_cp.Text = "USER";
            this.button_user_cp.UseVisualStyleBackColor = false;
            this.button_user_cp.Click += new System.EventHandler(this.button_user_cp_Click);
            // 
            // button_user_logout
            // 
            this.button_user_logout.BackColor = System.Drawing.Color.Green;
            this.button_user_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_user_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_user_logout.ForeColor = System.Drawing.Color.White;
            this.button_user_logout.Location = new System.Drawing.Point(587, 12);
            this.button_user_logout.Name = "button_user_logout";
            this.button_user_logout.Size = new System.Drawing.Size(105, 40);
            this.button_user_logout.TabIndex = 27;
            this.button_user_logout.Text = "Log Out";
            this.button_user_logout.UseVisualStyleBackColor = false;
            this.button_user_logout.Click += new System.EventHandler(this.button_user_logout_Click);
            // 
            // button_searchdonor
            // 
            this.button_searchdonor.BackColor = System.Drawing.Color.DarkGreen;
            this.button_searchdonor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_searchdonor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_searchdonor.ForeColor = System.Drawing.Color.White;
            this.button_searchdonor.Location = new System.Drawing.Point(266, 353);
            this.button_searchdonor.Name = "button_searchdonor";
            this.button_searchdonor.Size = new System.Drawing.Size(176, 44);
            this.button_searchdonor.TabIndex = 23;
            this.button_searchdonor.Text = "Search Donor";
            this.button_searchdonor.UseVisualStyleBackColor = false;
            this.button_searchdonor.Click += new System.EventHandler(this.button_searchdonor_Click);
            // 
            // button_regdonor
            // 
            this.button_regdonor.BackColor = System.Drawing.Color.DarkGreen;
            this.button_regdonor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_regdonor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_regdonor.ForeColor = System.Drawing.Color.White;
            this.button_regdonor.Location = new System.Drawing.Point(266, 290);
            this.button_regdonor.Name = "button_regdonor";
            this.button_regdonor.Size = new System.Drawing.Size(176, 44);
            this.button_regdonor.TabIndex = 24;
            this.button_regdonor.Text = "Update Profile";
            this.button_regdonor.UseVisualStyleBackColor = false;
            this.button_regdonor.Click += new System.EventHandler(this.button_regdonor_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(14, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(680, 31);
            this.label3.TabIndex = 19;
            this.label3.Text = "User Activities";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(12, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(680, 26);
            this.label2.TabIndex = 20;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(12, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 41);
            this.label1.TabIndex = 21;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_view_profile
            // 
            this.button_view_profile.BackColor = System.Drawing.Color.DarkGreen;
            this.button_view_profile.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_view_profile.ForeColor = System.Drawing.Color.White;
            this.button_view_profile.Location = new System.Drawing.Point(266, 227);
            this.button_view_profile.Name = "button_view_profile";
            this.button_view_profile.Size = new System.Drawing.Size(176, 44);
            this.button_view_profile.TabIndex = 28;
            this.button_view_profile.Text = "View Profile";
            this.button_view_profile.UseVisualStyleBackColor = false;
            this.button_view_profile.Click += new System.EventHandler(this.button_view_profile_Click);
            // 
            // Usercp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button_view_profile);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.button_user_cp);
            this.Controls.Add(this.button_user_logout);
            this.Controls.Add(this.button_searchdonor);
            this.Controls.Add(this.button_regdonor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Usercp";
            this.Text = "User Control Panel";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_home;
        public System.Windows.Forms.Button button_user_cp;
        private System.Windows.Forms.Button button_user_logout;
        private System.Windows.Forms.Button button_searchdonor;
        private System.Windows.Forms.Button button_regdonor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_view_profile;
    }
}