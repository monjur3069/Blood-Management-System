﻿namespace WindowsFormsApplication9
{
    partial class Userlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_login_inactive = new System.Windows.Forms.Button();
            this.button_donorlist = new System.Windows.Forms.Button();
            this.button_home2 = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.button_login = new System.Windows.Forms.Button();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_login_inactive
            // 
            this.button_login_inactive.BackColor = System.Drawing.Color.Green;
            this.button_login_inactive.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_login_inactive.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_login_inactive.ForeColor = System.Drawing.Color.White;
            this.button_login_inactive.Location = new System.Drawing.Point(545, 15);
            this.button_login_inactive.Name = "button_login_inactive";
            this.button_login_inactive.Size = new System.Drawing.Size(94, 40);
            this.button_login_inactive.TabIndex = 20;
            this.button_login_inactive.Text = "Log In";
            this.button_login_inactive.UseVisualStyleBackColor = false;
            this.button_login_inactive.Click += new System.EventHandler(this.button_login_inactive_Click);
            // 
            // button_donorlist
            // 
            this.button_donorlist.BackColor = System.Drawing.Color.Green;
            this.button_donorlist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_donorlist.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_donorlist.ForeColor = System.Drawing.Color.White;
            this.button_donorlist.Location = new System.Drawing.Point(447, 15);
            this.button_donorlist.Name = "button_donorlist";
            this.button_donorlist.Size = new System.Drawing.Size(94, 40);
            this.button_donorlist.TabIndex = 21;
            this.button_donorlist.Text = "Donor List";
            this.button_donorlist.UseVisualStyleBackColor = false;
            this.button_donorlist.Click += new System.EventHandler(this.button_donorlist_Click);
            // 
            // button_home2
            // 
            this.button_home2.BackColor = System.Drawing.Color.Green;
            this.button_home2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_home2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home2.ForeColor = System.Drawing.Color.White;
            this.button_home2.Location = new System.Drawing.Point(347, 15);
            this.button_home2.Name = "button_home2";
            this.button_home2.Size = new System.Drawing.Size(94, 40);
            this.button_home2.TabIndex = 22;
            this.button_home2.Text = "Home";
            this.button_home2.UseVisualStyleBackColor = false;
            this.button_home2.Click += new System.EventHandler(this.button_home2_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(64, 15);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(277, 40);
            this.button_home.TabIndex = 19;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // button_login
            // 
            this.button_login.BackColor = System.Drawing.Color.DarkGreen;
            this.button_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_login.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_login.ForeColor = System.Drawing.Color.White;
            this.button_login.Location = new System.Drawing.Point(299, 353);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(106, 36);
            this.button_login.TabIndex = 18;
            this.button_login.Text = "LOG IN";
            this.button_login.UseVisualStyleBackColor = false;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // textBox_password
            // 
            this.textBox_password.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_password.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_password.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_password.Location = new System.Drawing.Point(244, 308);
            this.textBox_password.MaxLength = 20;
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.PasswordChar = '*';
            this.textBox_password.Size = new System.Drawing.Size(209, 27);
            this.textBox_password.TabIndex = 16;
            this.textBox_password.Text = "password";
            this.textBox_password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_password.Enter += new System.EventHandler(this.textBox_password_Enter);
            this.textBox_password.Leave += new System.EventHandler(this.textBox_password_Leave);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGreen;
            this.label5.Location = new System.Drawing.Point(12, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(680, 34);
            this.label5.TabIndex = 14;
            this.label5.Text = "Enter Password";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_username
            // 
            this.textBox_username.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_username.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_username.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_username.Location = new System.Drawing.Point(244, 232);
            this.textBox_username.MaxLength = 20;
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(209, 27);
            this.textBox_username.TabIndex = 17;
            this.textBox_username.Text = "username";
            this.textBox_username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_username.Enter += new System.EventHandler(this.textBox_username_Enter);
            this.textBox_username.Leave += new System.EventHandler(this.textBox_username_Leave);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(12, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(680, 34);
            this.label4.TabIndex = 15;
            this.label4.Text = "Enter User ID";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(12, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(680, 26);
            this.label3.TabIndex = 11;
            this.label3.Text = "Login as User";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(10, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(682, 26);
            this.label2.TabIndex = 12;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(10, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(682, 41);
            this.label1.TabIndex = 13;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.GhostWhite;
            this.label6.Location = new System.Drawing.Point(276, 404);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 19);
            this.label6.TabIndex = 23;
            this.label6.Text = "Forgotten Account?";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // Userlogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_login_inactive);
            this.Controls.Add(this.button_donorlist);
            this.Controls.Add(this.button_home2);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.textBox_password);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_username);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Userlogin";
            this.Text = "User Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_login_inactive;
        private System.Windows.Forms.Button button_donorlist;
        private System.Windows.Forms.Button button_home2;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.TextBox textBox_password;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_username;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
    }
}