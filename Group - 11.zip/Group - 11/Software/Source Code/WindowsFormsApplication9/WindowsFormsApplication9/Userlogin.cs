﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Userlogin : Form
    {
        public Userlogin()
        {
            InitializeComponent();
        }

        private void button_login_Click(object sender, EventArgs e)
        {

            userLoginValidation();
            
        }


        // poor code so not using anymore
        /*
        private void UserLoginValidation2()
        {

            string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                
                // Trim for removing space
                string userid = textBox_username.Text.Trim();
                string userpwd = textBox_password.Text.Trim();

                if(!string.IsNullOrEmpty(userid))
                {
                    conn.Open();

                    MySqlDataAdapter sda = new MySqlDataAdapter("Select Count(*) From userlogin where username ='" + userid + "' and password = '" + userpwd + "' ", conn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        Usercp ucp = new Usercp();
                        ucp.Width = this.Width;
                        ucp.Height = this.Height;
                        ucp.StartPosition = FormStartPosition.Manual;
                        ucp.Location = new Point(this.Location.X, this.Location.Y);

                        // asigning username to _userName variable for detecting which user has logged in.
                        GlobalUserName.GlobalUser = userid.ToUpper();
                        ucp.button_user_cp.Text = GlobalUserName.GlobalUser;
                        conn.Close();
                        this.Hide();
                        ucp.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Username Password didn't match! Try again.");
                        textBox_username.Clear();
                        textBox_password.Clear();
                    }
                    
                    //cmd.ExecuteNonQuery();
                    textBox_username.Clear();
                    textBox_password.Clear();
                    conn.Close();
                }

                else
                {
                    MessageBox.Show("Enter a User Name!");
                }
                


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        */

        private void button_login_inactive_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_home2_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_donorlist_Click(object sender, EventArgs e)
        {
            Donorlist d = new Donorlist();
            d.Width = this.Width;
            d.Height = this.Height;
            d.StartPosition = FormStartPosition.Manual;
            d.Location = new Point(this.Location.X, this.Location.Y);
            //d.dataGridView_donor_list = new DataGridView();
            // d.dataGridView_donor_list.Enabled = true;
            //d.dataGridView_donor_list.Visible = true;

            string ConnectString = "datasource = localhost; username = root; password = ; database = bubt_blood_donation_center ";
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                conn.Open();
                MySqlCommand query = conn.CreateCommand();
                query.CommandType = CommandType.Text;

                query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable";
                //create adaptor to fill data from database
                MySqlDataAdapter da = new MySqlDataAdapter(query);
                //create datatable which holds the data
                DataTable dt = new DataTable();
                da.Fill(dt);
                //bind your data to gridview
                d.dataGridView_donor_list.DataSource = dt;
                // dataGridView1.DataBind();
                
                query.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            //this.Visible = false;
            this.Hide();
            d.ShowDialog();
            this.Close();

            //this.Hide();
            //this.Visible = true;
        }

        
        private void userLoginValidation()
        {
            // Trim for removing space
            string userid = textBox_username.Text.Trim();
            string userpwd = textBox_password.Text.Trim();
            string testUserName = null;
            string testUserPwd = null;
            GlobalUserName.GlobalUser = null;

            // Checking ussername password get matched or not.
            string ConnectString = ConnectionString.connString;
            //string string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            if (!string.IsNullOrEmpty(userid) && (userid != "username") && (userpwd != "password"))
            {
                try
                {
                    conn.Open();
                    DataTable dt = new DataTable();
                    MySqlDataReader myReader = null;
                    MySqlCommand myCommand = new MySqlCommand("select username, password from 	userlogin where username = '" + userid + "' and password = '" + userpwd + "' ", conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        testUserName = (myReader["username"].ToString().Trim());
                        testUserPwd = (myReader["password"].ToString().Trim());
                    }
                    if((userid==testUserName)&&(userpwd==testUserPwd))
                    {
                        Usercp ucp = new Usercp();
                        ucp.Width = this.Width;
                        ucp.Height = this.Height;
                        ucp.StartPosition = FormStartPosition.Manual;
                        ucp.Location = new Point(this.Location.X, this.Location.Y);

                        // asigning username to _userName variable for detecting which user has logged in.
                        GlobalUserName.GlobalUser = userid;
                        ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

                        myReader.Close();
                        conn.Close();
                        this.Hide();
                        ucp.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Username Password didn't match! Try again.");
                        textBox_username.Clear();
                        textBox_password.Clear();
                        myReader.Close();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter a User Name!");
            }
        }

        private void textBox_username_Enter(object sender, EventArgs e)
        {
            if(textBox_username.Text == "username")
            {
                textBox_username.Text = "";
                textBox_username.ForeColor = Color.Black;
            }
        }

        private void textBox_username_Leave(object sender, EventArgs e)
        {
            if (textBox_username.Text == "")
            {
                textBox_username.Text = "username";
                textBox_username.ForeColor = Color.Gray;
            }
        }

        private void textBox_password_Enter(object sender, EventArgs e)
        {
            if(textBox_password.Text == "password")
            {
                textBox_password.Text = "";
                textBox_password.ForeColor = Color.Black;
            }
        }

        private void textBox_password_Leave(object sender, EventArgs e)
        {
            if (textBox_password.Text == "")
            {
                textBox_password.Text = "password";
                textBox_password.ForeColor = Color.Gray;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Contact BUBT or an ADMIN");
            DEVELOPERS devp = new DEVELOPERS();
            devp.Width = this.Width;
            devp.Height = this.Height;
            devp.StartPosition = FormStartPosition.Manual;
            devp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            devp.ShowDialog();
            this.Close();
        }
    }
}
