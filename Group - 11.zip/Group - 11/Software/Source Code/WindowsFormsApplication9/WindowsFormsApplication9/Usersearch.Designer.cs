﻿namespace WindowsFormsApplication9
{
    partial class Usersearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_searchByUser = new System.Windows.Forms.DataGridView();
            this.button_home = new System.Windows.Forms.Button();
            this.button_user_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_search = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_userSearchAccrordingTo = new System.Windows.Forms.ComboBox();
            this.textBox_userSearchValue = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_searchByUser)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_searchByUser
            // 
            this.dataGridView_searchByUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView_searchByUser.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_searchByUser.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView_searchByUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_searchByUser.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView_searchByUser.Location = new System.Drawing.Point(12, 317);
            this.dataGridView_searchByUser.Name = "dataGridView_searchByUser";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_searchByUser.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView_searchByUser.Size = new System.Drawing.Size(680, 292);
            this.dataGridView_searchByUser.TabIndex = 27;
            this.dataGridView_searchByUser.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_searchresult_CellContentClick);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.DarkGreen;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(356, 40);
            this.button_home.TabIndex = 23;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // button_user_cp
            // 
            this.button_user_cp.BackColor = System.Drawing.Color.DarkGreen;
            this.button_user_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_user_cp.ForeColor = System.Drawing.Color.White;
            this.button_user_cp.Location = new System.Drawing.Point(374, 12);
            this.button_user_cp.Name = "button_user_cp";
            this.button_user_cp.Size = new System.Drawing.Size(215, 40);
            this.button_user_cp.TabIndex = 24;
            this.button_user_cp.Text = "USER";
            this.button_user_cp.UseVisualStyleBackColor = false;
            this.button_user_cp.Click += new System.EventHandler(this.button_user_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.DarkGreen;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(595, 12);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 25;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_search
            // 
            this.button_search.BackColor = System.Drawing.Color.AliceBlue;
            this.button_search.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_search.ForeColor = System.Drawing.Color.DodgerBlue;
            this.button_search.Location = new System.Drawing.Point(588, 194);
            this.button_search.Name = "button_search";
            this.button_search.Size = new System.Drawing.Size(104, 39);
            this.button_search.TabIndex = 26;
            this.button_search.Text = "SEARCH";
            this.button_search.UseVisualStyleBackColor = false;
            this.button_search.Click += new System.EventHandler(this.button_search_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGreen;
            this.label5.Location = new System.Drawing.Point(12, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(570, 21);
            this.label5.TabIndex = 19;
            this.label5.Text = "Search Value:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(12, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(567, 22);
            this.label4.TabIndex = 20;
            this.label4.Text = "Search According To:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(12, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(680, 26);
            this.label3.TabIndex = 16;
            this.label3.Text = "Search Donor";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(12, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(680, 26);
            this.label2.TabIndex = 17;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(12, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 41);
            this.label1.TabIndex = 18;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox_userSearchAccrordingTo
            // 
            this.comboBox_userSearchAccrordingTo.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_userSearchAccrordingTo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_userSearchAccrordingTo.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_userSearchAccrordingTo.FormattingEnabled = true;
            this.comboBox_userSearchAccrordingTo.Items.AddRange(new object[] {
            "Blood Group",
            "City"});
            this.comboBox_userSearchAccrordingTo.Location = new System.Drawing.Point(12, 200);
            this.comboBox_userSearchAccrordingTo.Name = "comboBox_userSearchAccrordingTo";
            this.comboBox_userSearchAccrordingTo.Size = new System.Drawing.Size(514, 27);
            this.comboBox_userSearchAccrordingTo.TabIndex = 28;
            this.comboBox_userSearchAccrordingTo.Text = "Select City or Blood Group";
            this.comboBox_userSearchAccrordingTo.SelectedIndexChanged += new System.EventHandler(this.comboBox_userSearchAccrordingTo_SelectedIndexChanged);
            this.comboBox_userSearchAccrordingTo.Enter += new System.EventHandler(this.comboBox_userSearchAccrordingTo_Enter);
            this.comboBox_userSearchAccrordingTo.Leave += new System.EventHandler(this.comboBox_userSearchAccrordingTo_Leave);
            // 
            // textBox_userSearchValue
            // 
            this.textBox_userSearchValue.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_userSearchValue.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_userSearchValue.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_userSearchValue.Location = new System.Drawing.Point(12, 267);
            this.textBox_userSearchValue.Name = "textBox_userSearchValue";
            this.textBox_userSearchValue.Size = new System.Drawing.Size(514, 27);
            this.textBox_userSearchValue.TabIndex = 29;
            this.textBox_userSearchValue.Text = "keyword sample : dhaka, O+";
            this.textBox_userSearchValue.TextChanged += new System.EventHandler(this.textBox_userSearchValue_TextChanged);
            this.textBox_userSearchValue.Enter += new System.EventHandler(this.textBox_userSearchValue_Enter);
            this.textBox_userSearchValue.Leave += new System.EventHandler(this.textBox_userSearchValue_Leave);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(588, 260);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 39);
            this.button1.TabIndex = 54;
            this.button1.Text = "PRINT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // Usersearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox_userSearchValue);
            this.Controls.Add(this.comboBox_userSearchAccrordingTo);
            this.Controls.Add(this.dataGridView_searchByUser);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.button_user_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_search);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Usersearch";
            this.Text = "User CP Search";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_searchByUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_searchByUser;
        private System.Windows.Forms.Button button_home;
        public System.Windows.Forms.Button button_user_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_search;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_userSearchAccrordingTo;
        private System.Windows.Forms.TextBox textBox_userSearchValue;
        private System.Windows.Forms.Button button1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}