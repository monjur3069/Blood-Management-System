﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Usersearch : Form
    {
        public Usersearch()
        {
            InitializeComponent();
        }

        private void button_user_cp_Click(object sender, EventArgs e)
        {
            Usercp ucp = new Usercp();
            ucp.Width = this.Width;
            ucp.Height = this.Height;
            ucp.StartPosition = FormStartPosition.Manual;
            ucp.Location = new Point(this.Location.X, this.Location.Y);

            // asigning username to _userName variable for detecting which user has logged in.

            ucp.button_user_cp.Text = GlobalUserName.GlobalUser;

            this.Hide();
            ucp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);
            GlobalUserName.GlobalUser = null;
            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void button_search_Click(object sender, EventArgs e)
        {
            user_search();
        }

        private void user_search()
        {
            string ConnectString = "datasource = localhost; username = root; password = ; database = bubt_blood_donation_center ";
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                if(comboBox_userSearchAccrordingTo.SelectedIndex != -1)
                {
                    string searchBy = comboBox_userSearchAccrordingTo.SelectedItem.ToString().Trim().ToUpper();
                    string searchValue = textBox_userSearchValue.Text.Trim().ToString().ToUpper();
                    conn.Open();
                    MySqlCommand query = conn.CreateCommand();
                    query.CommandType = CommandType.Text;

                    if (searchBy == "BLOOD GROUP")
                    {
                        query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable where Eligibility ='YES' and Blood_Group = '" + searchValue + "' ";
                    }
                    else if (searchBy == "CITY")
                    {
                        query.CommandText = "Select Student_Name, Blood_Group, Age, Phone_No, Eligibility, City, Address  from donortable where Eligibility ='YES' and City LIKE '%" + searchValue + "%' ";
                    }
                    else
                    {
                        comboBox_userSearchAccrordingTo.Text = "Select City or Blood Group";
                        MessageBox.Show("Search By Blood Group OR City");
                    }


                    //create adaptor to fill data from database
                    MySqlDataAdapter sda = new MySqlDataAdapter(query);

                    //create datatable which holds the data
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    //bind your data to gridview
                    dataGridView_searchByUser.DataSource = dt;
                    // dataGridView1.DataBind();



                    query.ExecuteNonQuery();
                    conn.Close();
                }
                else
                {
                    MessageBox.Show("SELECT CITY or BLOOD GROUP");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void comboBox_userSearchAccrordingTo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox_userSearchValue_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView_searchresult_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox_userSearchAccrordingTo_Enter(object sender, EventArgs e)
        {
            if(comboBox_userSearchAccrordingTo.Text == "Select City or Blood Group")
            {
                comboBox_userSearchAccrordingTo.Text = "";
                comboBox_userSearchAccrordingTo.ForeColor = Color.Black;
            }
        }

        private void comboBox_userSearchAccrordingTo_Leave(object sender, EventArgs e)
        {
            if (comboBox_userSearchAccrordingTo.Text == "")
            {
                comboBox_userSearchAccrordingTo.Text = "Select City or Blood Group";
                comboBox_userSearchAccrordingTo.ForeColor = Color.Gray;
            }
        }

        private void textBox_userSearchValue_Enter(object sender, EventArgs e)
        {
            if(textBox_userSearchValue.Text == "keyword sample : dhaka, O+")
            {
                textBox_userSearchValue.Text = "";
                textBox_userSearchValue.ForeColor = Color.Black;
            }
        }

        private void textBox_userSearchValue_Leave(object sender, EventArgs e)
        {
            if (textBox_userSearchValue.Text == "")
            {
                textBox_userSearchValue.Text = "keyword sample : dhaka, O+";
                textBox_userSearchValue.ForeColor = Color.Gray;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //PrintDialog printDlg = new PrintDialog();
            //printDlg.Document = printDocument1;

            // for previewing before printing
            PrintPreviewDialog prntpreview = new PrintPreviewDialog();
            prntpreview.Document = printDocument1;
            prntpreview.ShowDialog();


            /*printDlg.AllowSelection = true;

            printDlg.AllowSomePages = true;

            //Call ShowDialog

            if (printDlg.ShowDialog() == DialogResult.OK)
              
                printDocument1.Print();*/
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int height = dataGridView_searchByUser.Height;
            dataGridView_searchByUser.Height = dataGridView_searchByUser.RowCount * dataGridView_searchByUser.RowTemplate.Height * 2;
            Bitmap bmp = new Bitmap(dataGridView_searchByUser.Width, dataGridView_searchByUser.Height);
            dataGridView_searchByUser.DrawToBitmap(bmp, new Rectangle(0, 0, dataGridView_searchByUser.Width, dataGridView_searchByUser.Height));
            dataGridView_searchByUser.Height = height;
            e.Graphics.DrawImage(bmp, 10, 10);
        }
    }
}
