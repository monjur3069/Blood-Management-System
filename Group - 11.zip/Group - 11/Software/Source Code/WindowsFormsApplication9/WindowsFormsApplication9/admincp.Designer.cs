﻿namespace WindowsFormsApplication9
{
    partial class Admincp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_regdonor = new System.Windows.Forms.Button();
            this.button_searchdonor = new System.Windows.Forms.Button();
            this.button_delete_donor = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_adminview_all_donor = new System.Windows.Forms.Button();
            this.button_update_pwd = new System.Windows.Forms.Button();
            this.button_delete_user = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Calibri", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(5, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(702, 31);
            this.label3.TabIndex = 4;
            this.label3.Text = "Admin Activities";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(5, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(702, 26);
            this.label2.TabIndex = 5;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(6, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(702, 41);
            this.label1.TabIndex = 6;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_regdonor
            // 
            this.button_regdonor.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_regdonor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_regdonor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_regdonor.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_regdonor.Location = new System.Drawing.Point(70, 237);
            this.button_regdonor.Name = "button_regdonor";
            this.button_regdonor.Size = new System.Drawing.Size(168, 44);
            this.button_regdonor.TabIndex = 7;
            this.button_regdonor.Text = "Register Donor";
            this.button_regdonor.UseVisualStyleBackColor = false;
            this.button_regdonor.Click += new System.EventHandler(this.button_regdonor_Click);
            // 
            // button_searchdonor
            // 
            this.button_searchdonor.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_searchdonor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_searchdonor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_searchdonor.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_searchdonor.Location = new System.Drawing.Point(272, 237);
            this.button_searchdonor.Name = "button_searchdonor";
            this.button_searchdonor.Size = new System.Drawing.Size(168, 44);
            this.button_searchdonor.TabIndex = 7;
            this.button_searchdonor.Text = "Search";
            this.button_searchdonor.UseVisualStyleBackColor = false;
            this.button_searchdonor.Click += new System.EventHandler(this.button_searchdonor_Click);
            // 
            // button_delete_donor
            // 
            this.button_delete_donor.BackColor = System.Drawing.Color.LightCoral;
            this.button_delete_donor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_delete_donor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete_donor.ForeColor = System.Drawing.Color.White;
            this.button_delete_donor.Location = new System.Drawing.Point(474, 440);
            this.button_delete_donor.Name = "button_delete_donor";
            this.button_delete_donor.Size = new System.Drawing.Size(168, 44);
            this.button_delete_donor.TabIndex = 7;
            this.button_delete_donor.Text = "FAST DELETE";
            this.button_delete_donor.UseVisualStyleBackColor = false;
            this.button_delete_donor.Click += new System.EventHandler(this.button_deletedonor_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(364, 40);
            this.button_home.TabIndex = 15;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            this.button_home.Click += new System.EventHandler(this.button_home_Click);
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(382, 12);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(207, 40);
            this.button_admin_cp.TabIndex = 16;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(595, 12);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 17;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_adminview_all_donor
            // 
            this.button_adminview_all_donor.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_adminview_all_donor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_adminview_all_donor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_adminview_all_donor.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_adminview_all_donor.Location = new System.Drawing.Point(272, 304);
            this.button_adminview_all_donor.Name = "button_adminview_all_donor";
            this.button_adminview_all_donor.Size = new System.Drawing.Size(168, 44);
            this.button_adminview_all_donor.TabIndex = 18;
            this.button_adminview_all_donor.Text = "View Donor List";
            this.button_adminview_all_donor.UseVisualStyleBackColor = false;
            this.button_adminview_all_donor.Click += new System.EventHandler(this.button_adminview_all_donor_Click);
            // 
            // button_update_pwd
            // 
            this.button_update_pwd.BackColor = System.Drawing.Color.LightCoral;
            this.button_update_pwd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update_pwd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update_pwd.ForeColor = System.Drawing.Color.White;
            this.button_update_pwd.Location = new System.Drawing.Point(474, 304);
            this.button_update_pwd.Name = "button_update_pwd";
            this.button_update_pwd.Size = new System.Drawing.Size(168, 44);
            this.button_update_pwd.TabIndex = 19;
            this.button_update_pwd.Text = "Update Password";
            this.button_update_pwd.UseVisualStyleBackColor = false;
            this.button_update_pwd.Click += new System.EventHandler(this.button_update_pwd_Click);
            // 
            // button_delete_user
            // 
            this.button_delete_user.BackColor = System.Drawing.Color.LightCoral;
            this.button_delete_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_delete_user.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete_user.ForeColor = System.Drawing.Color.White;
            this.button_delete_user.Location = new System.Drawing.Point(474, 237);
            this.button_delete_user.Name = "button_delete_user";
            this.button_delete_user.Size = new System.Drawing.Size(168, 44);
            this.button_delete_user.TabIndex = 20;
            this.button_delete_user.Text = "DELETE USER";
            this.button_delete_user.UseVisualStyleBackColor = false;
            this.button_delete_user.Click += new System.EventHandler(this.button_delete_user_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button1.Location = new System.Drawing.Point(70, 371);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 44);
            this.button1.TabIndex = 21;
            this.button1.Text = "Update Donor Profile";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(474, 371);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 44);
            this.button2.TabIndex = 22;
            this.button2.Text = "DELETE DONOR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button3.Location = new System.Drawing.Point(70, 508);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(168, 44);
            this.button3.TabIndex = 23;
            this.button3.Text = "Tools Donor Patient";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button4.Location = new System.Drawing.Point(70, 304);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(168, 44);
            this.button4.TabIndex = 24;
            this.button4.Text = "Register Patient";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button5.Location = new System.Drawing.Point(272, 371);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(168, 44);
            this.button5.TabIndex = 25;
            this.button5.Text = "Patient Donor Info";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button6.Location = new System.Drawing.Point(272, 440);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(168, 44);
            this.button6.TabIndex = 26;
            this.button6.Text = "View Donor Profile";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button7.Location = new System.Drawing.Point(70, 440);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(168, 44);
            this.button7.TabIndex = 27;
            this.button7.Text = "Modify Patient";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Admincp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_delete_user);
            this.Controls.Add(this.button_update_pwd);
            this.Controls.Add(this.button_adminview_all_donor);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_delete_donor);
            this.Controls.Add(this.button_searchdonor);
            this.Controls.Add(this.button_regdonor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Admincp";
            this.Text = "Admin Control Panel";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_regdonor;
        private System.Windows.Forms.Button button_searchdonor;
        private System.Windows.Forms.Button button_delete_donor;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_adminview_all_donor;
        private System.Windows.Forms.Button button_update_pwd;
        private System.Windows.Forms.Button button_delete_user;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
    }
}