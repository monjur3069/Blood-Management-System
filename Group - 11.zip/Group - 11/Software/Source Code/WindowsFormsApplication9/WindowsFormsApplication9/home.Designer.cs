﻿namespace WindowsFormsApplication9
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_admin_login = new System.Windows.Forms.Button();
            this.button_user_login = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button_login = new System.Windows.Forms.Button();
            this.button_donorlist = new System.Windows.Forms.Button();
            this.button_home2 = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(0, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(704, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "It\'s not just blood. It\'s Life..";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(1, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(703, 41);
            this.label1.TabIndex = 3;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button_admin_login
            // 
            this.button_admin_login.BackColor = System.Drawing.Color.Green;
            this.button_admin_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_login.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_login.ForeColor = System.Drawing.Color.White;
            this.button_admin_login.Location = new System.Drawing.Point(252, 226);
            this.button_admin_login.Name = "button_admin_login";
            this.button_admin_login.Size = new System.Drawing.Size(197, 40);
            this.button_admin_login.TabIndex = 4;
            this.button_admin_login.Text = "ADMIN";
            this.button_admin_login.UseVisualStyleBackColor = false;
            this.button_admin_login.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_user_login
            // 
            this.button_user_login.BackColor = System.Drawing.Color.Green;
            this.button_user_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_user_login.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_user_login.ForeColor = System.Drawing.Color.White;
            this.button_user_login.Location = new System.Drawing.Point(252, 290);
            this.button_user_login.Name = "button_user_login";
            this.button_user_login.Size = new System.Drawing.Size(197, 40);
            this.button_user_login.TabIndex = 4;
            this.button_user_login.Text = "DONOR";
            this.button_user_login.UseVisualStyleBackColor = false;
            this.button_user_login.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(0, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(707, 55);
            this.label4.TabIndex = 1;
            this.label4.Text = "LOGIN AS";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // button_login
            // 
            this.button_login.BackColor = System.Drawing.Color.Green;
            this.button_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_login.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_login.ForeColor = System.Drawing.Color.White;
            this.button_login.Location = new System.Drawing.Point(544, 12);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(94, 40);
            this.button_login.TabIndex = 6;
            this.button_login.Text = "Signup";
            this.button_login.UseVisualStyleBackColor = false;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // button_donorlist
            // 
            this.button_donorlist.BackColor = System.Drawing.Color.Green;
            this.button_donorlist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_donorlist.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_donorlist.ForeColor = System.Drawing.Color.White;
            this.button_donorlist.Location = new System.Drawing.Point(444, 12);
            this.button_donorlist.Name = "button_donorlist";
            this.button_donorlist.Size = new System.Drawing.Size(94, 40);
            this.button_donorlist.TabIndex = 7;
            this.button_donorlist.Text = "Donor List";
            this.button_donorlist.UseVisualStyleBackColor = false;
            this.button_donorlist.Click += new System.EventHandler(this.button_donorlist_Click);
            // 
            // button_home2
            // 
            this.button_home2.BackColor = System.Drawing.Color.Green;
            this.button_home2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_home2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home2.ForeColor = System.Drawing.Color.White;
            this.button_home2.Location = new System.Drawing.Point(344, 12);
            this.button_home2.Name = "button_home2";
            this.button_home2.Size = new System.Drawing.Size(94, 40);
            this.button_home2.TabIndex = 8;
            this.button_home2.Text = "Home";
            this.button_home2.UseVisualStyleBackColor = false;
            this.button_home2.Click += new System.EventHandler(this.button_home2_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(63, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(275, 40);
            this.button_home.TabIndex = 5;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            this.button_home.Click += new System.EventHandler(this.button_home_Click);
            // 
            // label3
            // 
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(4, 554);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(694, 58);
            this.label3.TabIndex = 9;
            this.label3.Text = "© all rights reserved by bubt and developers team";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.button_donorlist);
            this.Controls.Add(this.button_home2);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.button_user_login);
            this.Controls.Add(this.button_admin_login);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Home";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_admin_login;
        private System.Windows.Forms.Button button_user_login;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.Button button_donorlist;
        private System.Windows.Forms.Button button_home2;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label3;
    }
}