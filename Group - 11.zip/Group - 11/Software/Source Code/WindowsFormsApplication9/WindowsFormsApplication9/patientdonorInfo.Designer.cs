﻿namespace WindowsFormsApplication9
{
    partial class patientdonorInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button_admin_cp = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_home = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView_admin_searchResult = new System.Windows.Forms.DataGridView();
            this.comboBox_AdminGeneralSearch = new System.Windows.Forms.ComboBox();
            this.textBox_adminGeneralSearchValue = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_search = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_searchResult)).BeginInit();
            this.SuspendLayout();
            // 
            // button_admin_cp
            // 
            this.button_admin_cp.BackColor = System.Drawing.Color.Green;
            this.button_admin_cp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_admin_cp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_admin_cp.ForeColor = System.Drawing.Color.White;
            this.button_admin_cp.Location = new System.Drawing.Point(387, 12);
            this.button_admin_cp.Name = "button_admin_cp";
            this.button_admin_cp.Size = new System.Drawing.Size(201, 40);
            this.button_admin_cp.TabIndex = 41;
            this.button_admin_cp.Text = "Admin";
            this.button_admin_cp.UseVisualStyleBackColor = false;
            this.button_admin_cp.Click += new System.EventHandler(this.button_admin_cp_Click);
            // 
            // button_logout
            // 
            this.button_logout.BackColor = System.Drawing.Color.Green;
            this.button_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_logout.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.ForeColor = System.Drawing.Color.White;
            this.button_logout.Location = new System.Drawing.Point(594, 11);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(97, 40);
            this.button_logout.TabIndex = 42;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = false;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_home
            // 
            this.button_home.BackColor = System.Drawing.Color.Green;
            this.button_home.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(12, 12);
            this.button_home.Name = "button_home";
            this.button_home.Size = new System.Drawing.Size(369, 40);
            this.button_home.TabIndex = 40;
            this.button_home.Text = "Blood Management System";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(11, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 32);
            this.label1.TabIndex = 39;
            this.label1.Text = "BUBT BLOOD DONATION CENTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(679, 23);
            this.label2.TabIndex = 43;
            this.label2.Text = "Information of Blood Donation and Receiving";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView_admin_searchResult
            // 
            this.dataGridView_admin_searchResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView_admin_searchResult.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_admin_searchResult.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_admin_searchResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_admin_searchResult.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_admin_searchResult.Location = new System.Drawing.Point(11, 313);
            this.dataGridView_admin_searchResult.Name = "dataGridView_admin_searchResult";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_admin_searchResult.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_admin_searchResult.Size = new System.Drawing.Size(680, 296);
            this.dataGridView_admin_searchResult.TabIndex = 44;
            // 
            // comboBox_AdminGeneralSearch
            // 
            this.comboBox_AdminGeneralSearch.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_AdminGeneralSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox_AdminGeneralSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_AdminGeneralSearch.ForeColor = System.Drawing.SystemColors.GrayText;
            this.comboBox_AdminGeneralSearch.FormattingEnabled = true;
            this.comboBox_AdminGeneralSearch.Items.AddRange(new object[] {
            "Patients List",
            "Donor\'s Phone Number",
            "Donor\'s Name",
            "Patient\'s Phone Number",
            "Patient\'s Name",
            "Date Range",
            "relational tool"});
            this.comboBox_AdminGeneralSearch.Location = new System.Drawing.Point(12, 218);
            this.comboBox_AdminGeneralSearch.Name = "comboBox_AdminGeneralSearch";
            this.comboBox_AdminGeneralSearch.Size = new System.Drawing.Size(300, 27);
            this.comboBox_AdminGeneralSearch.TabIndex = 48;
            this.comboBox_AdminGeneralSearch.Text = "Select Search Item";
            // 
            // textBox_adminGeneralSearchValue
            // 
            this.textBox_adminGeneralSearchValue.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_adminGeneralSearchValue.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_adminGeneralSearchValue.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox_adminGeneralSearchValue.Location = new System.Drawing.Point(12, 275);
            this.textBox_adminGeneralSearchValue.MaxLength = 50;
            this.textBox_adminGeneralSearchValue.Name = "textBox_adminGeneralSearchValue";
            this.textBox_adminGeneralSearchValue.Size = new System.Drawing.Size(300, 27);
            this.textBox_adminGeneralSearchValue.TabIndex = 47;
            this.textBox_adminGeneralSearchValue.Text = "Enter Search Value";
            this.textBox_adminGeneralSearchValue.Enter += new System.EventHandler(this.textBox_adminGeneralSearchValue_Enter);
            this.textBox_adminGeneralSearchValue.Leave += new System.EventHandler(this.textBox_adminGeneralSearchValue_Leave);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGreen;
            this.label5.Location = new System.Drawing.Point(8, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(503, 21);
            this.label5.TabIndex = 45;
            this.label5.Text = "Search Value:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(12, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(575, 22);
            this.label4.TabIndex = 46;
            this.label4.Text = "Search According To:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button_search
            // 
            this.button_search.BackColor = System.Drawing.Color.AliceBlue;
            this.button_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_search.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_search.ForeColor = System.Drawing.Color.DodgerBlue;
            this.button_search.Location = new System.Drawing.Point(599, 211);
            this.button_search.Name = "button_search";
            this.button_search.Size = new System.Drawing.Size(93, 39);
            this.button_search.TabIndex = 49;
            this.button_search.Text = "SEARCH";
            this.button_search.UseVisualStyleBackColor = false;
            this.button_search.Click += new System.EventHandler(this.button_search_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(350, 282);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 50;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(350, 225);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 51;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(599, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 39);
            this.button1.TabIndex = 52;
            this.button1.Text = "PRINT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // patientdonorInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(704, 621);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.button_search);
            this.Controls.Add(this.comboBox_AdminGeneralSearch);
            this.Controls.Add(this.textBox_adminGeneralSearchValue);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView_admin_searchResult);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_admin_cp);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_home);
            this.Controls.Add(this.label1);
            this.Name = "patientdonorInfo";
            this.Text = "Admin CP Search Donor and Patient";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_searchResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_admin_cp;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView_admin_searchResult;
        private System.Windows.Forms.ComboBox comboBox_AdminGeneralSearch;
        private System.Windows.Forms.TextBox textBox_adminGeneralSearchValue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_search;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button button1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}