﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class patientdonorInfo : Form
    {
        public patientdonorInfo()
        {
            InitializeComponent();
        }

        private void button_search_Click(object sender, EventArgs e)
        {
            DonorPatientInfo();
        }

        private void button_admin_cp_Click(object sender, EventArgs e)
        {
            Admincp admincp = new Admincp();
            admincp.Width = this.Width;
            admincp.Height = this.Height;
            admincp.StartPosition = FormStartPosition.Manual;
            admincp.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            admincp.ShowDialog();
            this.Close();
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Width = this.Width;
            home.Height = this.Height;
            home.StartPosition = FormStartPosition.Manual;
            home.Location = new Point(this.Location.X, this.Location.Y);

            this.Hide();
            home.ShowDialog();
            this.Close();
        }

        private void DonorPatientInfo()
        {
            string ConnectString = ConnectionString.connString;
            MySqlConnection conn = new MySqlConnection(ConnectString);

            try
            {
                if (comboBox_AdminGeneralSearch.SelectedIndex != -1)
                {
                    string searchBy = comboBox_AdminGeneralSearch.SelectedItem.ToString().Trim();
                    string searchValue = textBox_adminGeneralSearchValue.Text.Trim().ToString();
                    //DateTime tempdate1 = dateTimePicker1.Value; not working
                    //DateTime tempdate2 = dateTimePicker2.Value; not working
                    string tempdate1 = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                    string tempdate2 = dateTimePicker2.Value.ToString("yyyy-MM-dd");
                    //string tempdate2 = "2018-05-28";
                    //string tempdate1 = "2016-05-28";

                    //DateTime tempdate1 = DateTime.ParseExact(tempdate11, "yyyy-MM-dd", CultureInfo.InvariantCulture); not working
                    //DateTime tempdate2 = DateTime.ParseExact(tempdate22, "yyyy-MM-dd", CultureInfo.InvariantCulture); not working

                    conn.Open();
                    MySqlCommand query = conn.CreateCommand();
                    query.CommandType = CommandType.Text;

                    if(searchBy == "Patients List")
                    {
                        query.CommandText = "select Patient_Name, Phone_Number, email, birthday, city, age, address, bloodgroup, gender, diseases FROM patient";
                    }

                    else if (searchBy == "Donor's Phone Number")
                    {
                        
                        query.CommandText = "SELECT Student_Name, Phone_No, Patient_Name, Phone_Number, donationdate FROM donortable, patient, patientdonor WHERE donortable.Donor_Index = patientdonor.Donor_Index and patient.Patient_Index = patientdonor.Patient_Index and donortable.Phone_No = '" + searchValue + "'  ";
                    }
                    else if (searchBy == "Donor's Name")
                    {
                        query.CommandText = " SELECT Student_Name, Phone_No, Patient_Name, Phone_Number, donationdate FROM donortable, patient, patientdonor WHERE donortable.Donor_Index = patientdonor.Donor_Index and patient.Patient_Index = patientdonor.Patient_Index and donortable.Student_Name LIKE '%" + searchValue + "%' ";
                    }
                    else if (searchBy == "Patient's Phone Number")
                    {
                        query.CommandText = "SELECT Student_Name, Phone_No, Patient_Name, Phone_Number, donationdate FROM donortable, patient, patientdonor WHERE donortable.Donor_Index = patientdonor.Donor_Index and patient.Patient_Index = patientdonor.Patient_Index and patient.Phone_Number = '" + searchValue + "'  ";
                    }
                    else if (searchBy == "Patient's Name")
                    {
                        query.CommandText = " SELECT Student_Name, Phone_No, Patient_Name, Phone_Number, donationdate FROM donortable, patient, patientdonor WHERE donortable.Donor_Index = patientdonor.Donor_Index and patient.Patient_Index = patientdonor.Patient_Index and patient.Patient_Name LIKE '%" + searchValue + "%' ";
                    }
                    else if (searchBy == "Date Range")
                    {
                        query.CommandText = "SELECT Student_Name, Phone_No, Patient_Name, Phone_Number, donationdate FROM donortable, patient, patientdonor WHERE donortable.Donor_Index = patientdonor.Donor_Index and patient.Patient_Index = patientdonor.Patient_Index and patientdonor.donationdate BETWEEN '" + tempdate1 + "' and '" + tempdate2 + "' ORDER BY donationdate DESC";
                        //"SELECT * FROM patientdonor WHERE donationdate BETWEEN '" + tempdate1 + "' and '" + tempdate2 + "' ORDER BY donationdate DESC";
                            //"SELECT Student_Name, Phone_No, Patient_Name, Phone_Number, donationdate FROM donortable, patient, patientdonor WHERE donortable.Donor_Index = patientdonor.Donor_Index and patient.Patient_Index = patientdonor.Patient_Index and patientdonor.donationdate between '" + tempdate2 + "' and  '" + tempdate1 + "' order by donationdate desc   ";
                    }
                    else if (searchBy == "relational tool")
                    {
                        query.CommandText = "select * from patientdonor";
                    }
                    else
                    {
                        MessageBox.Show("Select Search Item");
                    }

                    //create adaptor to fill data from database
                    MySqlDataAdapter sda = new MySqlDataAdapter(query);

                    //create datatable which holds the data
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    //bind your data to gridview
                    dataGridView_admin_searchResult.DataSource = dt;
                    // dataGridView1.DataBind();



                    query.ExecuteNonQuery();
                    conn.Close();

                }
                else
                {
                    comboBox_AdminGeneralSearch.Text = "Select Search Item";
                    MessageBox.Show("Select Search Item");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //PrintDialog printDlg = new PrintDialog();
            //printDlg.Document = printDocument1;

            // for previewing before printing
            PrintPreviewDialog prntpreview = new PrintPreviewDialog();
            prntpreview.Document = printDocument1;
            prntpreview.ShowDialog();


            /*printDlg.AllowSelection = true;

            printDlg.AllowSomePages = true;

            //Call ShowDialog

            if (printDlg.ShowDialog() == DialogResult.OK)
              
                printDocument1.Print();*/
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            int height = dataGridView_admin_searchResult.Height;
            dataGridView_admin_searchResult.Height = dataGridView_admin_searchResult.RowCount * dataGridView_admin_searchResult.RowTemplate.Height * 2;
            Bitmap bmp = new Bitmap(dataGridView_admin_searchResult.Width, dataGridView_admin_searchResult.Height);
            dataGridView_admin_searchResult.DrawToBitmap(bmp, new Rectangle(0, 0, dataGridView_admin_searchResult.Width, dataGridView_admin_searchResult.Height));
            dataGridView_admin_searchResult.Height = height;
            e.Graphics.DrawImage(bmp, 10, 10);
        }

        private void textBox_adminGeneralSearchValue_Enter(object sender, EventArgs e)
        {
            if (textBox_adminGeneralSearchValue.Text == "Enter Search Value")
            {
                textBox_adminGeneralSearchValue.Text = "";
                textBox_adminGeneralSearchValue.ForeColor = Color.Black;
            }
        }

        private void textBox_adminGeneralSearchValue_Leave(object sender, EventArgs e)
        {
            if (textBox_adminGeneralSearchValue.Text == "")
            {
                textBox_adminGeneralSearchValue.Text = "Enter Search Value";
                textBox_adminGeneralSearchValue.ForeColor = Color.Gray;
            }
        }
    }
}
